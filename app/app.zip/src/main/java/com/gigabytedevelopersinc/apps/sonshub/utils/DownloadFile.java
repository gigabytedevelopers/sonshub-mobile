package com.gigabytedevelopersinc.apps.sonshub.utils;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Environment;
import com.gigabytedevelopersinc.apps.sonshub.App;
import com.gigabytedevelopersinc.apps.sonshub.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static android.content.Context.NOTIFICATION_SERVICE;

/**
 * @author Created by Emmanuel Nwokoma (Founder and CEO at Gigabyte Developers) on 11/23/2018
 **/
public class DownloadFile extends AsyncTask<String, String, String> {
    private CharSequence contentText, contentTitle;
    private Context context;
    private PendingIntent contentIntent;
    private int DOWNLOAD_ID = 1;
    private long time;
    private int icon;
    private File file;
    //private String fileURL = "https://sonshub.com/wp-content/uploads/2018/11/Agah-kuti-Yesuyabiya.mp3";

    private Notification notification;
    private NotificationManager notificationManager;

    private void downloadNotification() {
        context = App.getContext();
        notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);

        icon = R.drawable.ic_file_download;
        //the text that appears first on the status bar
        CharSequence tickerText = "Downloading...";
        time = System.currentTimeMillis();

        //notification = new Notification(icon, tickerText, time);

        //the bold font
        contentTitle = "Your download is in progress";
        //the text that needs to change
        contentText = "0% complete";
        Intent notificationIntent = new Intent(Intent.ACTION_VIEW);
        notificationIntent.setType("audio/*");
        contentIntent = PendingIntent.getActivity(context, 0, notificationIntent, 0);

        Notification.Builder builder = new Notification.Builder(context);
        builder.setSmallIcon(icon)
                .setContentTitle(contentTitle)
                .setTicker(tickerText)
                .setContentText(contentText)
                .setContentIntent(contentIntent);
        notification = builder.build();
        notificationManager.notify(DOWNLOAD_ID, notification);
    }

    @Override
    protected void onPreExecute() {
        //execute the status bar notification
        /*cdt = new CountDownTimer(100 * 60 * 1000, 500) {
            public void onTick(long millisUntilFinished) {
                downloadNotification();
            }

            public void onFinish() {
                downloadNotification();
            }
        };*/
        downloadNotification();
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... params) {
        int count;
        int previousProgress = 0;
        try {
            URL url = new URL(params[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoOutput(true);
            connection.connect();

            int lengthOfFile = connection.getContentLength();

            //make the SonsHub folder
            File sdrFolder = new File(Environment.getExternalStorageDirectory() + "/SonsHub");
            boolean success = false;

            if (!sdrFolder.exists()) {
                success = sdrFolder.mkdir();
            }
            if (!success) {
                String PATH = Environment.getExternalStorageDirectory()
                        + "/SonsHub/";
                file = new File(PATH);
                file.mkdirs();
            } else {
                String PATH = Environment.getExternalStorageDirectory()
                        + "/SonsHub/";
                file = new File(PATH);
                file.mkdirs();
            }

            String urlPath = url.getPath();
            String filename = urlPath.substring(urlPath.lastIndexOf('/')+1);
            String path = sdrFolder + "/" + filename;

            /*String[] path = url.getPath().split("/");
            String mp3 = path[path.length - 1];
            String mp31 = mp3.replace("%20", " ");
            String sdrMp3 = mp31.replace("%28", "(");
            String sdrMp31 = sdrMp3.replace("%29", ")");
            String sdrMp32 = sdrMp31.replace("%27", "'");*/

            //File outputFile = new File(file, path);
            FileOutputStream fos = new FileOutputStream(path);

            InputStream input = connection.getInputStream();

            byte[] data = new byte[1024];
            long total = 0;
            while ((count = input.read(data)) != -1) {
                total += count;
                int prog = (int) (total * 100 / lengthOfFile);
                if (prog > previousProgress) {
                    // Only post progress event if we've made progress.
                    previousProgress = prog;
                    publishProgress("" + prog);
                    fos.write(data, 0, count);
                }
                //publishProgress("" + (int) (total * 100 / lengthOfFile));
                //fos.write(data, 0, count);
            }
            input.close();
            fos.flush();
            fos.close();
        } catch (IllegalArgumentException | IllegalStateException | IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onProgressUpdate(String... progress) {
        contentText = Integer.parseInt(progress[0]) + "% complete";
        Notification.Builder builder = new Notification.Builder(context);
        builder.setSmallIcon(icon)
                .setContentTitle(contentTitle)
                .setContentText(contentText)
                .setProgress(100, Integer.parseInt(progress[0]), false)
                .setContentIntent(contentIntent);
        notification = builder.build();
        notificationManager.notify(DOWNLOAD_ID, notification);
        super.onProgressUpdate(progress);
    }

    /*public void onPostExecute(String... result){
        Notification.Builder builder = new Notification.Builder(context);
        builder.setSmallIcon(icon)
                .setContentTitle("SonsHub Mobile")
                .setContentText("Download complete")
                // Removes the progress bar
                .setProgress(0,0,false)
                .setContentIntent(contentIntent);
        notification = builder.build();
        notificationManager.notify(DOWNLOAD_ID, notification);
        super.onPostExecute(result);
    }*/
}