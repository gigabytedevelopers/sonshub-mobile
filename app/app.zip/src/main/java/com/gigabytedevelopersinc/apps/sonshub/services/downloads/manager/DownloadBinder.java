package com.gigabytedevelopersinc.apps.sonshub.services.downloads.manager;

import android.app.Notification;
import android.os.Binder;
import android.os.Build;
import android.text.TextUtils;

/**
 * @author Created by Emmanuel Nwokoma (Founder and CEO at Gigabyte Developers) on 11/25/2018
 **/
public class DownloadBinder extends Binder {

    private DownloadManager downloadManager = null;

    private DownloadListener downloadListener = null;

    private String currDownloadUrl = "";

    public DownloadManager getDownloadManager() {
        return downloadManager;
    }

    DownloadBinder() {
        if (downloadListener == null) {
            downloadListener = new DownloadListener();
        }
    }

    public void startDownload(String downloadUrl, int progress) {
        /* Because downloadManager is a subclass of AsyncTask, and AsyncTask can only be executed once,
         * So each download need a new downloadManager. */
        downloadManager = new DownloadManager(downloadListener);

        /* Because DownloadUtil has a static variable of downloadManger, so each download need to use new downloadManager. */
        DownloadUtil.setDownloadManager(downloadManager);

        // Execute download manager, this will invoke downloadManager's doInBackground() method.
        downloadManager.execute(downloadUrl);

        // Save current download file url.
        currDownloadUrl = downloadUrl;

        // Create and start foreground service with notification.
        //Notification notification = downloadListener.getDownloadNotification("Downloading...", progress);
        //downloadListener.getDownloadService().startForeground(1, notification);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification notification = downloadListener.getDownloadNotificationOreo("Starting Download...", progress);
            downloadListener.getDownloadService().startForeground(1, notification);
        } else {
            //downloadListener.sendDownloadNotification("Downloading...", progress);
            Notification notification = downloadListener.getDownloadNotification("Starting Download...", progress);
            /*NotificationManager notificationManager = (NotificationManager) downloadListener.getDownloadService().getSystemService(Context.NOTIFICATION_SERVICE);

            notificationManager.notify(1, notification);*/
           downloadListener.getDownloadService().startForeground(1, notification);
        }
    }

    private void contDownload(String downloadUrl, int progress) {
        downloadManager = new DownloadManager(downloadListener);
        DownloadUtil.setDownloadManager(downloadManager);
        downloadManager.execute(downloadUrl);

        currDownloadUrl = downloadUrl;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification notification = downloadListener.getDownloadNotificationOreo("Downloading...", progress);
            downloadListener.getDownloadService().startForeground(1, notification);
        } else {
            Notification notification = downloadListener.getDownloadNotification("Downloading...", progress);
           downloadListener.getDownloadService().startForeground(1, notification);
        }
    }

    void continueDownload() {
        if (currDownloadUrl != null && !TextUtils.isEmpty(currDownloadUrl)) {
            int lastDownloadProgress = downloadManager.getLastDownloadProgress();
            contDownload(currDownloadUrl, lastDownloadProgress);
        }
    }

    void cancelDownload() {
        downloadManager.cancelDownload();
    }

    void pauseDownload() {
        downloadManager.pauseDownload();
    }

    DownloadListener getDownloadListener() {
        return downloadListener;
    }
}
