package com.gigabytedevelopersinc.apps.sonshub.services.downloads.manager;

import android.os.AsyncTask;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.io.IOException;

/**
 * @author Created by Emmanuel Nwokoma (Founder and CEO at Gigabyte Developers) on 11/25/2018
 **/
public class DownloadManager extends AsyncTask<String, Integer, Integer> {
    private DownloadListener downloadListener;
    private boolean downloadCanceled = false;
    private boolean downloadPaused = false;
    private int lastDownloadProgress = 0;

    boolean isDownloadCanceled() {
        return downloadCanceled;
    }

    private void setDownloadCanceled(boolean downloadCanceled) {
        this.downloadCanceled = downloadCanceled;
    }

    boolean isDownloadPaused() {
        return downloadPaused;
    }

    private void setDownloadPaused(boolean downloadPaused) {
        this.downloadPaused = downloadPaused;
    }

    int getLastDownloadProgress() {
        return lastDownloadProgress;
    }

    public void setLastDownloadProgress(int lastDownloadProgress) {
        this.lastDownloadProgress = lastDownloadProgress;
    }

    DownloadManager(DownloadListener downloadListener) {
        this.downloadListener = downloadListener;
        this.setDownloadPaused(false);
        this.setDownloadCanceled(false);
    }

    /* This method is invoked after doInBackground() method. */
    @Override
    protected void onPostExecute(Integer downloadStatue) {
        if (downloadStatue == DownloadUtil.DOWNLOAD_SUCCESS) {
            this.setDownloadCanceled(false);
            this.setDownloadPaused(false);
            downloadListener.onSuccess();
        } else if (downloadStatue == DownloadUtil.DOWNLOAD_FAILED) {
            this.setDownloadCanceled(false);
            this.setDownloadPaused(false);
            downloadListener.onFailed();
        } else if (downloadStatue == DownloadUtil.DOWNLOAD_PAUSED) {
            downloadListener.onPaused();
        } else if (downloadStatue == DownloadUtil.DOWNLOAD_CANCELED) {
            downloadListener.onCanceled();
        }
    }


    /* Invoked when this async task execute.When this method return, onPostExecute() method will be called.*/
    @Override
    protected Integer doInBackground(String... params) {

        // Set current thread priority lower than main thread priority, so main thread Pause, Continue and Cancel action will not be blocked.
        Thread.currentThread().setPriority(Thread.NORM_PRIORITY - 2);

        String downloadFileUrl = "";
        if (params!=null && params.length > 0) {
            downloadFileUrl = params[0];
        }
        File downloadLocalFile = createDownloadLocalFile(downloadFileUrl);

        return DownloadUtil.downloadFileFromUrl(downloadFileUrl, downloadLocalFile);
    }

    /*
     * Parse the download file name from the download file url,
     * check whether the file exist in sdcard download directory or not.
     * If the file do not exist then create it.
     *
     * Return the file object.
     * */
    private File createDownloadLocalFile(String downloadFileUrl) {
        File ret = null;
        File file;
        try {
            if (downloadFileUrl != null && !TextUtils.isEmpty(downloadFileUrl)) {
                int lastIndex = downloadFileUrl.lastIndexOf("/");
                if (lastIndex > -1) {
                    String downloadFileName = downloadFileUrl.substring(lastIndex + 1);
                    String downloadDirectoryName = Environment.DIRECTORY_DOWNLOADS;
                    File downloadDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    String downloadDirectoryPath = downloadDirectory.getPath();

                    boolean success = false;
                    if (downloadFileName.toLowerCase().endsWith(".mp3")) {
                        File sdrFolder = new File(Environment.getExternalStorageDirectory()
                                + "/SonsHub" + "/Music");
                        if (!sdrFolder.exists()) {
                            success = sdrFolder.mkdir();
                        }
                        if (!success) {
                            String PATH = Environment.getExternalStorageDirectory()
                                    + "/SonsHub/" + "Music/";
                            file = new File(PATH);
                            file.mkdirs();
                        } else {
                            String PATH = Environment.getExternalStorageDirectory()
                                    + "/SonsHub/" + "Music/";
                            file = new File(PATH);
                            file.mkdirs();
                        }

                        ret = new File(sdrFolder + "/" + downloadFileName);

                        if (!ret.exists()) {
                            ret.createNewFile();
                        }
                    } else if (downloadFileName.toLowerCase().endsWith(".mp4")) {
                        File sdrFolder = new File(Environment.getExternalStorageDirectory()
                                + "/SonsHub" + "/Videos");
                        if (!sdrFolder.exists()) {
                            success = sdrFolder.mkdir();
                        }
                        if (!success) {
                            String PATH = Environment.getExternalStorageDirectory()
                                    + "/SonsHub/" + "Videos/";
                            file = new File(PATH);
                            file.mkdirs();
                        } else {
                            String PATH = Environment.getExternalStorageDirectory()
                                    + "/SonsHub/" + "Videos/";
                            file = new File(PATH);
                            file.mkdirs();
                        }

                        ret = new File(sdrFolder + "/" + downloadFileName);

                        if (!ret.exists()) {
                            ret.createNewFile();
                        }
                    } else {
                        File sdrFolder = new File(Environment.getExternalStorageDirectory() + "/SonsHub");
                    }
                }
            }
        } catch(IOException ex) {
            Log.e(DownloadUtil.TAG_DOWNLOAD_MANAGER, ex.getMessage(), ex);
        } finally {
            return ret;
        }
    }

    /* Update download async task progress. */
    void updateTaskProgress(Integer newDownloadProgress) {
        lastDownloadProgress = newDownloadProgress;
        downloadListener.onUpdateDownloadProgress(newDownloadProgress);
    }

    void pauseDownload() {
        this.setDownloadPaused(true);
    }

    void cancelDownload() {
        this.setDownloadCanceled(true);
    }
}
