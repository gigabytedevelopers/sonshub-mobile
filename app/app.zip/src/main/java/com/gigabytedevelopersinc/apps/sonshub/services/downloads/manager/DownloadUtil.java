package com.gigabytedevelopersinc.apps.sonshub.services.downloads.manager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import com.gigabytedevelopersinc.apps.sonshub.App;
import okhttp3.*;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;

import java.io.*;
import java.net.SocketTimeoutException;
import java.util.concurrent.TimeUnit;

/**
 * @author Created by Emmanuel Nwokoma (Founder and CEO at Gigabyte Developers) on 11/25/2018
 **/
public class DownloadUtil {
    @SuppressLint("StaticFieldLeak")
    public static Context context = App.getContext();
    public static final String TAG_DOWNLOAD_MANAGER = "TAG_DOWNLOAD_MANAGER";

    public static final int DOWNLOAD_SUCCESS = 1;
    public static final int DOWNLOAD_FAILED = 2;
    public static final int DOWNLOAD_PAUSED = 3;
    public static final int DOWNLOAD_CANCELED = 4;

    private static DownloadManager downloadManager = null;
    private static OkHttpClient okHttpClient = new OkHttpClient();

    public static DownloadManager getDownloadManager() {
        return downloadManager;
    }

    public static void setDownloadManager(DownloadManager downloadManager) {
        DownloadUtil.downloadManager = downloadManager;
    }

    /* Get download file size returned from http server header. */
    public static long getDownloadUrlFileSize(String downloadUrl) {
        long ret = 0;
        try {
            if (downloadUrl != null && !TextUtils.isEmpty(downloadUrl)) {
                Request.Builder builder = new Request.Builder();
                builder = builder.url(downloadUrl);
                Request request = builder.build();

                Call call = okHttpClient.newCall(request);
                Response response = call.execute();
                ResponseBody body = response.body();

                if(response.isSuccessful()) {
                    assert body != null;
                    ret = body.contentLength();
                    /*String contentLength = response.header("Content-Length");
                    assert contentLength != null;
                    ret = Long.parseLong(contentLength);*/
                }
            }
        } catch(Exception ex) {
            Log.e(TAG_DOWNLOAD_MANAGER, ex.getMessage(), ex);
        } finally {
            return ret;
        }
    }

    public static int downloadFileFromUrl(String downloadFileUrl, File existLocalFile) {
        int ret = DOWNLOAD_SUCCESS;
        String fileName = downloadFileUrl.substring(downloadFileUrl.lastIndexOf('/') + 1);
        DownloadListener downloadListener = new DownloadListener();

        InputStream inputStream = null;
        try {
            long existLocalFileLength = existLocalFile.length();
            OkHttpClient okHttpClientDownload = new OkHttpClient.Builder()
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(180, TimeUnit.SECONDS)
                    .build();
            Request.Builder builder = new Request.Builder();
            builder = builder.url(downloadFileUrl);
            builder = builder.addHeader("RANGE", "bytes=" + existLocalFileLength);
            Request request = builder.build();

            Call call = okHttpClientDownload.newCall(request);
            Response response = call.execute();
            ResponseBody responseBody = response.body();
            assert responseBody != null;
            long downloadFileLength = responseBody.contentLength();

            if (downloadFileLength == 0) {
                ret = DOWNLOAD_FAILED;
                if (!need2Download(fileName)) {
                    existLocalFile.delete();
                }
            }
            if (downloadFileLength == existLocalFileLength) {
                ret = DOWNLOAD_SUCCESS;
            } else {
                if (response.isSuccessful()) {
                    RandomAccessFile downloadFile = new RandomAccessFile(existLocalFile, "rw");
                    downloadFile.seek(existLocalFileLength);

                    inputStream = responseBody.byteStream();
                    BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
                    byte data[] = new byte[64 * 1024];

                    long totalReadLength = 0;
                    int readLength = bufferedInputStream.read(data);

                    while (readLength != -1) {
                        if (getDownloadManager().isDownloadPaused()) {
                            ret = DOWNLOAD_PAUSED;
                            break;
                        } else if (getDownloadManager().isDownloadCanceled()) {
                            ret = DOWNLOAD_CANCELED;
                            if (!need2Download(fileName)) {
                                existLocalFile.delete();
                            }
                            break;
                        } else {
                            downloadFile.write(data, 0, readLength);
                            totalReadLength = totalReadLength + readLength;
                            int downloadProgress = (int)
                                    ((totalReadLength + existLocalFileLength) * 100 / downloadFileLength);
                            getDownloadManager().updateTaskProgress(downloadProgress);
                            readLength = bufferedInputStream.read(data);
                        }
                    }
                }
            }

        } catch(Exception ex) {
            if (ex instanceof SocketTimeoutException) {
                ret = DOWNLOAD_FAILED;
                if (!need2Download(fileName)) {
                    existLocalFile.delete();
                }
                new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(context, "There was a Timeout Error while downloading... Please try again", Toast.LENGTH_LONG).show());
            } else {
                ret = DOWNLOAD_FAILED;
                if (!need2Download(fileName)) {
                    existLocalFile.delete();
                }
                new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(context, "There was an Error while downloading... Please try again", Toast.LENGTH_LONG).show());
            }
            Log.e(TAG_DOWNLOAD_MANAGER, ex.getMessage(), ex);
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return ret;
    }

    private static boolean need2Download(String fileName) {
        File basePathMp3 = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Music");
        File basePathVideo = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Videos");

        File fullPathMp3 = new File(basePathMp3, fileName);
        File fullPathVideo = new File(basePathVideo, fileName);

        /*if (fullPathMp3.exists() || fullPathVideo.exists()) {
            return false;
        }*/
        return !fullPathMp3.exists() && !fullPathVideo.exists();
    }
}
