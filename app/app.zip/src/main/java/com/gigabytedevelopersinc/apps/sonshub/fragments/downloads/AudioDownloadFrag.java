package com.gigabytedevelopersinc.apps.sonshub.fragments.downloads;


import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.gigabytedevelopersinc.apps.sonshub.R;
import com.gigabytedevelopersinc.apps.sonshub.adapters.DownloadedAdapter;
import com.gigabytedevelopersinc.apps.sonshub.models.DownloadedModel;
import com.gigabytedevelopersinc.apps.sonshub.utils.DownloadListener;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 */
public class AudioDownloadFrag extends Fragment {

    private RecyclerView recyclerView;
    private DownloadedAdapter adapter;
    private List<DownloadedModel> list;

    public AudioDownloadFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_music_download, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerview);
        list= new ArrayList<>();
        ArrayList<File> totalAudio = getListFiles();

        if (totalAudio != null){
            if (totalAudio.size() > 0){
                setListAdapter(parseToFileName(totalAudio), totalAudio);
            }
        }
    }

    private ArrayList<DownloadedModel> parseToFileName(ArrayList<File> videoFiles) {
        ArrayList<DownloadedModel> fileNames = new ArrayList<>();

        for (File f :
                videoFiles) {
            String[] name = f.getAbsolutePath().split("/");
            if (name[(name.length - 1)].endsWith(".mp3"))
                fileNames.add(new DownloadedModel(name[(name.length - 1)]));
        }

        return fileNames;
    }

    private void setListAdapter(List<DownloadedModel> data, ArrayList<File> audio){
        adapter = new DownloadedAdapter(getActivity(), data, new DownloadListener() {
            @Override
            public void onAudioOrVideoClick(View view, int position, String title) {
                if (Build.VERSION.SDK_INT >= 24) {
                    try {
                        Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                        m.invoke(null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    File fileFolder = Environment.getExternalStorageDirectory();
                    File audioUrl = new File(fileFolder.getPath() + "/SonsHub/Music/"+title);
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.fromFile(audioUrl),"audio/mp3");
                    startActivity(Intent.createChooser(intent, "Play this song with"));
                } catch (Exception e) {
                    Toast.makeText(getContext(), "No Application can open this file", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }

//                intent.setDataAndType(Uri.parse(audiourl) ,"audio/*");
//                startActivity(intent);
            }
        });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);
    }

    private ArrayList<File> getListFiles() {
        File file = new File(Environment.getExternalStorageDirectory() + "/SonsHub/Music");

        ArrayList<File> fileArrayList = new ArrayList<>();

        File[] listOfFiles = file.listFiles();
        if (file.exists()) {
            for (File f :
                    listOfFiles) {
                if (f.getAbsolutePath().endsWith(".mp3"))
                    fileArrayList.add(f);
            }
        } else {
            file.mkdir();
        }

        return fileArrayList;
    }
}
