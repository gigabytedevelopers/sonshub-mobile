package com.gigabytedevelopersinc.apps.sonshub.player.music.music

/**
 * Project - SonsHub
 * Created with Android Studio
 * Company: Gigabyte Developers
 * User: Emmanuel Nwokoma
 * Title: Founder and CEO
 * Day: Wednesday, 06
 * Month: February
 * Year: 2019
 * Date: 06 Feb, 2019
 * Time: 11:21 PM
 * Desc: Music
 **/
data class Music(
    val artist: String,
    val year: Int,
    val track: Int,
    val title: String,
    val duration: Long,
    val album: String,
    val path: String
)