package com.gigabytedevelopersinc.apps.sonshub.utils;

public interface IOnBackPressed {
    boolean onBackPressed();
}
