package com.gigabytedevelopersinc.apps.sonshub.utils;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import com.gigabytedevelopersinc.apps.sonshub.App;
import com.gigabytedevelopersinc.apps.sonshub.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static android.content.Context.NOTIFICATION_SERVICE;

/**
 * @author Created by Emmanuel Nwokoma (Founder and CEO at Gigabyte Developers) on 11/24/2018
 **/
public class Downloader extends AsyncTask<String,Integer,Void> {
    private CharSequence contentText, contentTitle;
    private Context context;
    private PendingIntent contentIntent;
    private int DOWNLOAD_ID = 1;
    private long time;
    private int icon;
    private File file;

    private Notification notification;
    private NotificationManager notificationManager;

    private void downloadNotification() {
        context = App.getContext();
        notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);

        icon = R.drawable.ic_file_download;
        //the text that appears first on the status bar
        CharSequence tickerText = "Downloading...";
        time = System.currentTimeMillis();

        //notification = new Notification(icon, tickerText, time);

        //the bold font
        contentTitle = "File Download";
        //the text that needs to change
        contentText = "Download in progress";
        Intent notificationIntent = new Intent(Intent.ACTION_VIEW);
        notificationIntent.setType("audio/*");
        contentIntent = PendingIntent.getActivity(context, 0, notificationIntent, 0);

        Notification.Builder builder = new Notification.Builder(context);
        builder.setSmallIcon(icon)
                .setContentTitle(contentTitle)
                .setTicker(tickerText)
                .setContentText(contentText)
                .setContentIntent(contentIntent);
        notification = builder.build();
        notificationManager.notify(DOWNLOAD_ID, notification);
    }

    protected void onPreExecute(){
        downloadNotification();
        super.onPreExecute();
    }

    protected Void doInBackground(String...params){
        String storeDir = Environment.getExternalStorageDirectory().toString();
        URL url;
        int count;
        int previousProgress = 0;
        try {
            url = new URL(params[0]);
            String pathl;
            //make the SonsHub folder
            File sdrFolder = new File(Environment.getExternalStorageDirectory() + "/SonsHub");
            boolean success = false;

            if (!sdrFolder.exists()) {
                success = sdrFolder.mkdir();
            }
            if (!success) {
                String PATH = Environment.getExternalStorageDirectory()
                        + "/SonsHub/";
                file = new File(PATH);
                file.mkdirs();
            } else {
                String PATH = Environment.getExternalStorageDirectory()
                        + "/SonsHub/";
                file = new File(PATH);
                file.mkdirs();
            }
            try {
                File f = new File(storeDir);
                if(f.exists()){
                    HttpURLConnection con = (HttpURLConnection)url.openConnection();
                    InputStream is = con.getInputStream();
                    String pathr = url.getPath();
                    String filename = pathr.substring(pathr.lastIndexOf('/')+1);
                    pathl = storeDir + "/SonsHub" + "/" + filename;
                    FileOutputStream fos = new FileOutputStream(pathl);
                    int lengthOfFile = con.getContentLength();
                    byte data[] = new byte[1024];
                    long total = 0;
                    while ((count = is.read(data)) != -1) {
                        total += count;
                        int prog = (int)((total*100)/lengthOfFile);
                        if (prog > previousProgress) {
                            // publishing the progress
                            publishProgress((int) ((total * 100) / lengthOfFile));
                            // writing data to output file
                            fos.write(data, 0, count);
                        }
                    }

                    is.close();
                    fos.flush();
                    fos.close();
                }
                else{
                    Log.e("Error","Not found: "+storeDir);

                }

            } catch (Exception e) {
                e.printStackTrace();

            }

        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return null;

    }

    protected void onProgressUpdate(Integer... progress) {
        contentTitle = "SonsHub File Downloader";
        contentText = "" + progress[0] + "%";
        Notification.Builder builder = new Notification.Builder(context);
        builder.setSmallIcon(icon)
                .setContentTitle(contentTitle)
                .setContentText(contentText)
                .setProgress(100, progress[0], false);
        // Displays the progress bar on notification
        notification = builder.build();
        notificationManager.notify(DOWNLOAD_ID, notification);
    }

    protected void onPostExecute(Void result){
        contentTitle = "SonsHub File Downloader";
        contentText = "Download Complete";
        Notification.Builder builder = new Notification.Builder(context);
        builder.setSmallIcon(icon)
                .setContentText(contentText)
                .setContentTitle(contentTitle)
                // Removes the progress bar
                .setProgress(0,0,false)
                .setContentIntent(contentIntent);
        notification = builder.build();
        notificationManager.notify(DOWNLOAD_ID, notification);
    }
}
