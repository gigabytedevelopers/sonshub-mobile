package com.gigabytedevelopersinc.apps.sonshub.player.music.uihelpers

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import com.gigabytedevelopersinc.apps.sonshub.R

/**
 * Project - SonsHub
 * Created with Android Studio
 * Company: Gigabyte Developers
 * User: Emmanuel Nwokoma
 * Title: Founder and CEO
 * Day: Wednesday, 06
 * Month: February
 * Year: 2019
 * Date: 06 Feb, 2019
 * Time: 11:32 PM
 * Desc: PreferencesHelper
 **/
private const val TAG_ACCENT_PREF = "com.gigabytedevelopersinc.apps.sonshub.pref_accent"
private const val TAG_ACCENT_VALUE = "com.gigabytedevelopersinc.apps.sonshub.pref_accent_value"
private const val TAG_THEME_PREF = "com.gigabytedevelopersinc.apps.sonshub.pref_theme"
private const val TAG_THEME_VALUE = "com.gigabytedevelopersinc.apps.sonshub.pref_theme_value"
private const val TAG_SEARCH_BAR_PREF = "com.gigabytedevelopersinc.apps.sonshub.pref_search_bar"
private const val TAG_SEARCH_BAR_VALUE = "com.gigabytedevelopersinc.apps.sonshub.pref_search_bar_value"

class PreferencesHelper(private val activity: Activity) {

    private fun getPreference(key: String): SharedPreferences {
        return activity.getSharedPreferences(key, Context.MODE_PRIVATE)
    }

    fun invertTheme() {
        val value = !isThemeInverted()
        getPreference(TAG_THEME_PREF).edit().putBoolean(TAG_THEME_VALUE, value).apply()
        activity.recreate()
    }

    fun isThemeInverted(): Boolean {
        return getPreference(TAG_THEME_PREF).getBoolean(TAG_THEME_VALUE, false)
    }

    fun applyTheme(accent: Int, isThemeInverted: Boolean) {
        val theme = resolveTheme(isThemeInverted, accent)
        activity.setTheme(theme)
    }

    //get theme
    private fun resolveTheme(isThemeDark: Boolean, accent: Int): Int {

        return when (accent) {

            R.color.red -> if (isThemeDark) R.style.MusicPlayerAppThemeRedInverted else R.style.MusicPlayerAppThemeRed

            R.color.pink -> if (isThemeDark) R.style.MusicPlayerAppThemePinkInverted else R.style.MusicPlayerAppThemePink

            R.color.purple ->
                if (isThemeDark) R.style.MusicPlayerAppThemePurpleInverted else R.style.MusicPlayerAppThemePurple

            R.color.deep_purple ->
                if (isThemeDark) R.style.MusicPlayerAppThemeDeepPurpleInverted else R.style.MusicPlayerAppThemeDeepPurple

            R.color.indigo ->
                if (isThemeDark) R.style.MusicPlayerAppThemeIndigoInverted else R.style.MusicPlayerAppThemeIndigo

            R.color.blue -> if (isThemeDark) R.style.MusicPlayerAppThemeBlueInverted else R.style.MusicPlayerAppThemeBlue
            R.color.light_blue ->
                if (isThemeDark) R.style.MusicPlayerAppThemeLightBlueInverted else R.style.MusicPlayerAppThemeLightBlue

            R.color.cyan -> if (isThemeDark) R.style.MusicPlayerAppThemeCyanInverted else R.style.MusicPlayerAppThemeCyan

            R.color.teal -> if (isThemeDark) R.style.MusicPlayerAppThemeTealInverted else R.style.MusicPlayerAppThemeTeal

            R.color.green -> if (isThemeDark) R.style.MusicPlayerAppThemeGreenInverted else R.style.MusicPlayerAppThemeGreen

            R.color.amber -> if (isThemeDark) R.style.MusicPlayerAppThemeAmberInverted else R.style.MusicPlayerAppThemeAmber

            R.color.orange ->
                if (isThemeDark) R.style.MusicPlayerAppThemeOrangeInverted else R.style.MusicPlayerAppThemeOrange

            R.color.deep_orange ->
                if (isThemeDark) R.style.MusicPlayerAppThemeDeepOrangeInverted else R.style.MusicPlayerAppThemeDeepOrange

            R.color.brown -> if (isThemeDark) R.style.MusicPlayerAppThemeBrownInverted else R.style.MusicPlayerAppThemeBrown

            R.color.gray ->
                if (isThemeDark) R.style.MusicPlayerAppThemeGrayLightInverted else R.style.MusicPlayerAppThemeGrayLight

            R.color.blue_gray ->
                if (isThemeDark) R.style.MusicPlayerAppThemeBlueGrayInverted else R.style.MusicPlayerAppThemeBlueGray
            else -> R.color.blue
        }
    }

    fun setThemeAccent(accent: Int) {
        getPreference(TAG_ACCENT_PREF).edit().putInt(TAG_ACCENT_VALUE, accent).apply()
        activity.recreate()
    }

    fun getAccent(): Int {
        return try {
            getPreference(TAG_ACCENT_PREF).getInt(
                TAG_ACCENT_VALUE,
                R.color.blue
            )
        } catch (e: Exception) {
            R.color.blue
        }
    }

    fun setSearchToolbarVisibility(isVisible: Boolean) {
        getPreference(TAG_SEARCH_BAR_PREF).edit().putBoolean(TAG_SEARCH_BAR_VALUE, isVisible).apply()
    }

    fun isSearchBarEnabled(): Boolean {
        return getPreference(TAG_SEARCH_BAR_PREF).getBoolean(TAG_SEARCH_BAR_VALUE, true)
    }
}