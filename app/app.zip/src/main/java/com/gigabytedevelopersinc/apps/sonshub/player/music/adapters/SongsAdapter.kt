package com.gigabytedevelopersinc.apps.sonshub.player.music.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gigabytedevelopersinc.apps.sonshub.R
import com.gigabytedevelopersinc.apps.sonshub.player.music.music.Music
import com.gigabytedevelopersinc.apps.sonshub.player.music.music.MusicUtils
import com.gigabytedevelopersinc.apps.sonshub.player.music.player.MediaPlayerHolder
import com.gigabytedevelopersinc.apps.sonshub.player.music.uihelpers.UIUtils
import kotlinx.android.synthetic.main.music_song_item.view.*

/**
 * Project - SonsHub
 * Created with Android Studio
 * Company: Gigabyte Developers
 * User: Emmanuel Nwokoma
 * Title: Founder and CEO
 * Day: Wednesday, 06
 * Month: February
 * Year: 2019
 * Date: 06 Feb, 2019
 * Time: 11:18 PM
 * Desc: SongsAdapter
 **/
class SongsAdapter(music: MutableList<Music>) : RecyclerView.Adapter<SongsAdapter.SongsHolder>() {

    var onSongClick: ((Music) -> Unit)? = null

    private var mMusic = music

    init {
        mMusic.sortBy { it.track }
    }

    fun swapSongs(music: MutableList<Music>) {
        mMusic = music
        mMusic.sortBy { it.track }
        notifyDataSetChanged()
    }

    fun randomPlaySelectedAlbum(mediaPlayerHolder: MediaPlayerHolder) {
        val currentAlbum = mMusic
        currentAlbum.shuffle()
        val song = currentAlbum[0]
        mediaPlayerHolder.setCurrentSong(song, mMusic)
        mediaPlayerHolder.initMediaPlayer(song)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongsHolder {
        return SongsHolder(LayoutInflater.from(parent.context).inflate(R.layout.music_song_item, parent, false))
    }

    override fun getItemCount(): Int {
        return mMusic.size
    }

    override fun onBindViewHolder(holder: SongsHolder, position: Int) {
        val track = mMusic[holder.adapterPosition].track
        val title = mMusic[holder.adapterPosition].title
        val duration = mMusic[holder.adapterPosition].duration

        holder.bindItems(track, title, duration)
    }

    inner class SongsHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindItems(track: Int, title: String, duration: Long) {
            itemView.track.text = MusicUtils.formatSongTrack(track).toString()
            itemView.title.text = title
            itemView.duration.text = MusicUtils.formatSongDuration(duration)
            itemView.setOnClickListener { onSongClick?.invoke(mMusic[adapterPosition]) }
            UIUtils.setHorizontalScrollBehavior(itemView, itemView.title)
        }
    }
}