package com.gigabytedevelopersinc.apps.sonshub.utils.misc;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.gigabytedevelopersinc.apps.sonshub.R;

import java.io.File;
import java.util.Objects;

import static android.content.Context.DOWNLOAD_SERVICE;

/**
 * @author Created by Emmanuel Nwokoma (Founder and CEO at Gigabyte Developers) on 11/30/2018
 **/
public class ShowUpdate extends BottomSheetDialogFragment {
    private BroadcastReceiver receiver;
    private long enqueue;
    private DownloadManager dm;
    Context context;
    boolean isDeleted;

    private File file;
    private Button updateButton;

    @SuppressLint("RestrictedApi")
    @Override
    public void setupDialog(Dialog dialog, int style) {
        super.setupDialog(dialog, style);
        //Get the content View
        //Set the custom view
        View privacyPolicyView = LayoutInflater.from(getContext()).inflate(R.layout.updater_notice, null);
        //dialog.setContentView(view);

        //dialog = new BottomSheetDialog(Objects.requireNonNull(getContext()));
        (privacyPolicyView.findViewById(R.id.update_continue)).setOnClickListener(v -> {
            Toast.makeText(Objects.requireNonNull(getContext()).getApplicationContext(), "App Downloading...Please Wait", Toast.LENGTH_LONG).show();
            dm = (DownloadManager) Objects.requireNonNull(getContext()).getSystemService(DOWNLOAD_SERVICE);
            downloadStatus();

            File file = new File(Environment.getExternalStorageDirectory()
                    + "/SonsHub" + "/AppUpdate" + "/sonshub_mobile.apk");
            if (file.exists()) {
                isDeleted = file.delete();
                deleteAndInstall();
            } else {
                firstTimeInstall();
            }
        });
        //dialog.getContext().setTheme(R.style.Theme_AppCompat_NoActionBar);
        dialog.setCancelable(false);
        dialog.setContentView(privacyPolicyView);
        dialog.show();

        //Set the coordinator layout behavior

        //Set callback
        /*if (behavior != null && behavior instanceof android.support.design.widget.BottomSheetBehavior) {
            ((BottomSheetBehavior) behavior).setBottomSheetCallback(mBottomSheetBehaviorCallback);
        }*/
    }

    /*@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View privacyPolicyView = getLayoutInflater().inflate(R.layout.updater_notice,null);
        WebView webView = privacyPolicyView.findViewById(R.id.updater_content_web);
        webView.loadUrl("file:///android_asset/update_content.html");
        (privacyPolicyView.findViewById(R.id.update_continue)).setOnClickListener(v -> {
            Toast.makeText(getApplicationContext(), "App Downloading...Please Wait", Toast.LENGTH_LONG).show();
            dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);

            File file = new File(Environment.getExternalStorageDirectory()
                    + "/SonsHub" + "/AppUpdate" + "/sonshub_mobile.apk");
            if (file.exists()) {
                isDeleted = file.delete();
                deleteAndInstall();
            } else {
                firstTimeInstall();
            }
        });
        bottomSheetDialog.getContext().setTheme(R.style.Theme_AppCompat_NoActionBar);
        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setContentView(privacyPolicyView);
        bottomSheetDialog.show();
    }*/

    private void firstTimeInstall() {
        Log.d("May be 1st Update:","OR deleted from folder" );
        downloadAndInstall();
    }

    private void deleteAndInstall() {
        if (isDeleted) {
            Log.d("Deleted Existed file:", String.valueOf(isDeleted));
            downloadAndInstall();

        } else {
            Log.d("NOT DELETED:", String.valueOf(isDeleted));
            Toast.makeText(Objects.requireNonNull(getContext()).getApplicationContext(), "Error in Updating...Please try Later", Toast.LENGTH_LONG).show();
            //bottomSheetDialog.dismiss();
        }
    }

    private void downloadAndInstall() {
        File sdrFolder = new File(Environment.getExternalStorageDirectory()
                + "/SonsHub" + "/AppUpdate");
        String path = Environment.getExternalStorageDirectory()
                + "/SonsHub/" + "AppUpdate/" + "sonshub_mobile";

        boolean success = false;
        if (!sdrFolder.exists()) {
            success = sdrFolder.mkdir();
        }
        if (!success) {
            String PATH = Environment.getExternalStorageDirectory()
                    + "/SonsHub/" + "AppUpdate/";
            file = new File(PATH);
            file.mkdirs();
        } else {
            String PATH = Environment.getExternalStorageDirectory()
                    + "/SonsHub/" + "AppUpdate/";
            file = new File(PATH);
            file.mkdirs();
        }

        DownloadManager.Request request = new DownloadManager.Request(
                Uri.parse("http://gigabytedevelopersinc.com/apps/sonshub/sonshub_mobile.apk"));
        request.setDestinationUri(Uri.fromFile(new File(Environment.getExternalStorageDirectory()
                + "/SonsHub" + "/AppUpdate" + "/sonshub_mobile.apk")));

        enqueue = dm.enqueue(request);

        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                    Toast.makeText(Objects.requireNonNull(getContext()).getApplicationContext(), "Download Completed", Toast.LENGTH_LONG).show();

                    long downloadId = intent.getLongExtra(
                            DownloadManager.EXTRA_DOWNLOAD_ID, 0);
                    DownloadManager.Query query = new DownloadManager.Query();
                    query.setFilterById(enqueue);
                    Cursor c = dm.query(query);
                    if (c.moveToFirst()) {
                        int columnIndex = c.getColumnIndex(DownloadManager.COLUMN_STATUS);
                        if (DownloadManager.STATUS_SUCCESSFUL == c.getInt(columnIndex)) {
                            String uriString = c.getString(c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));

                            Log.d("ainfo", uriString);

                            if(downloadId == c.getInt(0)) {
                                Log.d("DOWNLOAD PATH:", c.getString(c.getColumnIndex("local_uri")));


                                Log.d("isRooted:",String.valueOf(isRooted()));
                                if (!isRooted()) {
                                    //if your device is not rooted
                                    Intent intent_install = new Intent(Intent.ACTION_VIEW);
                                    intent_install.setDataAndType(Uri.fromFile(new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/AppUpdate/" + "sonshub_mobile.apk")), "application/vnd.android.package-archive");
                                    Log.d("phone path",Environment.getExternalStorageDirectory() + "/SonsHub" + "/AppUpdate/" + "sonshub_mobile.apk");
                                    startActivity(intent_install);
                                    Toast.makeText(getContext().getApplicationContext(), "App Installing", Toast.LENGTH_LONG).show();
                                } else {
                                    //if your device is rooted then you can install or update app in background directly
                                    Toast.makeText(getContext().getApplicationContext(), "App Installing...Please Wait", Toast.LENGTH_LONG).show();
                                    File file = new File(path);
                                    Log.d("IN INSTALLER:", path);
                                    if(file.exists()){
                                        try {
                                            String command;
                                            Log.d("IN File exists:",path);

                                            command = "pm install -r " + path;
                                            Log.d("COMMAND:",command);
                                            Process proc = Runtime.getRuntime().exec(new String[] { "su", "-c", command });
                                            proc.waitFor();
                                            Toast.makeText(getContext().getApplicationContext(), "App Installed Successfully", Toast.LENGTH_LONG).show();

                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    c.close();
                }
            }
        };

        Objects.requireNonNull(getContext()).registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
    }

    private static boolean isRooted() {
        return findBinary("su");
    }

    public static boolean findBinary(String binaryName) {
        boolean found = false;
        if (!found) {
            String[] places = {"/sbin/", "/system/bin/", "/system/xbin/", "/data/local/xbin/","/data/local/bin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/"};
            for (String where : places) {
                if ( new File( where + binaryName ).exists() ) {
                    found = true;
                    break;
                }
            }
        }
        return found;
    }

    private void downloadStatus() {
        updateButton = Objects.requireNonNull(getActivity()).findViewById(R.id.update_continue);
        DownloadManager.Query queryProgress = new DownloadManager.Query();
        Cursor cursor = dm.query(queryProgress);
        cursor.moveToFirst();
        int bytes_downloaded = cursor.getInt(cursor
                .getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
        int bytes_total = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
        final int dl_progress = (int) ((bytes_downloaded * 100L) / bytes_total);

        switch (cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS))) {
            case DownloadManager.STATUS_RUNNING:
                updateButton.setVisibility(View.GONE);
        }
    }
}
