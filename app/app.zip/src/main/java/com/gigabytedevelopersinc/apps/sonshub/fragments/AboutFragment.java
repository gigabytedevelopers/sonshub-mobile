package com.gigabytedevelopersinc.apps.sonshub.fragments;


import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;
import com.gigabytedevelopersinc.apps.sonshub.App;
import com.gigabytedevelopersinc.apps.sonshub.activities.MainActivity;
import com.github.javiersantos.appupdater.AppUpdaterUtils;
import com.github.javiersantos.appupdater.enums.AppUpdaterError;
import com.github.javiersantos.appupdater.enums.UpdateFrom;
import com.github.javiersantos.appupdater.objects.Update;
import com.google.android.gms.ads.AdListener;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import androidx.fragment.app.Fragment;
import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.*;
import com.gigabytedevelopersinc.apps.sonshub.BuildConfig;
import com.gigabytedevelopersinc.apps.sonshub.R;
import com.google.android.material.snackbar.Snackbar;
import saschpe.android.customtabs.CustomTabsHelper;
import saschpe.android.customtabs.WebViewFallback;

import java.io.File;
import java.util.Objects;

import static android.content.Context.DOWNLOAD_SERVICE;

/**
 * A simple {@link Fragment} subclass.
 */
public class AboutFragment extends Fragment {

    // Updater
    private ImageView updateImg;
    private TextView updateTitle, updateText;
    private Button continueButton, cancelButton;

    private long enqueue;
    private DownloadManager dm;
    private boolean isDeleted;


    public AboutFragment() {
        // Required empty public constructor
    }


    @SuppressLint("InflateParams")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_about, container, false);
        String url = getResources().getString(R.string.developer_url);
        String faceBookUrl = getResources().getString(R.string.facebook_url);
        String sonsHubUrl = getResources().getString(R.string.website_url);
        String instagramUrl = getResources().getString(R.string.instagram_url);
        String changeLogUrl = getResources().getString(R.string.changelog_url);
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setShowTitle(true);
        CustomTabsIntent customTabsIntent = builder.build();
        builder.setToolbarColor(getResources().getColor(R.color.colorPrimary));
        CustomTabsHelper.addKeepAliveExtra(Objects.requireNonNull(getContext()), customTabsIntent.intent);

        LinearLayout developer = view.findViewById(R.id.developedBy);
        developer.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(getContext(), customTabsIntent,
                Uri.parse(url),
                new WebViewFallback()));

        TextView versionNumber = view.findViewById(R.id.version_number);
        versionNumber.append(BuildConfig.VERSION_NAME);

        LinearLayout facebook = view.findViewById(R.id.facebook);
        facebook.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(getContext(), customTabsIntent,
                Uri.parse(faceBookUrl),
                new WebViewFallback()));
        LinearLayout youtube = view.findViewById(R.id.youtube);
        youtube.setOnClickListener(view1 -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getResources().getString(R.string.youtube_url)))));

        LinearLayout website = view.findViewById(R.id.web);
        website.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(getContext(), customTabsIntent,
                Uri.parse(sonsHubUrl),
                new WebViewFallback()));
        LinearLayout instagram = view.findViewById(R.id.instagram);
        instagram.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(getContext(), customTabsIntent,
                Uri.parse(instagramUrl),
                new WebViewFallback()));
        LinearLayout changelog = view.findViewById(R.id.changeLog);
        changelog.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(getContext(), customTabsIntent,
                Uri.parse(changeLogUrl),
                new WebViewFallback()));
        LinearLayout openSource = view.findViewById(R.id.open_source_license);
        openSource.setOnClickListener(view1 ->{

            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Objects.requireNonNull(getContext()));
            View openSourceView = getLayoutInflater().inflate(R.layout.open_source_bottom_sheet, null);
            openSourceView.findViewById(R.id.license_1).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.license_1_url)))));
            openSourceView.findViewById(R.id.license_2).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.license_2_url)))));
            openSourceView.findViewById(R.id.license_3).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.license_3_url)))));
            openSourceView.findViewById(R.id.license_4).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.license_4_url)))));
            openSourceView.findViewById(R.id.license_5).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.license_5_url)))));
            openSourceView.findViewById(R.id.license_6).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.license_6_url)))));
            openSourceView.findViewById(R.id.license_7).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.license_7_url)))));
            openSourceView.findViewById(R.id.license_8).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.license_8_url)))));
            openSourceView.findViewById(R.id.license_9).setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.license_9_url)))));

            (openSourceView.findViewById(R.id.continue_btn)).setOnClickListener(v -> bottomSheetDialog.dismiss());
            bottomSheetDialog.setCancelable(false);
            bottomSheetDialog.setContentView(openSourceView);
            bottomSheetDialog.show();

        });
        LinearLayout privacyPolicy = view.findViewById(R.id.privacy_policy);
        privacyPolicy.setOnClickListener(view1 -> {
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Objects.requireNonNull(getContext()));
            View privacyPolicyView = getLayoutInflater().inflate(R.layout.privacy_policy,null);
            WebView webView = privacyPolicyView.findViewById(R.id.privacy_policy_web);
            webView.loadUrl("file:///android_asset/www/policy.html");
            (privacyPolicyView.findViewById(R.id.privacy_policy_continue)).setOnClickListener(v -> bottomSheetDialog.dismiss());
            bottomSheetDialog.setCancelable(false);
            bottomSheetDialog.setContentView(privacyPolicyView);
            bottomSheetDialog.show();
        });

        LinearLayout about = view.findViewById(R.id.aboutSonsHub);
        about.setOnLongClickListener(v -> {
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Objects.requireNonNull(getContext()));
            View privacyPolicyView = getLayoutInflater().inflate(R.layout.general_notice,null);

            updateImg = privacyPolicyView.findViewById(R.id.warningImg);
            updateTitle = privacyPolicyView.findViewById(R.id.warning);
            updateText = privacyPolicyView.findViewById(R.id.generalNoticeText);
            continueButton = privacyPolicyView.findViewById(R.id.continueButton);
            cancelButton = privacyPolicyView.findViewById(R.id.cancelButton);

            updateImg.setImageResource(R.drawable.ic_system_update_white_24dp);
            updateImg.setColorFilter(ContextCompat.getColor(Objects.requireNonNull(getContext()), R.color.black), android.graphics.PorterDuff.Mode.SRC_IN);
            updateTitle.setText(getString(R.string.update_check_title));
            updateText.setText("If for some reason you have not automatically been asked to update your version of SonsHub Mobile to the latest, then it most likely means that you are already running the latest version of SonsHub Mobile.\n\nDo you still want to check for new SonsHub Mobile app update?");
            continueButton.setText(getString(R.string.update_check_proceed));
            cancelButton.setText(getString(R.string.update_check_cancel));

            continueButton.setOnClickListener(view1 -> {
                bottomSheetDialog.dismiss();
                checkForUpdate();
            });
            cancelButton.setOnClickListener(view1 -> {
                bottomSheetDialog.dismiss();
                Snackbar.make(Objects.requireNonNull(getActivity())
                                .findViewById(android.R.id.content),
                        getString(R.string.snackBar_update_check_cancel),
                        Snackbar.LENGTH_LONG).show();
            });
            bottomSheetDialog.setCancelable(false);
            bottomSheetDialog.setContentView(privacyPolicyView);
            bottomSheetDialog.show();
            return false;
        });

        LinearLayout rate = view.findViewById(R.id.rate);
        rate.setOnClickListener(v -> {
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Objects.requireNonNull(getContext()));
            View updateNoticeView = getLayoutInflater().inflate(R.layout.updater_notice, null);

            TextView updateNoticeTitle = updateNoticeView.findViewById(R.id.updateNoticeTitle);
            TextView updateNoticeMarquee = updateNoticeView.findViewById(R.id.updateNoticeMarquee);
            TextView updateNoticeText = updateNoticeView.findViewById(R.id.updateNoticeText);
            Button continueButton = updateNoticeView.findViewById(R.id.update_continue);
            LinearLayout closeButton = updateNoticeView.findViewById(R.id.close);
            updateNoticeTitle.setText(getString(R.string.rate));
            updateNoticeMarquee.setVisibility(View.GONE);
            updateNoticeText.setText("Love what we do? \nWhy not support us today by giving SonsHub Mobile a 5-Star rating on Play Store. This takes only a few seconds and means a lot to us.\n\nClick on the button below to rate SonsHub Mobile on Google Play Store.");
            continueButton.setText(getString(R.string.rate_btn_desc));

            // For Rating SonsHub Mobile
            Intent rateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.gigabytedevelopersinc.apps.sonshub"));
            continueButton.setOnClickListener(v1 -> {
                startActivity(rateIntent);
                bottomSheetDialog.dismiss();
            });
            closeButton.setOnClickListener(v1 -> bottomSheetDialog.dismiss());
            bottomSheetDialog.setCancelable(false);
            bottomSheetDialog.setContentView(updateNoticeView);
            bottomSheetDialog.show();
        });

        LinearLayout share = view.findViewById(R.id.share);
        share.setOnClickListener(v -> {
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Objects.requireNonNull(getContext()));
            View updateNoticeView = getLayoutInflater().inflate(R.layout.updater_notice, null);

            TextView updateNoticeTitle = updateNoticeView.findViewById(R.id.updateNoticeTitle);
            TextView updateNoticeMarquee = updateNoticeView.findViewById(R.id.updateNoticeMarquee);
            TextView updateNoticeText = updateNoticeView.findViewById(R.id.updateNoticeText);
            Button continueButton = updateNoticeView.findViewById(R.id.update_continue);
            LinearLayout closeButton = updateNoticeView.findViewById(R.id.close);
            updateNoticeTitle.setText(getString(R.string.share));
            updateNoticeMarquee.setVisibility(View.GONE);
            updateNoticeText.setText("Love what we do? We can't do this without your support.\nSupport Us today by sharing SonsHub Mobile across to your friends. This takes only a few seconds and means a lot to us.\n\nClick on the button below to share SonsHub Mobile to your friends.");
            continueButton.setText(getString(R.string.share_btn_desc));

            // For Sharing SonsHub Mobile
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            String shareSub = "\nDownload SonsHub Mobile App for your latest Gospel Music, Sermons, Articles and all round Christian Entertainment.\n\n";
            shareSub = shareSub + "https://bit.ly/DownloadSonsHubMobile \n\n";
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Check out SonsHub Mobile");
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareSub);
            continueButton.setOnClickListener(v1 -> {
                startActivity(Intent.createChooser(shareIntent, "Share SonsHub Mobile using"));
                bottomSheetDialog.dismiss();
            });
            closeButton.setOnClickListener(v1 -> bottomSheetDialog.dismiss());
            bottomSheetDialog.setCancelable(false);
            bottomSheetDialog.setContentView(updateNoticeView);
            bottomSheetDialog.show();
        });

        return view;
    }

    @SuppressLint("InflateParams")
    private void checkForUpdate() {
        Snackbar updateCheck = Snackbar.make(Objects.requireNonNull(getActivity())
                        .findViewById(android.R.id.content),
                "Hang on, Checking for new version update! \n- This takes less than a minute.",
                Snackbar.LENGTH_INDEFINITE);
        updateCheck.show();
        AppUpdaterUtils appUpdaterUtils = new AppUpdaterUtils(getContext())
                .setUpdateFrom(UpdateFrom.JSON)
                .setUpdateJSON("https://gigabytedevelopersinc.com/apps/sonshub/update/update.json")
                .withListener(new AppUpdaterUtils.UpdateListener() {
                    @Override
                    public void onSuccess(Update update, Boolean isUpdateAvailable) {
                        Log.d("Latest Version", update.getLatestVersion());
                        Log.d("Latest Version Code", String.valueOf(update.getLatestVersionCode()));
                        Log.d("Release notes", update.getReleaseNotes());
                        Log.d("URL", String.valueOf(update.getUrlToDownload()));
                        Log.d("Is update available?", Boolean.toString(isUpdateAvailable));

                        if ((update.getLatestVersionCode() > BuildConfig.VERSION_CODE) || isUpdateAvailable) {
                            Handler handler = new Handler();
                            Runnable r = () -> {
                                updateCheck.dismiss();
                                Toast.makeText(Objects.requireNonNull(getContext()), getString(R.string.toast_success_new_version), Toast.LENGTH_LONG).show();
                                BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Objects.requireNonNull(getContext()));
                                final View updateNoticeView = LayoutInflater.from(Objects.requireNonNull(getContext())).inflate(R.layout.updater_notice, null);

                                TextView updateNoticeText = updateNoticeView.findViewById(R.id.updateNoticeText);
                                Button continueButton = updateNoticeView.findViewById(R.id.update_continue);
                                LinearLayout closeButton = updateNoticeView.findViewById(R.id.close);
                                updateNoticeText.setText(update.getReleaseNotes());
                                continueButton.setOnClickListener(v -> {
                                    bottomSheetDialog.dismiss();
                                    BottomSheetDialog bottomSheetDialogConfirm = new BottomSheetDialog(Objects.requireNonNull(getContext()));
                                    final View generalNoticeViewConfirm = LayoutInflater.from(Objects.requireNonNull(getContext())).inflate(R.layout.general_notice, null);

                                    TextView generalNoticeTextConfirm = generalNoticeViewConfirm.findViewById(R.id.generalNoticeText);
                                    Button cancelButtonConfirm = generalNoticeViewConfirm.findViewById(R.id.cancelButton);
                                    Button continueButtonConfirm = generalNoticeViewConfirm.findViewById(R.id.continueButton);
                                    Button optionButtonConfirm = generalNoticeViewConfirm.findViewById(R.id.optionButton);

                                    generalNoticeTextConfirm.setText("Did you install your current version of SonsHub Mobile from the Google Play Store? If yes, use the first button to update from Play Store.\n\nDid you install your current version of SonsHub Mobile elsewhere (not from Play Store)? If yes, use the second button to manually download the latest update from our Server.");
                                    cancelButtonConfirm.setVisibility(View.GONE);
                                    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                                    continueButtonConfirm.setLayoutParams(layoutParams);
                                    continueButtonConfirm.setText(getString(R.string.update_server));
                                    optionButtonConfirm.setVisibility(View.VISIBLE);
                                    optionButtonConfirm.setText(getString(R.string.update_play_store));
                                    continueButtonConfirm.setOnClickListener(v1 -> {
                                        dm = (DownloadManager) Objects.requireNonNull(getContext()).getSystemService(DOWNLOAD_SERVICE);
                                        Toast.makeText(Objects.requireNonNull(getContext()), "App Update Downloading... Please Wait", Toast.LENGTH_LONG).show();
                                        File file = new File(Environment.getExternalStorageDirectory()
                                                + "/SonsHub" + "/AppUpdate" + "/sonshub_mobile.apk");
                                        if (file.exists()) {
                                            isDeleted = file.delete();
                                            deleteAndInstall();
                                        } else {
                                            firstTimeInstall();
                                        }
                                        bottomSheetDialog.dismiss();
                                    });
                                    optionButtonConfirm.setOnClickListener(v1 -> {
                                        Intent rate = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.gigabytedevelopersinc.apps.sonshub"));
                                        if (BuildConfig.DEBUG) {
                                            Toast.makeText(Objects.requireNonNull(getContext()), "Sorry, You are not permitted to update through Play Store!", Toast.LENGTH_LONG).show();
                                        } else {
                                            startActivity(rate);
                                        }
                                        bottomSheetDialog.dismiss();
                                    });
                                    bottomSheetDialogConfirm.setCancelable(true);
                                    bottomSheetDialogConfirm.setContentView(generalNoticeViewConfirm);
                                    bottomSheetDialogConfirm.show();
                                });
                                closeButton.setOnClickListener(v -> bottomSheetDialog.dismiss());
                                bottomSheetDialog.setCancelable(false);
                                bottomSheetDialog.setContentView(updateNoticeView);
                                bottomSheetDialog.show();
                            };
                            handler.postDelayed(r, 5000);
                        } else {
                            // No Update
                            Handler handler = new Handler();
                            Runnable r = () -> {
                                updateCheck.dismiss();
                                Snackbar.make(Objects.requireNonNull(getActivity())
                                                .findViewById(android.R.id.content),
                                        "You have the latest version of SonsHub Mobile!",
                                        Snackbar.LENGTH_LONG).show();
                            };
                            handler.postDelayed(r, 5000);
                        }
                    }

                    @Override
                    public void onFailed(AppUpdaterError appUpdaterError) {
                        Log.d("AppUpdater Error", "Something went wrong");
                    }
                });
        appUpdaterUtils.start();
    }

    private void firstTimeInstall() {
        Log.d("May be 1st Update:","OR deleted from folder" );
        downloadAndInstall();
    }

    private void deleteAndInstall() {
        if (isDeleted) {
            Log.d("Deleted Existed file:", String.valueOf(true));
            downloadAndInstall();

        } else {
            Log.d("NOT DELETED:", String.valueOf(false));
            Toast.makeText(Objects.requireNonNull(getContext()), "Error in Updating...Please try Later", Toast.LENGTH_LONG).show();
            //bottomSheetDialog.dismiss();
        }
    }

    private void downloadAndInstall() {
        File sdrFolder = new File(Environment.getExternalStorageDirectory()
                + "/SonsHub" + "/AppUpdate");
        String path = Environment.getExternalStorageDirectory()
                + "/SonsHub/" + "AppUpdate/" + "sonshub_mobile";

        boolean success = false;
        if (!sdrFolder.exists()) {
            success = sdrFolder.mkdir();
        }
        File file;
        if (!success) {
            String PATH = Environment.getExternalStorageDirectory()
                    + "/SonsHub/" + "AppUpdate/";
            file = new File(PATH);
            file.mkdirs();
        } else {
            String PATH = Environment.getExternalStorageDirectory()
                    + "/SonsHub/" + "AppUpdate/";
            file = new File(PATH);
            file.mkdirs();
        }

        String downloadLink;
        if (BuildConfig.DEBUG) {
            downloadLink = "https://gigabytedevelopersinc.com/apps/sonshub/update/SonsHub-debug-" + BuildConfig.VERSION_NAME + ".apk";
        } else {
            downloadLink = "https://gigabytedevelopersinc.com/apps/sonshub/update/SonsHub-release-" + BuildConfig.VERSION_NAME + ".apk";
        }
        DownloadManager.Request request = new DownloadManager.Request(
                Uri.parse(downloadLink));
        request.setDestinationUri(Uri.fromFile(new File(Environment.getExternalStorageDirectory()
                + "/SonsHub" + "/AppUpdate" + "/sonshub_mobile.apk")));

        enqueue = dm.enqueue(request);

        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                    Toast.makeText(context, "Download Completed", Toast.LENGTH_LONG).show();

                    long downloadId = intent.getLongExtra(
                            DownloadManager.EXTRA_DOWNLOAD_ID, 0);
                    DownloadManager.Query query = new DownloadManager.Query();
                    query.setFilterById(enqueue);
                    Cursor c = dm.query(query);
                    if (c.moveToFirst()) {
                        int columnIndex = c.getColumnIndex(DownloadManager.COLUMN_STATUS);
                        if (DownloadManager.STATUS_SUCCESSFUL == c.getInt(columnIndex)) {
                            String uriString = c.getString(c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));

                            Log.d("ainfo", uriString);

                            if (downloadId == c.getInt(0)) {
                                Log.d("DOWNLOAD PATH:", c.getString(c.getColumnIndex("local_uri")));
                                Log.d("isRooted:", String.valueOf(isRooted()));

                                if (!isRooted()) {
                                    //if your device is not rooted
                                    Intent intent_install = new Intent(Intent.ACTION_VIEW);
                                    intent_install.setDataAndType(Uri.fromFile(new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/AppUpdate/" + "sonshub_mobile.apk")), "application/vnd.android.package-archive");
                                    Log.d("phone path", Environment.getExternalStorageDirectory() + "/SonsHub" + "/AppUpdate/" + "sonshub_mobile.apk");
                                    startActivity(intent_install);
                                    Toast.makeText(context, "App Installing", Toast.LENGTH_LONG).show();
                                } else {
                                    //if your device is rooted then you can install or update app in background directly
                                    Toast.makeText(context, "App Installing... Please Wait", Toast.LENGTH_LONG).show();
                                    File file = new File(path);
                                    Log.d("IN INSTALLER:", path);
                                    if (file.exists()) {
                                        try {
                                            String command;
                                            Log.d("IN File exists:", path);

                                            command = "pm install -r " + path;
                                            Log.d("COMMAND:", command);
                                            Process proc = Runtime.getRuntime().exec(new String[]{"su", "-c", command});
                                            proc.waitFor();
                                            Toast.makeText(context, "App Installed Successfully", Toast.LENGTH_LONG).show();

                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    c.close();
                }
            }
        };

        Objects.requireNonNull(getContext()).registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
    }

    private static boolean isRooted() {
        return findBinary("su");
    }

    public static boolean findBinary(String binaryName) {
        boolean found = false;
        if (!found) {
            String[] places = {"/sbin/", "/system/bin/", "/system/xbin/", "/data/local/xbin/","/data/local/bin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/"};
            for (String where : places) {
                if ( new File( where + binaryName ).exists() ) {
                    found = true;
                    break;
                }
            }
        }
        return found;
    }
}
