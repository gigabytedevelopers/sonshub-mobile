package com.gigabytedevelopersinc.apps.sonshub;

import android.annotation.SuppressLint;
import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.os.SystemClock;
import com.crashlytics.android.Crashlytics;
import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.RatingEvent;
import com.crashlytics.android.answers.SearchEvent;
import com.crashlytics.android.answers.ShareEvent;
import com.gigabytedevelopersinc.apps.sonshub.services.notification.MyFirebaseMessagingService;
import com.gigabytedevelopersinc.apps.sonshub.utils.misc.AnalyticsManager;
import com.gigabytedevelopersinc.apps.sonshub.utils.misc.CrashReportingManager;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.database.FirebaseDatabase;
import io.fabric.sdk.android.Fabric;

import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

public class App extends Application implements Application.ActivityLifecycleCallbacks {
    private static final String TAG = App.class.getSimpleName();
    /**
     * Keeps a reference of the application context
     */
    @SuppressLint("StaticFieldLeak")
    private static Context sContext;
    @SuppressLint("StaticFieldLeak")
    private static App sInstance;

    @Override
    public void onCreate() {
        super.onCreate();
        sContext = getApplicationContext();
        sInstance = this;
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        registerActivityLifecycleCallbacks(sInstance);
        if(!BuildConfig.DEBUG) {
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
            // Enables Crash, Error Reporting for detailed, well structured Error messages on Firebase Console
            Fabric.with(sInstance, new Crashlytics());
            CrashReportingManager.enable(sInstance, true);

            // Initialize Live Banner Ads immediately SonsHub Mobile is opened
            MobileAds.initialize(sInstance, getResources().getString(R.string.admob_app_id));
            if (Build.VERSION.SDK_INT >= 24) {
                try {
                    Method m = StrictMode.class.getMethod(getResources().getString(R.string.runtimeStrictMode));
                    m.invoke(null);
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }
            // Initialize User Analytics to track usage events within SonsHub Mobile
            AnalyticsManager.intialize(sContext);
            Answers.getInstance().logSearch(new SearchEvent());
            Answers.getInstance().logShare(new ShareEvent());
            Answers.getInstance().logRating(new RatingEvent());
        } else {
            // Disable Crash, Error Reporting since we can easily make use of the logcat during development
            CrashReportingManager.enable(sInstance, false);

            // Initialize Sample Banner Ads immediately SonsHub Mobile is opened
            MobileAds.initialize(sInstance, getResources().getString(R.string.sample_admob_app_id));
        }
        SystemClock.sleep(TimeUnit.SECONDS.toMillis(1));
    }

    /**
     * Returns the application context
     *
     * @return application context
     */
    public static Context getContext() {
        return sContext;
    }

    public static App getInstance() {
        return sInstance;
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

    }

    @Override
    public void onActivityStarted(Activity activity) {

    }

    @Override
    public void onActivityResumed(Activity activity) {

    }

    @Override
    public void onActivityPaused(Activity activity) {

    }

    @Override
    public void onActivityStopped(Activity activity) {

    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        Intent restartService = new Intent(sContext, MyFirebaseMessagingService.class);
        PendingIntent pendingIntent = PendingIntent.getService(sContext, 1, restartService, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.ELAPSED_REALTIME, 5000, pendingIntent);
    }
}
