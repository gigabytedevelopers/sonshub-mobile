package com.gigabytedevelopersinc.apps.sonshub.player.music

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import com.gigabytedevelopersinc.apps.sonshub.player.music.player.MediaPlayerHolder
import com.gigabytedevelopersinc.apps.sonshub.player.music.player.MusicNotificationManager

/**
 * Project - SonsHub
 * Created with Android Studio
 * Company: Gigabyte Developers
 * User: Emmanuel Nwokoma
 * Title: Founder and CEO
 * Day: Wednesday, 06
 * Month: February
 * Year: 2019
 * Date: 06 Feb, 2019
 * Time: 11:08 PM
 * Desc: PlayerService
 **/
class PlayerService : Service() {
    //service
    private val mIBinder = LocalBinder()
    var isRestoredFromPause = false

    //media player
    var mediaPlayerHolder: MediaPlayerHolder? = null
    lateinit var musicNotificationManager: MusicNotificationManager

    override fun onDestroy() {
        super.onDestroy()
        if (mediaPlayerHolder != null) {
            mediaPlayerHolder!!.registerNotificationActionsReceiver(false)
            mediaPlayerHolder!!.release()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        if (mediaPlayerHolder == null) {
            mediaPlayerHolder = MediaPlayerHolder(this)
            musicNotificationManager = MusicNotificationManager(this)
            mediaPlayerHolder!!.registerNotificationActionsReceiver(true)
        }
        return mIBinder
    }

    inner class LocalBinder : Binder() {
        val instance: PlayerService
            get() = this@PlayerService
    }
}