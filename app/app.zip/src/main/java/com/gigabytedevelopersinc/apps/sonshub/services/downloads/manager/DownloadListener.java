package com.gigabytedevelopersinc.apps.sonshub.services.downloads.manager;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.FragmentTransaction;
import com.gigabytedevelopersinc.apps.sonshub.R;
import com.gigabytedevelopersinc.apps.sonshub.fragments.SearchFrag;

import static android.content.Context.NOTIFICATION_SERVICE;

/**
 * @author Created by Emmanuel Nwokoma (Founder and CEO at Gigabyte Developers) on 11/25/2018
 **/
class DownloadListener {

    private DownloadService downloadService = null;
    private int lastProgress = 0;

    void setDownloadService(DownloadService downloadService) {
        this.downloadService = downloadService;
    }

    DownloadService getDownloadService() {
        return downloadService;
    }

    void onSuccess() {
        downloadService.stopForeground(true);
        sendDownloadNotification("Download Successful.", -1);
    }

    void onFailed() {
        downloadService.stopForeground(true);
        sendDownloadNotification("Download Failed.", -1);
    }

    void onPaused() {
        sendDownloadNotification("Download Paused.", lastProgress);
    }

    void onCanceled() {
        downloadService.stopForeground(true);
        sendDownloadNotification("Download Canceled.", -1);
    }

    void onUpdateDownloadProgress(int progress) {
        lastProgress = progress;
        sendDownloadNotification("Downloading...", lastProgress);
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                //TODO your background code
                // Thread sleep 0.2 seconds to let Pause, Continue and Cancel button in notification clickable.
                try {
                    Thread.sleep(1000);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }


    private void sendDownloadNotification(String title, int progress) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification notification = getDownloadNotificationOreo(title, progress);
            NotificationManager notificationManager = (NotificationManager)downloadService.getSystemService(NOTIFICATION_SERVICE);
            notificationManager.notify(1, notification);
        } else {
            Notification notification = getDownloadNotification(title, progress);
            NotificationManager notificationManager = (NotificationManager)downloadService.getSystemService(NOTIFICATION_SERVICE);
            notificationManager.notify(1, notification);
        }
    }

    Notification getDownloadNotification(String title, int progress) {
        Intent intent = new Intent();
        PendingIntent pendingIntent = PendingIntent.getActivity(downloadService, 0, intent, 0);
        NotificationCompat.Builder notifyBuilder = new NotificationCompat.Builder(downloadService);
        notifyBuilder.setSmallIcon(R.drawable.ic_file_download);

        Bitmap bitmap = BitmapFactory.decodeResource(downloadService.getResources(), R.mipmap.ic_launcher_round);
        notifyBuilder.setLargeIcon(bitmap);

        notifyBuilder.setContentIntent(pendingIntent);
        notifyBuilder.setContentTitle(title);
        //notifyBuilder.setFullScreenIntent(pendingIntent, true);

        if (progress > 0 && progress < 100) {
            StringBuilder stringBuffer = new StringBuilder();
            stringBuffer.append("Download progress ");
            stringBuffer.append(progress);
            stringBuffer.append("%");

            notifyBuilder.setContentText("Download progress " + progress + "%");
            notifyBuilder.setProgress(100, progress, false);

            // Add Pause download button intent in notification.
            Intent pauseDownloadIntent = new Intent(getDownloadService(), DownloadService.class);
            pauseDownloadIntent.setAction(DownloadService.ACTION_PAUSE_DOWNLOAD);
            PendingIntent pauseDownloadPendingIntent = PendingIntent.getService(getDownloadService(), 0, pauseDownloadIntent, 0);
            NotificationCompat.Action pauseDownloadAction = new NotificationCompat.Action(0, "Pause", pauseDownloadPendingIntent);
            notifyBuilder.addAction(pauseDownloadAction);

            // Add Continue download button intent in notification.
            Intent continueDownloadIntent = new Intent(getDownloadService(), DownloadService.class);
            continueDownloadIntent.setAction(DownloadService.ACTION_CONTINUE_DOWNLOAD);
            PendingIntent continueDownloadPendingIntent = PendingIntent.getService(getDownloadService(), 0, continueDownloadIntent, 0);
            NotificationCompat.Action continueDownloadAction = new NotificationCompat.Action(0, "Continue", continueDownloadPendingIntent);
            notifyBuilder.addAction(continueDownloadAction);

            // Add Cancel download button intent in notification.
            Intent cancelDownloadIntent = new Intent(getDownloadService(), DownloadService.class);
            cancelDownloadIntent.setAction(DownloadService.ACTION_CANCEL_DOWNLOAD);
            PendingIntent cancelDownloadPendingIntent = PendingIntent.getService(getDownloadService(), 0, cancelDownloadIntent, 0);
            NotificationCompat.Action cancelDownloadAction = new NotificationCompat.Action(0, "Cancel", cancelDownloadPendingIntent);
            notifyBuilder.addAction(cancelDownloadAction);
        }
        return notifyBuilder.build();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    Notification getDownloadNotificationOreo(String title, int progress) {
        Intent intent = new Intent();
        PendingIntent pendingIntent = PendingIntent.getActivity(downloadService, 0, intent, 0);

        String NOTIFICATION_CHANNEL_ID = "sonshubNotificationsChannel";
        String NOTIFICATION_CHANNEL_NAME = "sonshubNotificationsService";
        NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, NOTIFICATION_CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
        channel.setLightColor(Color.BLUE);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        NotificationManager manager = (NotificationManager) downloadService.getSystemService(Context.NOTIFICATION_SERVICE);
        assert manager != null;
        manager.createNotificationChannel(channel);
        NotificationCompat.Builder notifyBuilder = new NotificationCompat.Builder(downloadService, NOTIFICATION_CHANNEL_ID);

        notifyBuilder.setSmallIcon(R.drawable.ic_file_download);

        Bitmap bitmap = BitmapFactory.decodeResource(downloadService.getResources(), R.mipmap.ic_launcher_round);
        notifyBuilder.setLargeIcon(bitmap);

        notifyBuilder.setContentIntent(pendingIntent);
        notifyBuilder.setContentTitle(title);
        notifyBuilder.setFullScreenIntent(pendingIntent, false);
        notifyBuilder.setChannelId(NOTIFICATION_CHANNEL_ID);

        if (progress > 0 && progress < 100) {
            StringBuilder stringBuffer = new StringBuilder();
            stringBuffer.append("Download progress ");
            stringBuffer.append(progress);
            stringBuffer.append("%");

            notifyBuilder.setContentText("Download progress " + progress + "%");

            notifyBuilder.setOngoing(true);
            notifyBuilder.setAutoCancel(false);
            notifyBuilder.setPriority(NotificationManager.IMPORTANCE_MAX);
            notifyBuilder.setCategory(Notification.CATEGORY_SERVICE);

            notifyBuilder.setProgress(100, progress, true);

            // Add Pause download button intent in notification.
            Intent pauseDownloadIntent = new Intent(getDownloadService(), DownloadService.class);
            pauseDownloadIntent.setAction(DownloadService.ACTION_PAUSE_DOWNLOAD);
            PendingIntent pauseDownloadPendingIntent = PendingIntent.getService(getDownloadService(), 0, pauseDownloadIntent, 0);
            NotificationCompat.Action pauseDownloadAction = new NotificationCompat.Action(0, "Pause", pauseDownloadPendingIntent);
            notifyBuilder.addAction(pauseDownloadAction);

            // Add Continue download button intent in notification.
            Intent continueDownloadIntent = new Intent(getDownloadService(), DownloadService.class);
            continueDownloadIntent.setAction(DownloadService.ACTION_CONTINUE_DOWNLOAD);
            PendingIntent continueDownloadPendingIntent = PendingIntent.getService(getDownloadService(), 0, continueDownloadIntent, 0);
            NotificationCompat.Action continueDownloadAction = new NotificationCompat.Action(0, "Continue", continueDownloadPendingIntent);
            notifyBuilder.addAction(continueDownloadAction);

            // Add Cancel download button intent in notification.
            Intent cancelDownloadIntent = new Intent(getDownloadService(), DownloadService.class);
            cancelDownloadIntent.setAction(DownloadService.ACTION_CANCEL_DOWNLOAD);
            PendingIntent cancelDownloadPendingIntent = PendingIntent.getService(getDownloadService(), 0, cancelDownloadIntent, 0);
            NotificationCompat.Action cancelDownloadAction = new NotificationCompat.Action(0, "Cancel", cancelDownloadPendingIntent);
            notifyBuilder.addAction(cancelDownloadAction);
        }/* else if (progress == 100) {
            notifyBuilder.setOngoing(false);
            notifyBuilder.setAutoCancel(true);
            notifyBuilder.setPriority(NotificationManager.IMPORTANCE_MIN);
            notifyBuilder.setCategory(Notification.CATEGORY_SERVICE);

            notifyBuilder.setProgress(0, 0, false);
        }*/
        return notifyBuilder.build();
    }
}
