package com.gigabytedevelopersinc.apps.sonshub.activities;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.app.SearchManager;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.Html;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.browser.customtabs.CustomTabsIntent;
import com.bumptech.glide.GenericTransitionOptions;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.gigabytedevelopersinc.apps.sonshub.player.music.MusicMainActivity;
import com.gigabytedevelopersinc.apps.sonshub.ui.ExpandableLayout;
import com.gigabytedevelopersinc.apps.sonshub.utils.misc.IndividualUser;
import com.google.android.exoplayer2.*;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.navigation.NavigationView;
import androidx.fragment.app.FragmentTransaction;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.*;
import android.widget.*;
import com.gigabytedevelopersinc.apps.sonshub.BuildConfig;
import com.gigabytedevelopersinc.apps.sonshub.R;
import com.gigabytedevelopersinc.apps.sonshub.fragments.AboutFragment;
import com.gigabytedevelopersinc.apps.sonshub.fragments.HomeFragment;
import com.gigabytedevelopersinc.apps.sonshub.fragments.SearchFrag;
import com.gigabytedevelopersinc.apps.sonshub.fragments.gist.GistFragment;
import com.gigabytedevelopersinc.apps.sonshub.fragments.music.MusicFragment;
import com.gigabytedevelopersinc.apps.sonshub.fragments.videos.VideosFragment;
import com.gigabytedevelopersinc.apps.sonshub.fragments.wordoffaith.WordOfFaithFragment;
import com.gigabytedevelopersinc.apps.sonshub.services.downloads.manager.DownloadBinder;
import com.gigabytedevelopersinc.apps.sonshub.services.downloads.manager.DownloadService;
import com.gigabytedevelopersinc.apps.sonshub.utils.NotificationUtil;
import com.gigabytedevelopersinc.apps.sonshub.utils.TinyDb;
import com.gigabytedevelopersinc.apps.sonshub.utils.misc.Configs;
import com.github.javiersantos.appupdater.AppUpdater;
import com.github.javiersantos.appupdater.AppUpdaterUtils;
import com.github.javiersantos.appupdater.enums.AppUpdaterError;
import com.github.javiersantos.appupdater.enums.UpdateFrom;
import com.github.javiersantos.appupdater.objects.Update;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.database.*;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.leinardi.android.speeddial.SpeedDialView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import saschpe.android.customtabs.CustomTabsHelper;
import saschpe.android.customtabs.WebViewFallback;

import java.io.File;
import java.lang.Process;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.gigabytedevelopersinc.apps.sonshub.App.getContext;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawerLayout;
    public static Toolbar toolbar;
    public static DownloadBinder downloadBinder = null;
    private boolean haveConnectedWifi = false;
    private boolean haveConnectedMobile = false;
    private TinyDb tinyDb;
    private SearchView searchView;
    private RelativeLayout searchLayout;
    boolean doubleBackToExitPressedOnce = false;
    public static PlayerView playerView;
    public static SimpleExoPlayer player;

    // Ads (Google)
    public static InterstitialAd sonshubInterstitialAd;

    private static boolean isTelevision;
    private static MainActivity sonshubAppInstance;

    private BroadcastReceiver sonshubNotificaticationBroadcastReceiver, receiver;
    private AppUpdater appUpdater;
    private AppUpdaterUtils appUpdaterUtils;
    private long enqueue;
    private DownloadManager dm;
    boolean isDeleted;
    private File file;
    public static int currentWindow;
    public static long playBackPosition;
    public static boolean playWhenReady = false;
    private TinyDb tinydb;
    public  static LinearLayout streamLayout;
    public static ImageView imageStreamArt;
    public static TextView streamTitle;
    public static boolean isPreparing;
    public static AudioManager mAudioManager;
    public static boolean mAudioFocusGranted = false;
    public static AudioManager.OnAudioFocusChangeListener afChangeListener;
    public final static Object mFocusLock = new Object();
    public static AudioAttributes mAudioAttributes;
    public static AudioFocusRequest mAudioFocusRequest;
    public static int focusRequest;
    public static boolean mPlaybackDelayed,mPlaybackNowAuthorized;
    public static String searchQuery;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            downloadBinder = (DownloadBinder)service;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    @SuppressLint({"InflateParams", "HardwareIds"})
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TrackSelection.Factory adaptiveTrackSelectionFactory =
                new AdaptiveTrackSelection.Factory(new DefaultBandwidthMeter());
        playerView = findViewById(R.id.audio_view);
        player = ExoPlayerFactory.newSimpleInstance(this,
                new DefaultRenderersFactory(this),
                new DefaultTrackSelector(adaptiveTrackSelectionFactory),
                new DefaultLoadControl());
        tinyDb = new TinyDb(MainActivity.this);
        playerView.setControllerHideOnTouch(false);

        mAudioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);

//Setting the audio focus listener
        afChangeListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                switch (focusChange) {
                    case AudioManager.AUDIOFOCUS_GAIN:
                        player.setPlayWhenReady(true);
                        break;
                    case AudioManager.AUDIOFOCUS_GAIN_TRANSIENT:
                        player.setPlayWhenReady(false);
                        break;
                    case AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK:
                        player.setPlayWhenReady(false);
                        break;
                    case AudioManager.AUDIOFOCUS_LOSS:
                        player.setPlayWhenReady(false);
                        break;
                    case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                        player.setPlayWhenReady(false);
                        break;
                    case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:

                    break;
                    case AudioManager.AUDIOFOCUS_REQUEST_FAILED:
                        
                    break;
                    default:
                        //
                }
            }
        };

        //This is a check for different android versions to handle audio focus differently
        if (Build.VERSION.SDK_INT >= 26){
            mAudioManager = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
             mAudioAttributes =
                    new AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build();
             mAudioFocusRequest =
                    new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(mAudioAttributes)
                            .setAcceptsDelayedFocusGain(true)
                            .setOnAudioFocusChangeListener(afChangeListener)
                            .build();

            mPlaybackDelayed = false;
            mPlaybackNowAuthorized = false;
            focusRequest = mAudioManager.requestAudioFocus(mAudioFocusRequest);

            synchronized(mFocusLock){
                switch (focusRequest) {
                    case AudioManager.AUDIOFOCUS_REQUEST_FAILED:
                        mPlaybackNowAuthorized = false;
                        break;
                    case AudioManager.AUDIOFOCUS_REQUEST_GRANTED:
                        mPlaybackNowAuthorized = true;
                        initializePlayer(this, player, playerView, playWhenReady, playBackPosition, currentWindow, tinyDb.getString("downloadLink"));
                        break;
                    case AudioManager.AUDIOFOCUS_REQUEST_DELAYED:
                        mPlaybackDelayed = true;
                        mPlaybackNowAuthorized = false;

                }
            }

        } else {
            if (requestAudioFocus()){
                initializePlayer(this, player, playerView, playWhenReady, playBackPosition, currentWindow, tinyDb.getString("downloadLink"));

            }
        }
        sonshubAppInstance = this;
        checkForUpdate();


        ImageView toggleStreamLayout = findViewById(R.id.toggle);
        LinearLayout toggleDivider = findViewById(R.id.toggleDivider);
        toggleStreamLayout.setImageResource(R.drawable.ic_toggle_close);
        ExpandableLayout expandableLayout = findViewById(R.id.expandable_layout);
        toggleStreamLayout.setOnClickListener(v -> {
            //expandableLayout.toggle();
            if (expandableLayout.isExpanded()) {
                toggleStreamLayout.setImageResource(R.drawable.ic_toggle_open);
                toggleDivider.setVisibility(View.VISIBLE);
                expandableLayout.collapse();
            } else {
                toggleStreamLayout.setImageResource(R.drawable.ic_toggle_close);
                toggleDivider.setVisibility(View.GONE);
                expandableLayout.expand();
            }
        });
        expandableLayout.setOnExpansionUpdateListener(new ExpandableLayout.OnExpansionUpdateListener() {
            @Override
            public void onExpansionUpdate(float expansionFraction, int state) {
                Log.d("ExpandableLayout", "State: " + state);
                //toggleStreamLayout.setRotation(expansionFraction * 180);
            }
        });

        streamLayout = findViewById(R.id.stream_layout);
        imageStreamArt = findViewById(R.id.image_stream_art);
        streamTitle = findViewById(R.id.stream_title);
        String imageLink = tinyDb.getString("details_image_link");
        String titleString = tinyDb.getString("music_title");
        System.out.println("Title String " + titleString);

        Glide.with(this)
                .load(imageLink)
                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                .into(imageStreamArt);

        streamTitle.setText(Html.fromHtml(titleString), TextView.BufferType.SPANNABLE);

        if (haveNetworkConnection()) {
            checkNetworkState();
        } else {
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
            final View generalNoticeView = LayoutInflater.from(this).inflate(R.layout.general_notice, null);

            TextView generalNoticeTitle = generalNoticeView.findViewById(R.id.warning);
            TextView generalNoticeText = generalNoticeView.findViewById(R.id.generalNoticeText);
            ImageView generalNoticeImg = generalNoticeView.findViewById(R.id.warningImg);
            Button cancelButton = generalNoticeView.findViewById(R.id.cancelButton);
            Button continueButton = generalNoticeView.findViewById(R.id.continueButton);
            Button optionButton = generalNoticeView.findViewById(R.id.optionButton);

            generalNoticeText.setText("Hello, We've detected a lack of internet connectivity on your device.\nTo avoid some difficulties using SonsHub Mobile, kindly turn on your Internet Connection.");
            cancelButton.setVisibility(View.GONE);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            continueButton.setLayoutParams(layoutParams);
            continueButton.setText(R.string.continue_without_internet);
            (generalNoticeView.findViewById(R.id.continueButton)).setOnClickListener(v -> bottomSheetDialog.dismiss());
            bottomSheetDialog.setCancelable(false);
            bottomSheetDialog.setContentView(generalNoticeView);
            bottomSheetDialog.show();
        }

        // Register Broadcast Receiver for Custom Notifications from Firebase
        sonshubNotificaticationBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Objects.requireNonNull(intent.getAction()).equals(Configs.REGISTRATION_COMPLETE)) {
                    // Google Cloud Messaging (GCM) successfully registered
                    // now subscribe to `global` topic to receive app wide notifications
                    FirebaseMessaging.getInstance().subscribeToTopic(Configs.TOPIC_GLOBAL);
                } else {
                    FirebaseMessaging.getInstance().subscribeToTopic(Configs.TOPIC_GLOBAL);
                }
            }
        };

        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(this, instanceIdResult -> {
            String token = instanceIdResult.getToken();
            String androidId = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
            String device = Build.DEVICE;
            String deviceModel = Build.MODEL;
            String deviceManufacturer = Build.MANUFACTURER;
            String deviceBrand = Build.BRAND;
            String userDeviceName = Build.BRAND + " " + Build.MODEL;
            String androidOS = Build.DISPLAY;
            String androidVersion = "Android " + Build.VERSION.RELEASE;
            String appVersion = BuildConfig.VERSION_NAME;
            int appVersionCode = BuildConfig.VERSION_CODE;
            Log.d("FCM_TOKEN", token);

            DatabaseReference sonshubDatabase = FirebaseDatabase.getInstance().getReference("users");
            String userId = sonshubDatabase.push().getKey();
            FirebaseMessaging.getInstance().subscribeToTopic(Configs.TOPIC_GLOBAL);

            sonshubDatabase.orderByChild("token").equalTo(token).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    //IndividualUser user = dataSnapshot.getValue(IndividualUser.class);
                    // creating user object
                    IndividualUser user = new IndividualUser(androidId,
                            token,
                            device,
                            deviceModel,
                            deviceManufacturer,
                            deviceBrand,
                            userDeviceName,
                            androidOS,
                            androidVersion,
                            appVersion,
                            appVersionCode
                    );
                    // pushing user to 'users' node using the userId
                    assert userId != null;
                    Log.d("Device_Info", String.valueOf(user));

                    /*for (DataSnapshot userSnapshot: dataSnapshot.getChildren()) {
                        String remoteToken = userSnapshot.child("token").getValue(String.class);
                        assert remoteToken != null;
                        if (!remoteToken.equals(token)) {
                            sonshubDatabase.child(userId).child("token").setValue(token);
                        }
                        //Log.i(TAG, userSnapshot.child("token").getValue(String.class);
                    }*/

                    if (dataSnapshot.getChildrenCount() > 0) {
                        //user already exists (Never executed)
                        //Toast.makeText(MusicPlayerActivity.this, "Thank You", Toast.LENGTH_SHORT).show();
                    } else {
                        //user doesn't exists (Always executed)
                        sonshubDatabase.child(userId).setValue(user);
                    }

                    /*Log.d("USER_INFO", "Name: " + user.getName()
                            + ", Email: " + user.getEmail()
                            + ", AndroidID: " + user.getAndroidId()
                            + ", Token: " + user.getToken()
                            + ", Device: " + user.getUserDeviceName());*/

                    /*sonshubDatabase.child(userId).child("name").setValue(finalName);
                    sonshubDatabase.child(userId).child("email").setValue(finalEmail);
                    sonshubDatabase.child(userId).child("androidId").setValue(androidId);
                    sonshubDatabase.child(userId).child("token").setValue(token);
                    sonshubDatabase.child(userId).child("device").setValue(device);
                    sonshubDatabase.child(userId).child("deviceModel").setValue(deviceModel);
                    sonshubDatabase.child(userId).child("deviceManufacturer").setValue(deviceManufacturer);
                    sonshubDatabase.child(userId).child("deviceBrand").setValue(deviceBrand);
                    sonshubDatabase.child(userId).child("userDeviceName").setValue(userDeviceName);*/
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Failed to read value
                    Log.w("DatabaseError 101", "Failed to read value.", databaseError.toException());
                }
            });
        });
        //checkNetworkState();
        startAndBindDownloadService();

        // Prepare the interstitial Ad
        sonshubInterstitialAd = new InterstitialAd(getApplicationContext());
        // Insert the Ad Unit ID
        if (BuildConfig.DEBUG) {
            sonshubInterstitialAd.setAdUnitId(getString(R.string.interstitial_test_ads));
        } else {
            sonshubInterstitialAd.setAdUnitId(getString(R.string.interstitial_ads));
        }
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();
        // Load requested Ad
        sonshubInterstitialAd.loadAd(adRequest);
        isTelevision = Configs.isTelevision(this);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        tinyDb = new TinyDb(this);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_open, R.string.navigation_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        HomeFragment homeFragment = new HomeFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.parent_frame, homeFragment);
        toolbar.setTitle(R.string.nav_home);
        fragmentTransaction.commit();
        SpeedDialView contactUs = findViewById(R.id.speedDial);
        contactUs.setOnChangeListener(new SpeedDialView.OnChangeListener() {
            @Override
            public boolean onMainActionSelected() {
                // Call your main action here
                sendFeedback();
                return false; // true to keep the Speed Dial open
            }

            @Override
            public void onToggleChanged(boolean isOpen) {
                //Log.d(TAG, "Speed dial toggle state changed. Open = " + isOpen);
            }
        });
        // ATTENTION: This was auto-generated to handle app links.
        Intent appLinkIntent = getIntent();
        String appLinkAction = appLinkIntent.getAction();
        Uri appLinkData = appLinkIntent.getData();
    }

    public static void initializePlayer(Context context,SimpleExoPlayer player, PlayerView playerView,
                                        boolean playWhenReady, long playBackPosition,int currentWindow, String songLink) {

        playerView.setPlayer(player);

        isPreparing = true;
        player.setPlayWhenReady(playWhenReady);
        player.seekTo(currentWindow, playBackPosition);
//        if (songLink.isEmpty()){
//            songLink = tinyDb.getString("downloadLink");
//        }
        Uri uri = Uri.parse(songLink);
        MediaSource mediaSource = buildMediaSource(uri);
        player.prepare(mediaSource, true, false);

        player.addListener(new Player.EventListener() {
            @Override
            public void onTimelineChanged(Timeline timeline, Object manifest, int reason) {

            }

            @Override
            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

            }

            @Override
            public void onLoadingChanged(boolean isLoading) {

            }

            @Override
            public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
                playerView.setControllerHideOnTouch(false);
                if(isPreparing && playbackState == ExoPlayer.STATE_READY){
                    // this is accurate
                    isPreparing = false;
                }
            }

            @Override
            public void onRepeatModeChanged(int repeatMode) {

            }

            @Override
            public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {

            }

            @Override
            public void onPlayerError(ExoPlaybackException error) {

            }

            @Override
            public void onPositionDiscontinuity(int reason) {

            }

            @Override
            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {

            }

            @Override
            public void onSeekProcessed() {

            }
        });

    }

    @SuppressLint("InflateParams")
    public void fillBottomSheet(Context context, Pattern pattern, Matcher matcher, TinyDb tinyDb){
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Objects.requireNonNull(context));
        View detailsView = LayoutInflater.from(context).inflate(R.layout.details_bottomsheet, null);
        ImageView imageView = detailsView.findViewById(R.id.songImage);
        ImageView downloadBtn = detailsView.findViewById(R.id.download_button);
        ImageView streamBtn = detailsView.findViewById(R.id.stream_button);
        TextView songTitle = detailsView.findViewById(R.id.song_title);
        TextView songContent = detailsView.findViewById(R.id.content_view);
        Button button = detailsView.findViewById(R.id.web_button);
        LinearLayout backButton = detailsView.findViewById(R.id.back);

        backButton.setOnClickListener(v -> bottomSheetDialog.dismiss());
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(context.getResources().getColor(R.color.colorAccent));          // (no gradient)
        gd.setStroke(2, Color.BLACK);
        gd.setShape(GradientDrawable.OVAL);
        gd.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        gd.setGradientRadius(streamBtn.getWidth()/2);
        gd.setSize(50,50);
        streamBtn.setBackground(gd);
        downloadBtn.setBackground(gd);

        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setContentView(detailsView);
        bottomSheetDialog.show();
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setShowTitle(true);
        CustomTabsIntent customTabsIntent = builder.build();
        builder.setToolbarColor(context.getResources().getColor(R.color.colorPrimary));
        CustomTabsHelper.addKeepAliveExtra(context, customTabsIntent.intent);
        tinyDb = new TinyDb(context);

        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                //.addTestDevice("DED5E5589FE9B73E06F70486636F2945") // Tecno Camon C7
                .build();

        //This switch statement checks tiny db for each item clicked and know which specific genre was clicked to handle logic properly
        //THis switch statement different categories which are movies, music,news,featureimages,featured
        switch (tinyDb.getString("clicked")) {
            case "movies":
                streamBtn.setVisibility(View.GONE);
                downloadBtn.setVisibility(View.VISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("movieDetailsList"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");

                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
//                        contentView.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        tinyDb.putString("movie_title", title);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));
                        pattern = Pattern.compile("http.*?mp4");
                        matcher = pattern.matcher(content);
                        final Matcher matcher2= matcher;
                        if (matcher.find()){
                            //put the download link in tinydb for the exoplayer to pick up
                            tinyDb.putString("downloadLink", matcher.group(0));
                            downloadBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                if (sonshubInterstitialAd.isLoaded()){
                                    sonshubInterstitialAd.show();
                                    sonshubInterstitialAd.setAdListener(new AdListener(){
                                        @Override
                                        public void onAdClosed() {
                                            MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                            downloadFile(matcher2,context);
                                        }
                                    });
                                } else {
                                    downloadFile(matcher2,context);
                                    MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                }
                            });

                        } else {
                            downloadBtn.setOnClickListener(view -> Toast.makeText(context, "No Download Link Available at this time", Toast.LENGTH_SHORT).show());
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            //If it was music that was clicked
            case "music":
                downloadBtn.setVisibility(View.VISIBLE);
                streamBtn.setVisibility(View.VISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("musicDetailsList"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");
                        tinyDb.putString("details_image_link", imageUrl);
                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
//                        contentView.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        tinyDb.putString("music_title", title);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));

                        pattern = Pattern.compile("http.*?\\.mp3");
                        matcher = pattern.matcher(content);
                        final Matcher matcher2= matcher;
                        if (matcher.find()){
                            //put the download link in tinydb for the exoplayer to pick up
                            tinyDb.putString("downloadLink", matcher.group(0));

                            downloadBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                if (sonshubInterstitialAd.isLoaded()){
                                    sonshubInterstitialAd.show();
                                    sonshubInterstitialAd.setAdListener(new AdListener(){
                                        @Override
                                        public void onAdClosed() {
                                            sonshubInterstitialAd.loadAd(adRequest);
                                            downloadFile(matcher2,context);
                                        }
                                    });
                                } else {
                                    downloadFile(matcher2,context);
                                    MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                }
                            });

                            streamBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                Toast.makeText(context, "Loading Music...", Toast.LENGTH_SHORT).show();
                                if (player.getPlayWhenReady()){
                                    player.stop();
                                }
                                Glide.with(context)
                                        .load(imageUrl)
                                        .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                        .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                        .into(imageStreamArt);

                                streamTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);

                                if (!isPreparing){
                                    playWhenReady = true;
                                }

                                if (Build.VERSION.SDK_INT >= 26){
                                    mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                                    mAudioAttributes =
                                            new AudioAttributes.Builder()
                                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                                    .build();
                                    mAudioFocusRequest =
                                            new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                                                    .setAudioAttributes(mAudioAttributes)
                                                    .setAcceptsDelayedFocusGain(true)
                                                    .setOnAudioFocusChangeListener(afChangeListener)
                                                    .build();

                                    mPlaybackDelayed = false;
                                    mPlaybackNowAuthorized = false;
                                    focusRequest = mAudioManager.requestAudioFocus(mAudioFocusRequest);

                                    synchronized(mFocusLock){
                                        switch (focusRequest) {
                                            case AudioManager.AUDIOFOCUS_REQUEST_FAILED:
                                                mPlaybackNowAuthorized = false;
                                                break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_GRANTED:
                                                mPlaybackNowAuthorized = true;
                                                initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                        MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));                                                    break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_DELAYED:
                                                mPlaybackDelayed = true;
                                                mPlaybackNowAuthorized = false;

                                        }
                                    }
                                } else {
                                    if (MainActivity.requestAudioFocus()){
                                        MainActivity.initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));
                                    }
                                }

                            });
                        } else {
                            downloadBtn.setOnClickListener(view -> Toast.makeText(context, "No Download Link Available at this time", Toast.LENGTH_SHORT).show());

                            streamBtn.setOnClickListener(view -> Toast.makeText(context, "No Download Link Available at this time", Toast.LENGTH_SHORT).show());
                        }

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case "featured":
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("featuredDetailsList"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");

                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
//                        contentView.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));

                        pattern = Pattern.compile("http.*?\\.mp3");
                        matcher = pattern.matcher(content);
                        final Matcher matcher2= matcher;
                        //If the mp3 file is found meaning it's a featured music
                        if (matcher.find()){
                            //put the download link in tinydb for the exoplayer to pick up
                            tinyDb.putString("downloadLink", matcher.group(0));

                            downloadBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                if (MainActivity.sonshubInterstitialAd.isLoaded()){
                                    MainActivity.sonshubInterstitialAd.show();
                                    MainActivity.sonshubInterstitialAd.setAdListener(new AdListener(){
                                        @Override
                                        public void onAdClosed() {
                                            MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                            downloadFile(matcher2,context);
                                        }
                                    });
                                } else {
                                    downloadFile(matcher2,context);
                                    MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                }
                            });

                            streamBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                Toast.makeText(context, "Loading Music...", Toast.LENGTH_SHORT).show();
                                if (player.getPlayWhenReady()){
                                    player.stop();
                                }
                                Glide.with(context)
                                        .load(imageUrl)
                                        .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                        .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                        .into(imageStreamArt);

                                streamTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);

                                if (!MainActivity.isPreparing){
                                    MainActivity.playWhenReady = true;
                                }

                                if (Build.VERSION.SDK_INT >= 26){
                                    mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                                    mAudioAttributes =
                                            new AudioAttributes.Builder()
                                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                                    .build();
                                    mAudioFocusRequest =
                                            new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                                                    .setAudioAttributes(mAudioAttributes)
                                                    .setAcceptsDelayedFocusGain(true)
                                                    .setOnAudioFocusChangeListener(afChangeListener)
                                                    .build();

                                    mPlaybackDelayed = false;
                                    mPlaybackNowAuthorized = false;
                                    focusRequest = mAudioManager.requestAudioFocus(mAudioFocusRequest);

                                    synchronized(mFocusLock){
                                        switch (focusRequest) {
                                            case AudioManager.AUDIOFOCUS_REQUEST_FAILED:
                                                mPlaybackNowAuthorized = false;
                                                break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_GRANTED:
                                                mPlaybackNowAuthorized = true;
                                                initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                        MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));                                                    break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_DELAYED:
                                                mPlaybackDelayed = true;
                                                mPlaybackNowAuthorized = false;

                                        }
                                    }
                                } else {
                                    if (MainActivity.requestAudioFocus()){
                                        MainActivity.initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));
                                    }
                                }
                            });
                        } else {
                            downloadBtn.setOnClickListener(view -> Toast.makeText(context, "No Download Link Available at this time", Toast.LENGTH_SHORT).show());

                            streamBtn.setOnClickListener(view -> Toast.makeText(context, "No Download Link Available at this time", Toast.LENGTH_SHORT).show());
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case "news":
                streamBtn.setVisibility(View.GONE);
                downloadBtn.setVisibility(View.GONE);
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("newsDetailsList"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");

                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        songContent.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case "featuredimages":
                downloadBtn.setVisibility(View.VISIBLE);
                streamBtn.setVisibility(View.VISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("featuredimageslist"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");
                        tinyDb.putString("details_image_link", imageUrl);
                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
//                        contentView.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        tinyDb.putString("music_title", title);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));

                        //THis looks for a specific regex pattern (a link ending with mp3)
                        //If it is found then the user can download or stream the music
                        pattern = Pattern.compile("http.*?\\.mp3");
                        matcher = pattern.matcher(content);
                        final Matcher matcher2= matcher;
                        if (matcher.find()) {
                            //put the download link in tinydb for the exoplayer to pick up
                            tinyDb.putString("downloadLink", matcher.group(0));

                            downloadBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                if (MainActivity.sonshubInterstitialAd.isLoaded()){
                                    MainActivity.sonshubInterstitialAd.show();
                                    MainActivity.sonshubInterstitialAd.setAdListener(new AdListener(){
                                        @Override
                                        public void onAdClosed() {
                                            AdRequest adRequest1 = new AdRequest.Builder()
                                                    .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                                                    //.addTestDevice("DED5E5589FE9B73E06F70486636F2945") // Tecno Camon C7
                                                    .build();
                                            MainActivity.sonshubInterstitialAd.loadAd(adRequest1);
                                            downloadFile(matcher2,context);
                                        }
                                    });
                                } else {
                                    downloadFile(matcher2,context);
                                    MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                }
                            });

                            streamBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                Toast.makeText(context, "Loading Music...", Toast.LENGTH_SHORT).show();
                                if (player.getPlayWhenReady()){
                                    player.stop();
                                }
                                Glide.with(context)
                                        .load(imageUrl)
                                        .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                        .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                        .into(imageStreamArt);

                                streamTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);

                                if (!MainActivity.isPreparing){
                                    MainActivity.playWhenReady = true;
                                }

                                if (Build.VERSION.SDK_INT >= 26){
                                    mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                                    mAudioAttributes =
                                            new AudioAttributes.Builder()
                                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                                    .build();
                                    mAudioFocusRequest =
                                            new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                                                    .setAudioAttributes(mAudioAttributes)
                                                    .setAcceptsDelayedFocusGain(true)
                                                    .setOnAudioFocusChangeListener(afChangeListener)
                                                    .build();

                                    mPlaybackDelayed = false;
                                    mPlaybackNowAuthorized = false;
                                    focusRequest = mAudioManager.requestAudioFocus(mAudioFocusRequest);

                                    synchronized(mFocusLock){
                                        switch (focusRequest) {
                                            case AudioManager.AUDIOFOCUS_REQUEST_FAILED:
                                                mPlaybackNowAuthorized = false;
                                                break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_GRANTED:
                                                mPlaybackNowAuthorized = true;
                                                initializePlayer(MainActivity.getInstance(),player,playerView,playWhenReady,
                                                        playBackPosition,currentWindow,matcher2.group(0));                                                    break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_DELAYED:
                                                mPlaybackDelayed = true;
                                                mPlaybackNowAuthorized = false;

                                        }
                                    }
                                } else {
                                    if (MainActivity.requestAudioFocus()){
                                        MainActivity.initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));
                                    }
                                }
                            });
                        } else {
                            downloadBtn.setOnClickListener(view -> Toast.makeText(context, "No Download Link Available at this time", Toast.LENGTH_SHORT).show());

                            streamBtn.setOnClickListener(view -> Toast.makeText(context, "No Download Link Available at this time", Toast.LENGTH_SHORT).show());
                        }

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    @SuppressLint("InflateParams")
    public static void downloadFile(Matcher matcher,Context context){
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context);
        final View generalNoticeView = LayoutInflater.from(context).inflate(R.layout.general_notice, null);

        TextView generalNoticeTitle = generalNoticeView.findViewById(R.id.warning);
        TextView generalNoticeText = generalNoticeView.findViewById(R.id.generalNoticeText);
        ImageView generalNoticeImg = generalNoticeView.findViewById(R.id.warningImg);
        Button cancelButton = generalNoticeView.findViewById(R.id.cancelButton);
        Button continueButton = generalNoticeView.findViewById(R.id.continueButton);
        Button optionButton = generalNoticeView.findViewById(R.id.optionButton);

        String downloadFileUrl = matcher.group(0);
        String fileName = downloadFileUrl.substring(downloadFileUrl.lastIndexOf('/') + 1);
        if (need2Download(fileName)){
            MainActivity.downloadBinder.startDownload(downloadFileUrl, 0);
        } else {
            continueButton.setOnClickListener(v -> {
                File basePathMp3 = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Music");
                File basePathVideo = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Videos");

                File fullPathMp3 = new File(basePathMp3, fileName);
                File fullPathVideo = new File(basePathVideo, fileName);
                if (fileName.toLowerCase().endsWith(".mp3")) {
                    fullPathMp3.delete();
                } else if (fileName.toLowerCase().endsWith(".mp4")) {
                    fullPathVideo.delete();
                } else {
                    Toast.makeText(context, "We encountered an error ;(", Toast.LENGTH_LONG).show();
                }
                MainActivity.downloadBinder.startDownload(downloadFileUrl, 0);
                bottomSheetDialog.dismiss();
            });
            cancelButton.setOnClickListener(v -> bottomSheetDialog.dismiss());
            bottomSheetDialog.setCancelable(false);
            bottomSheetDialog.setContentView(generalNoticeView);
            bottomSheetDialog.show();
        }

    }

    public static boolean need2Download(String fileName) {
        File basePathMp3 = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Music");
        File basePathVideo = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Videos");

        File fullPathMp3 = new File(basePathMp3, fileName);
        File fullPathVideo = new File(basePathVideo, fileName);

        /*if (fullPathMp3.exists() || fullPathVideo.exists()) {
            return false;
        }*/
        return !fullPathMp3.exists() && !fullPathVideo.exists();
    }


    public static MediaSource buildMediaSource(Uri uri) {
        return new ExtractorMediaSource.Factory(
                new DefaultHttpDataSourceFactory("exoplayer-codelab")).
                createMediaSource(uri);

    }

    public static boolean requestAudioFocus() {
        if (!mAudioFocusGranted) {
            // Request audio focus for play back
            int result = mAudioManager.requestAudioFocus(afChangeListener,
                    // Use the music stream.
                    AudioManager.STREAM_MUSIC,
                    // Request permanent focus.
                    AudioManager.AUDIOFOCUS_GAIN);

            if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                mAudioFocusGranted = true;
            } else {
                // FAILED
                System.out.println("Failed to get audio focus player permission");
            }
        }
        return mAudioFocusGranted;
    }

    @SuppressLint("InflateParams")
    public void checkForUpdate() {
        appUpdaterUtils = new AppUpdaterUtils(this)
                .setUpdateFrom(UpdateFrom.JSON)
                .setUpdateJSON("https://gigabytedevelopersinc.com/apps/sonshub/update/update.json")
                .withListener(new AppUpdaterUtils.UpdateListener() {
                    @Override
                    public void onSuccess(Update update, Boolean isUpdateAvailable) {
                        Log.d("Latest Version", update.getLatestVersion());
                        Log.d("Latest Version Code", String.valueOf(update.getLatestVersionCode()));
                        Log.d("Release notes", update.getReleaseNotes());
                        Log.d("URL", String.valueOf(update.getUrlToDownload()));
                        Log.d("Is update available?", Boolean.toString(isUpdateAvailable));

                        if ((update.getLatestVersionCode() > BuildConfig.VERSION_CODE) || isUpdateAvailable) {
                            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(MainActivity.this);
                            final View updateNoticeView = LayoutInflater.from(MainActivity.this).inflate(R.layout.updater_notice, null);

                            TextView updateNoticeText = updateNoticeView.findViewById(R.id.updateNoticeText);
                            Button continueButton = updateNoticeView.findViewById(R.id.update_continue);
                            LinearLayout closeButton = updateNoticeView.findViewById(R.id.close);
                            updateNoticeText.setText(update.getReleaseNotes());
                            continueButton.setOnClickListener(v -> {
                                bottomSheetDialog.dismiss();
                                BottomSheetDialog bottomSheetDialogConfirm = new BottomSheetDialog(MainActivity.this);
                                final View generalNoticeViewConfirm = LayoutInflater.from(MainActivity.this).inflate(R.layout.general_notice, null);

                                TextView generalNoticeTextConfirm = generalNoticeViewConfirm.findViewById(R.id.generalNoticeText);
                                Button cancelButtonConfirm = generalNoticeViewConfirm.findViewById(R.id.cancelButton);
                                Button continueButtonConfirm = generalNoticeViewConfirm.findViewById(R.id.continueButton);
                                Button optionButtonConfirm = generalNoticeViewConfirm.findViewById(R.id.optionButton);

                                generalNoticeTextConfirm.setText("Did you install your current version of SonsHub Mobile from the Google Play Store? If yes, use the first button to update from Play Store.\n\nDid you install your current version of SonsHub Mobile elsewhere (not from Play Store)? If yes, use the second button to manually download the latest update from our Server.");
                                cancelButtonConfirm.setVisibility(View.GONE);
                                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                                continueButtonConfirm.setLayoutParams(layoutParams);
                                continueButtonConfirm.setText(getString(R.string.update_server));
                                optionButtonConfirm.setVisibility(View.VISIBLE);
                                optionButtonConfirm.setText(getString(R.string.update_play_store));
                                continueButtonConfirm.setOnClickListener(v1 -> {
                                    dm = (DownloadManager) getContext().getSystemService(DOWNLOAD_SERVICE);
                                    Toast.makeText(getContext(), "App Update Downloading... Please Wait", Toast.LENGTH_LONG).show();
                                    File file = new File(Environment.getExternalStorageDirectory()
                                            + "/SonsHub" + "/AppUpdate" + "/sonshub_mobile.apk");
                                    if (file.exists()) {
                                        isDeleted = file.delete();
                                        deleteAndInstall();
                                    } else {
                                        firstTimeInstall();
                                    }
                                    bottomSheetDialog.dismiss();
                                });
                                optionButtonConfirm.setOnClickListener(v1 -> {
                                    Intent rate = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.gigabytedevelopersinc.apps.sonshub"));
                                    startActivity(rate);
                                    bottomSheetDialog.dismiss();
                                });
                                bottomSheetDialogConfirm.setCancelable(true);
                                bottomSheetDialogConfirm.setContentView(generalNoticeViewConfirm);
                                if (!MainActivity.this.isFinishing()) {
                                    bottomSheetDialogConfirm.show();
                                }
                            });
                            closeButton.setOnClickListener(v -> bottomSheetDialog.dismiss());
                            bottomSheetDialog.setCancelable(false);
                            bottomSheetDialog.setContentView(updateNoticeView);
                            if (!MainActivity.this.isFinishing()) {
                                bottomSheetDialog.show();
                            }
                        } else {
                            // No Update
                            // TODO: Do something when there is no update
                        }
                    }

                    @Override
                    public void onFailed(AppUpdaterError appUpdaterError) {
                        Log.d("AppUpdater Error", "Something went wrong");
                    }
                });
        appUpdaterUtils.start();
    }

    private void firstTimeInstall() {
        Log.d("May be 1st Update:","OR deleted from folder" );
        downloadAndInstall();
    }

    public void releasePlayer() {
        if (player != null) {
            playBackPosition = player.getCurrentPosition();
            currentWindow = player.getCurrentWindowIndex();
            playWhenReady = player.getPlayWhenReady();
            player.release();
            mAudioManager.abandonAudioFocus(afChangeListener);
        }
    }

    private void deleteAndInstall() {
        if (isDeleted) {
            Log.d("Deleted Existed file:", String.valueOf(true));
            downloadAndInstall();

        } else {
            Log.d("NOT DELETED:", String.valueOf(false));
            Toast.makeText(this, "Error in Updating...Please try Later", Toast.LENGTH_LONG).show();
            //bottomSheetDialog.dismiss();
        }
    }

    private void downloadAndInstall() {
        File sdrFolder = new File(Environment.getExternalStorageDirectory()
                + "/SonsHub" + "/AppUpdate");
        String path = Environment.getExternalStorageDirectory()
                + "/SonsHub/" + "AppUpdate/" + "sonshub_mobile";

        boolean success = false;
        if (!sdrFolder.exists()) {
            success = sdrFolder.mkdir();
        }
        if (!success) {
            String PATH = Environment.getExternalStorageDirectory()
                    + "/SonsHub/" + "AppUpdate/";
            file = new File(PATH);
            file.mkdirs();
        } else {
            String PATH = Environment.getExternalStorageDirectory()
                    + "/SonsHub/" + "AppUpdate/";
            file = new File(PATH);
            file.mkdirs();
        }

        String downloadLink;
        if (BuildConfig.DEBUG) {
            downloadLink = "https://gigabytedevelopersinc.com/apps/sonshub/update/SonsHub-debug-" + BuildConfig.VERSION_NAME + ".apk";
        } else {
            downloadLink = "https://gigabytedevelopersinc.com/apps/sonshub/update/SonsHub-release-" + BuildConfig.VERSION_NAME + ".apk";
        }
        DownloadManager.Request request = new DownloadManager.Request(
                Uri.parse(downloadLink));
        request.setDestinationUri(Uri.fromFile(new File(Environment.getExternalStorageDirectory()
                + "/SonsHub" + "/AppUpdate" + "/sonshub_mobile.apk")));

        enqueue = dm.enqueue(request);

        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                    Toast.makeText(MainActivity.this, "Download Completed", Toast.LENGTH_LONG).show();

                    long downloadId = intent.getLongExtra(
                            DownloadManager.EXTRA_DOWNLOAD_ID, 0);
                    DownloadManager.Query query = new DownloadManager.Query();
                    query.setFilterById(enqueue);
                    Cursor c = dm.query(query);
                    if (c.moveToFirst()) {
                        int columnIndex = c.getColumnIndex(DownloadManager.COLUMN_STATUS);
                        if (DownloadManager.STATUS_SUCCESSFUL == c.getInt(columnIndex)) {
                            String uriString = c.getString(c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));

                            Log.d("ainfo", uriString);

                            if(downloadId == c.getInt(0)) {
                                Log.d("DOWNLOAD PATH:", c.getString(c.getColumnIndex("local_uri")));


                                Log.d("isRooted:",String.valueOf(isRooted()));
                                if (!isRooted()) {
                                    //if your device is not rooted
                                    Intent intent_install = new Intent(Intent.ACTION_VIEW);
                                    intent_install.setDataAndType(Uri.fromFile(new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/AppUpdate/" + "sonshub_mobile.apk")), "application/vnd.android.package-archive");
                                    Log.d("phone path",Environment.getExternalStorageDirectory() + "/SonsHub" + "/AppUpdate/" + "sonshub_mobile.apk");
                                    startActivity(intent_install);
                                    Toast.makeText(MainActivity.this, "App Installing", Toast.LENGTH_LONG).show();
                                } else {
                                    //if your device is rooted then you can install or update app in background directly
                                    Toast.makeText(MainActivity.this, "App Installing... Please Wait", Toast.LENGTH_LONG).show();
                                    File file = new File(path);
                                    Log.d("IN INSTALLER:", path);
                                    if(file.exists()){
                                        try {
                                            String command;
                                            Log.d("IN File exists:",path);

                                            command = "pm install -r " + path;
                                            Log.d("COMMAND:",command);
                                            Process proc = Runtime.getRuntime().exec(new String[] { "su", "-c", command });
                                            proc.waitFor();
                                            Toast.makeText(MainActivity.this, "App Installed Successfully", Toast.LENGTH_LONG).show();

                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    c.close();
                }
            }
        };

        this.registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
    }

    private static boolean isRooted() {
        return findBinary("su");
    }

    public static boolean findBinary(String binaryName) {
        boolean found = false;
        if (!found) {
            String[] places = {"/sbin/", "/system/bin/", "/system/xbin/", "/data/local/xbin/","/data/local/bin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/"};
            for (String where : places) {
                if ( new File( where + binaryName ).exists() ) {
                    found = true;
                    break;
                }
            }
        }
        return found;
    }

    public static synchronized MainActivity getInstance() {
        return sonshubAppInstance;
    }

    public static boolean isTelevision() {
        return isTelevision;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_home,menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.nav_search)
                .getActionView();
        searchView.setSearchableInfo(searchManager
                .getSearchableInfo(getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SearchFrag searchFrag = new SearchFrag();
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.parent_frame, searchFrag);
                fragmentTransaction.commit();
            }
        });
        // listening to search query text change
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // filter recycler view when query submitted
//                adapter.getFilter().filter(query);
//                if (query.length() > 1){
//                    SearchFrag searchFrag = new SearchFrag();
//                    searchQuery = query;
//                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
//                    fragmentTransaction.replace(R.id.parent_frame, searchFrag);
//                    fragmentTransaction.commit();
//
//                } else {
//                    HomeFragment homeFragment = new HomeFragment();
//                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
//                    fragmentTransaction.replace(R.id.parent_frame, homeFragment);
//                    toolbar.setTitle(R.string.nav_home);
//                    fragmentTransaction.commit();
//                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                // filter recycler view when text is changed
                if (query.length() > 1){
                    AsyncTask.execute(new Runnable() {
                        @Override
                        public void run() {
                            //TODO your background code
                            searchQuery = query;
                            SearchFrag searchFrag = new SearchFrag();
                            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                            fragmentTransaction.replace(R.id.parent_frame, searchFrag);
                            fragmentTransaction.commitAllowingStateLoss();
                        }
                    });

//                    searchFrag.getSearchResults(query,MusicPlayerActivity.this);
                } else {
                    HomeFragment homeFragment = new HomeFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.parent_frame, homeFragment);
                    toolbar.setTitle(R.string.nav_home);
                    fragmentTransaction.commit();

                }

                return false;
            }
        });
        return true;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                //.addTestDevice("DED5E5589FE9B73E06F70486636F2945") // Tecno Camon C7
                .build();

        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(MainActivity.this);
        final View optionsView = LayoutInflater.from(MainActivity.this).inflate(R.layout.options_sheet, null);

        LinearLayout optionShare = optionsView.findViewById(R.id.shareSonsHub);
        LinearLayout optionRate = optionsView.findViewById(R.id.rateSonsHub);
        LinearLayout close = optionsView.findViewById(R.id.back);
        switch (item.getItemId()) {
            case R.id.nav_search:
                return true;

            case R.id.nav_download:
                if (sonshubInterstitialAd.isLoaded()) {
                    sonshubInterstitialAd.show();
                    sonshubInterstitialAd.setAdListener(new AdListener() {
                        public void onAdClosed() {
                            sonshubInterstitialAd.loadAd(adRequest);
                            startActivity(new Intent(MainActivity.this, DownloadActivity.class));
                        }
                    });
                } else {
                    startActivity(new Intent(this, DownloadActivity.class));
                    sonshubInterstitialAd.loadAd(adRequest);
                }
                return true;

            case R.id.nav_sub_menu:
                sonshubInterstitialAd.loadAd(adRequest);
                // For Rating SonsHub Mobile
                Intent rateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.gigabytedevelopersinc.apps.sonshub"));

                // For Sharing SonsHub Mobile
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                String shareSub = "\nDownload SonsHub Mobile App for your latest Gospel Music, Sermons, Articles and all round Christian Entertainment.\n\n";
                shareSub = shareSub + "https://bit.ly/DownloadSonsHubMobile \n\n";
                share.putExtra(Intent.EXTRA_SUBJECT, "Check out SonsHub Mobile");
                share.putExtra(Intent.EXTRA_TEXT, shareSub);
                optionShare.setOnClickListener(v -> startActivity(Intent.createChooser(share, "Share SonsHub Mobile using")));
                optionRate.setOnClickListener(v -> startActivity(rateIntent));
                close.setOnClickListener(v -> bottomSheetDialog.dismiss());
                bottomSheetDialog.setCancelable(false);
                bottomSheetDialog.setContentView(optionsView);
                bottomSheetDialog.show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
//        if (drawerLayout.isDrawerOpen(drawerLayout)){
//            drawerLayout.closeDrawers();
//        } else {
//            finish();
//        }
//        super.onBackPressed();
    }

    @SuppressLint("SetTextI18n")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();
        drawerLayout = findViewById(R.id.drawer_layout);
        if (id == R.id.nav_home) {
            HomeFragment homeFragment = new HomeFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.parent_frame, homeFragment);
            toolbar.setTitle(R.string.nav_home);
            fragmentTransaction.commit();
        } else if (id == R.id.nav_music) {
            MusicFragment musicFragment = new MusicFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.parent_frame, musicFragment);
            toolbar.setTitle(R.string.nav_music);
            fragmentTransaction.commit();
        } else if (id == R.id.nav_video) {
            VideosFragment videosFragment = new VideosFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.parent_frame, videosFragment);
            toolbar.setTitle(R.string.nav_video);
            fragmentTransaction.commit();
        } else if (id == R.id.nav_gist) {
            GistFragment gistFragment = new GistFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.parent_frame, gistFragment);
            toolbar.setTitle(R.string.nav_gist);
            fragmentTransaction.commit();
        } else if (id == R.id.nav_word_of_faith) {
            WordOfFaithFragment wordOfFaithFragment = new WordOfFaithFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.parent_frame, wordOfFaithFragment);
            toolbar.setTitle(R.string.nav_word_of_faith);
            fragmentTransaction.commit();
        } else if (id == R.id.nav_sonshub_tv) {
            drawerLayout.closeDrawers();
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
            final View generalNoticeView = LayoutInflater.from(this).inflate(R.layout.general_notice, null);

            TextView generalNoticeText = generalNoticeView.findViewById(R.id.generalNoticeText);
            TextView generalNoticeTitle = generalNoticeView.findViewById(R.id.warning);
            ImageView generalNoticeImg = generalNoticeView.findViewById(R.id.warningImg);
            Button cancelButton = generalNoticeView.findViewById(R.id.cancelButton);
            Button continueButton = generalNoticeView.findViewById(R.id.continueButton);

            generalNoticeTitle.setText("SonsHub TV");
            generalNoticeTitle.setPadding(0,10,0,0);
            generalNoticeImg.setImageResource(R.drawable.ic_sonshub_tv);
            generalNoticeText.setText("\"Coming Soon\".\n\nMeanwhile, do subscribe to our YouTube Channel...");
            cancelButton.setVisibility(View.GONE);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
            continueButton.setLayoutParams(layoutParams);
            continueButton.setText("Subscribe to Our YouTube Channel");
            continueButton.setOnClickListener(v -> {
                bottomSheetDialog.dismiss();
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getResources().getString(R.string.youtube_url))));
            });
            bottomSheetDialog.setCancelable(true);
            bottomSheetDialog.setContentView(generalNoticeView);
            bottomSheetDialog.show();
        } else if (id == R.id.nav_music_player) {
            startActivity(new Intent(MainActivity.this, MusicMainActivity.class));
        } else if (id == R.id.nav_about) {
            AboutFragment aboutFragment = new AboutFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.parent_frame, aboutFragment);
            toolbar.setTitle(R.string.nav_about);
            fragmentTransaction.commit();
        }
        drawerLayout.closeDrawers();
        return true;
    }

    private void startAndBindDownloadService() {
        Intent downloadIntent = new Intent(this, DownloadService.class);
        startService(downloadIntent);
        bindService(downloadIntent, serviceConnection, BIND_AUTO_CREATE);
    }

    @SuppressLint({"InflateParams", "SetTextI18n"})
    private void checkNetworkState() {
        ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert cm != null;
        NetworkInfo info = cm.getActiveNetworkInfo();

        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        final View generalNoticeView = LayoutInflater.from(this).inflate(R.layout.general_notice, null);

        TextView generalNoticeTitle = generalNoticeView.findViewById(R.id.warning);
        TextView generalNoticeText = generalNoticeView.findViewById(R.id.generalNoticeText);
        ImageView generalNoticeImg = generalNoticeView.findViewById(R.id.warningImg);
        Button cancelButton = generalNoticeView.findViewById(R.id.cancelButton);
        Button continueButton = generalNoticeView.findViewById(R.id.continueButton);
        Button optionButton = generalNoticeView.findViewById(R.id.optionButton);

        if (info.getType() == ConnectivityManager.TYPE_WIFI) {
            // do something
//            generalNoticeText.setText("Hello, We have detected that your current Internet Connectivity is on WiFi and the your Internet state might become unpredictable and fluctuate often which makes your network state unreliable.\n\nContinue using SonsHub if you trust this network is reliable.");
//            cancelButton.setVisibility(View.GONE);
//            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
//            continueButton.setLayoutParams(layoutParams);
//            continueButton.setText("Continue with WiFi Network");
//            continueButton.setOnClickListener(v -> bottomSheetDialog.dismiss());
//            bottomSheetDialog.setCancelable(false);
//            bottomSheetDialog.setContentView(generalNoticeView);
//            bottomSheetDialog.show();
        } else if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
            // check NetworkInfo subtype
            if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_CDMA) {
                // Bandwidth between 14-64 kbps
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_EDGE) {
                // Bandwidth between 50-100 kbps
                generalNoticeText.setText("Hello, We have detected that your current Internet Connectivity is on EDGE (2G).\nThis means that your Internet Connection is slow and could affect your User Experience on this app.\nWe strongly advice you to switch your network to 3G, 4G or 5G (if available at your location).\n\nContinue using SonsHub if you are certain that you are unable to switch over to a better network... This could adversely affect your experience with the SonsHub Mobile app");
                cancelButton.setVisibility(View.GONE);
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                continueButton.setLayoutParams(layoutParams);
                continueButton.setText("Continue with 2G Network");
                continueButton.setOnClickListener(v -> bottomSheetDialog.dismiss());
                bottomSheetDialog.setCancelable(false);
                bottomSheetDialog.setContentView(generalNoticeView);
                bottomSheetDialog.show();
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_GPRS) {
                // Bandwidth between 100 kbps and below
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_EVDO_0) {
                // Bandwidth between 400-1000 kbps
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_EVDO_A) {
                // Bandwidth between 600-1400 kbps
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_UMTS) {
                // Bandwidth between 400-7000 kbps
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_HSPA) {
                // Bandwidth between 700-1700 kbps
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_HSPAP) {
                // Bandwidth between 700-1700 kbps
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_HSDPA) {
                // Bandwidth between 2-14 Mbps
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_HSUPA) {
                // Bandwidth between 1-23 Mbps
            } else if (info.getSubtype() == TelephonyManager.NETWORK_TYPE_UNKNOWN) {
                // Bandwidth is Unknown
            }
            // Other list of various subtypes you can check for and their bandwidth limits
            // TelephonyManager.NETWORK_TYPE_1xRTT       ~ 50-100 kbps
            // TelephonyManager.NETWORK_TYPE_CDMA        ~ 14-64 kbps
            // TelephonyManager.NETWORK_TYPE_HSDPA       ~ 2-14 Mbps
            // TelephonyManager.NETWORK_TYPE_HSPA        ~ 700-1700 kbps
            // TelephonyManager.NETWORK_TYPE_HSUPA       ~ 1-23 Mbps
            // TelephonyManager.NETWORK_TYPE_UMTS        ~ 400-7000 kbps
            // TelephonyManager.NETWORK_TYPE_UNKNOWN     ~ Unknown

        }
    }

    private boolean haveNetworkConnection() {
        ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert cm != null;
        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo){
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }

        return haveConnectedWifi || haveConnectedMobile;
    }

    @SuppressLint({"IntentReset", "InflateParams", "SetTextI18n"})
    private void sendFeedback() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        final View generalNoticeView = LayoutInflater.from(this).inflate(R.layout.general_notice, null);

        TextView generalNoticeTitle = generalNoticeView.findViewById(R.id.warning);
        TextView generalNoticeText = generalNoticeView.findViewById(R.id.generalNoticeText);
        ImageView generalNoticeImg = generalNoticeView.findViewById(R.id.warningImg);
        Button cancelButton = generalNoticeView.findViewById(R.id.cancelButton);
        Button continueButton = generalNoticeView.findViewById(R.id.continueButton);
        Button optionButton = generalNoticeView.findViewById(R.id.optionButton);

        generalNoticeTitle.setText("Send Us a Feedback");
        generalNoticeImg.setImageResource(R.drawable.ic_feedback);
        generalNoticeText.setText("Would you like to contact us for promotional offers to promote your content on both our website and SonsHub Mobile? If yes, use the first button to contact us.\n\nAre you having issues using SonsHub Mobile or did you notice anything unusual with our content? If yes, use the second button to contact our technical team.");
        cancelButton.setVisibility(View.GONE);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        continueButton.setLayoutParams(layoutParams);
        continueButton.setText("I want to Report an Error");
        optionButton.setVisibility(View.VISIBLE);
        optionButton.setText("I want to Promote my Content");
        continueButton.setOnClickListener(v -> {
            Intent mail = new Intent(Intent.ACTION_SENDTO);
            mail.setType("text/html");
            mail.setData(Uri.parse("mailto:"));
            mail.putExtra(Intent.EXTRA_EMAIL, new String[]{ "gigabytedevelopers@gmail.com"});
            mail.putExtra(Intent.EXTRA_SUBJECT, "Hello, Gigabyte Developers");
            startActivity(Intent.createChooser(mail, "Talk to Gigabyte Developers with"));
            bottomSheetDialog.dismiss();
        });
        optionButton.setOnClickListener(v -> {
            Intent mail = new Intent(Intent.ACTION_SENDTO);
            mail.setType("text/html");
            mail.setData(Uri.parse("mailto:"));
            mail.putExtra(Intent.EXTRA_EMAIL, new String[]{ "sonshubmobile@gmail.com"});
            mail.putExtra(Intent.EXTRA_SUBJECT, "Hello, SonsHub (Promotional Offer)");
            startActivity(Intent.createChooser(mail, "Talk to SonsHub with"));
            bottomSheetDialog.dismiss();
        });
        bottomSheetDialog.setCancelable(true);
        bottomSheetDialog.setContentView(generalNoticeView);
        bottomSheetDialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // register GCM registration complete receiver
        LocalBroadcastManager.getInstance(this).registerReceiver(sonshubNotificaticationBroadcastReceiver,
                new IntentFilter(Configs.REGISTRATION_COMPLETE));

        // register new push message receiver
        // by doing this, the activity will be notified each time a new message arrives
        LocalBroadcastManager.getInstance(this).registerReceiver(sonshubNotificaticationBroadcastReceiver,
                new IntentFilter(Configs.PUSH_NOTIFICATION));

        // clear the notification area when the app is opened
        NotificationUtil.clearNotifications(getApplicationContext());
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(sonshubNotificaticationBroadcastReceiver);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(serviceConnection);
        releasePlayer();
    }
}