package com.gigabytedevelopersinc.apps.sonshub.fragments.music;


import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.*;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.gigabytedevelopersinc.apps.sonshub.R;
import com.gigabytedevelopersinc.apps.sonshub.activities.MainActivity;
import com.gigabytedevelopersinc.apps.sonshub.adapters.AdmobRecyclerViewAdapter;
import com.gigabytedevelopersinc.apps.sonshub.adapters.MainListAdapter;
import com.gigabytedevelopersinc.apps.sonshub.fragments.HomeFragment;
import com.gigabytedevelopersinc.apps.sonshub.models.MainListModel;
import com.gigabytedevelopersinc.apps.sonshub.utils.ClickListener;
import com.gigabytedevelopersinc.apps.sonshub.utils.OnBottomReachedListener;
import com.gigabytedevelopersinc.apps.sonshub.utils.TinyDb;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.NativeExpressAdView;
import com.google.gson.Gson;
import jp.co.recruit_lifestyle.android.widget.WaveSwipeRefreshLayout;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A simple {@link Fragment} subclass.
 */
public class AfricanFragTest extends Fragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    public static final int ITEM_PER_AD = 8;
    private static final int NATIVE_EXPRESS_AD_HEIGHT = 150;
    private AdmobRecyclerViewAdapter adapter;
    private TinyDb tinyDb;
    private LinearLayoutManager manager;
    private ProgressBar progressBar,progressBarLoading;
    int pageNum;
    private SearchView searchView;
    private List<Object> mRecyclerViewItems = new ArrayList<>();
    private WaveSwipeRefreshLayout mWaveSwipeRefreshLayout;
    private Pattern pattern;
    private Matcher matcher;

    private List<Object> mDataSet;

    public final static int spaceBetweenAds = 6;

    public AfricanFragTest() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_african, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mRecyclerView = view.findViewById(R.id.african_list);
        mLayoutManager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(mLayoutManager);

        mDataSet = new ArrayList<>();

        tinyDb = new TinyDb(getActivity());
        tinyDb.putString("currentFrag", "africanFragment");

        setHasOptionsMenu(false);
        manager = new LinearLayoutManager(getActivity());
        progressBar = view.findViewById(R.id.progressBar);
        progressBarLoading = view.findViewById(R.id.progress_bar_loading);

        mWaveSwipeRefreshLayout = view.findViewById(R.id.main_swipe);
        mWaveSwipeRefreshLayout.setWaveColor(getResources().getColor(R.color.colorPrimary));
        mWaveSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.colorAccent));
        mWaveSwipeRefreshLayout.setOnRefreshListener(new WaveSwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getAfricanList();
            }
        });

        progressBarLoading.setVisibility(View.VISIBLE);
        pageNum = 2;
        HomeFragment homeFragment = new HomeFragment();
        homeFragment.hideStreamLayout(mRecyclerView);

        getAfricanList();
        addNativeExpressAds();

    }

    //Method to get the first 10 items from the sonshub api
    private void getAfricanList(){
        mDataSet.clear();
        String AFRICAN_URL = "https://sonshub.com/wp-json/wp/v2/posts?categories=2&per_page=10&page=1";
        JsonArrayRequest africanRequest = new JsonArrayRequest(AFRICAN_URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                mDataSet.clear();
                mWaveSwipeRefreshLayout.setRefreshing(false);
                System.out.println("African response: "+response);
                progressBarLoading.setVisibility(View.GONE);

                try {
                    for (int i = 0; i < response.length(); i++){
                        JSONObject obj = response.getJSONObject(i);
                        String title = obj.getJSONObject("title").getString("rendered");
                        String description = obj.getJSONObject("excerpt").getString("rendered");
                        String time = obj.getString("date");
                        String newTitle = title.trim().replace("<p>", "");
                        String mainTitle = newTitle.trim().replace("&#8211;", "'");
                        String content = obj.getJSONObject("content").getString("rendered");
                        String newDescription = description.trim().replace("<p>", "");
                        String mainDescription = newDescription.trim().replace("&#8211;", "'");
                        String link = obj.getString("link");
                        String movieImage = obj.getString("jetpack_featured_media_url");
                        updateAfricanList(movieImage,mainTitle,link,mainDescription,time,content);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                try {
                    progressBarLoading.setVisibility(View.GONE);
                } catch (Exception npe) {
                    npe.printStackTrace();
                }
                HomeFragment.checkVolleyErrors(getContext(), error);
                error.printStackTrace();
            }
        }){
            @Override
            protected Response<JSONArray> parseNetworkResponse(NetworkResponse response) {
                mDataSet.clear();
                try {
                    Cache.Entry cacheEntry = HttpHeaderParser.parseCacheHeaders(response);
                    if (cacheEntry == null) {
                        cacheEntry = new Cache.Entry();
                    }
                    final long cacheHitButRefreshed = 3 * 60 * 1000; // in 3 minutes cache will be hit, but also refreshed on background
                    final long cacheExpired = 24 * 60 * 60 * 1000; // in 24 hours this cache entry expires completely
                    long now = System.currentTimeMillis();
                    final long softExpire = now + cacheHitButRefreshed;
                    final long ttl = now + cacheExpired;
                    cacheEntry.data = response.data;
                    cacheEntry.softTtl = softExpire;
                    cacheEntry.ttl = ttl;
                    String headerValue;
                    headerValue = response.headers.get("Date");
                    if (headerValue != null) {
                        cacheEntry.serverDate = HttpHeaderParser.parseDateAsEpoch(headerValue);
                    }
                    headerValue = response.headers.get("Last-Modified");
                    if (headerValue != null) {
                        cacheEntry.lastModified = HttpHeaderParser.parseDateAsEpoch(headerValue);
                    }
                    cacheEntry.responseHeaders = response.headers;
                    final String jsonString = new String(response.data,
                            HttpHeaderParser.parseCharset(response.headers));
                    return Response.success(new JSONArray(jsonString), cacheEntry);
                } catch (UnsupportedEncodingException | JSONException e) {
                    return Response.error(new ParseError(e));
                }
            }

            @Override
            protected void deliverResponse(JSONArray response) {
                super.deliverResponse(response);
            }

            @Override
            public void deliverError(VolleyError error) {
                super.deliverError(error);
            }

            @Override
            protected VolleyError parseNetworkError(VolleyError volleyError) {
                return super.parseNetworkError(volleyError);
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(africanRequest);

        africanRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
    }

    private void addNativeExpressAds() {

        // We are looping through our original dataset
        // And adding Admob's Native Express Ad at consecutive positions at a distance of spaceBetweenAds
        // You should change the spaceBetweenAds variable according to your need
        // i.e how often you want to show ad in RecyclerView

        for (int i = spaceBetweenAds; i <= mDataSet.size(); i += (spaceBetweenAds + 1)) {
            NativeExpressAdView adView = new NativeExpressAdView(getContext());
            // I have used a Test ID provided by Admob below
            // you should replace it with yours
            // And if wou are just experimenting, then just copy the code
            adView.setAdUnitId(getResources().getString(R.string.sample_admob_native_ad_id));
            mDataSet.add(i, adView);
        }

        // Below we are using post on RecyclerView
        // because we want to resize our native ad's width equal to screen width
        // and we should do it after RecyclerView is created

        mRecyclerView.post(new Runnable() {
            @Override
            public void run() {
                float scale = getContext().getResources().getDisplayMetrics().density;
                int adWidth = (int) (mRecyclerView.getWidth() - (2 * getContext().getResources().getDimension(R.dimen.image_slider_size)));




                // looping over mDataset to sesize every Native Express Ad to ew adSize
                for (int i = spaceBetweenAds; i < mDataSet.size(); i += (spaceBetweenAds + 1)) {
                   final NativeExpressAdView adViewToSize = (NativeExpressAdView) mDataSet.get(i);

                    // we are setting size of adView
                    // you should check admob's site for possible ads size
                    AdSize adSize = new AdSize((int) (adWidth / scale), 150);
                    adViewToSize.setAdSize(adSize);
                }

                // calling method to load native ads in their views one by one
                loadNativeExpressAd(spaceBetweenAds);
            }
        });

    }

    private void loadNativeExpressAd(final int index) {

        if (index >= mDataSet.size()) {
            return;
        }

        Object item = mDataSet.get(index);
        if (!(item instanceof NativeExpressAdView)) {
            throw new ClassCastException("Expected item at index " + index + " to be a Native"
                    + " Express ad.");
        }

        final NativeExpressAdView adView = (NativeExpressAdView) item;

        // Set an AdListener on the NativeExpressAdView to wait for the previous Native Express ad
        // to finish loading before loading the next ad in the items list.
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                // The previous Native Express ad loaded successfully, call this method again to
                // load the next ad in the items list.
                loadNativeExpressAd(index + spaceBetweenAds + 1);
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // The previous Native Express ad failed to load. Call this method again to load
                // the next ad in the items list.
                Log.e("AdmobMainActivity", "The previous Native Express ad failed to load. Attempting to"
                        + " load the next Native Express ad in the items list.");
                loadNativeExpressAd(index + spaceBetweenAds + 1);
            }
        });

        // Load the Native Express ad.
        //We also registering our device as Test Device with addTestDevic("ID") method
//        adView.loadAd(new AdRequest.Builder().addTestDevice("YOUR_TEST_DEVICE_ID").build());
    }

    private void updateAfricanList(String imageUrl, String title, String link,String description, String time,String content){

        MainListModel mainListModel = new MainListModel(imageUrl,title,link,description,time,content);
        mDataSet.add(mainListModel);

        adapter = new AdmobRecyclerViewAdapter(getContext(), mDataSet, spaceBetweenAds,new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                tinyDb.putString("clicked", "music");
                tinyDb.putString("musicDetailsList", getDetails(mDataSet,position));

                MainActivity mainActivity = new MainActivity();
                mainActivity.fillBottomSheet(getContext(),pattern,matcher,tinyDb);
            }
        });

        mRecyclerView.setLayoutManager(manager);
        mRecyclerView.setAdapter(adapter);

        adapter.setOnBottomReachedListener(new OnBottomReachedListener() {
            @Override
            public void onBottomReached(int position) {
                String AFRICAN_URL = "https://sonshub.com/wp-json/wp/v2/posts?categories=2&per_page=10&page=" + pageNum;
                pageNum = pageNum + 1;
                progressBar.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        loadMoreAfricanList(AFRICAN_URL);
                    }
                }, 5000);


            }
        });

    }

    private String getDetails(List<Object> mainList, int position){
        List<Object> mainListModels = new ArrayList<>();
        mainListModels.add(mainList.get(position));

        Gson gson = new Gson();
        return gson.toJson(mainListModels);
    }

    //Method to load more to the list
    private void loadMoreAfricanList(String AFRICAN_URL){
        JsonArrayRequest africanRequest = new JsonArrayRequest(AFRICAN_URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                System.out.println(response);
                try {
                    for (int i = 0; i < response.length(); i++){
                        JSONObject obj = response.getJSONObject(i);
                        String title = obj.getJSONObject("title").getString("rendered");
                        String description = obj.getJSONObject("excerpt").getString("rendered");
                        String newDescription = description.replace("<p>", "");
                        String time = obj.getString("date");
                        String content = obj.getJSONObject("content").getString("rendered");
                        String newTitle = title.trim().replace("DOWNLOAD MOVIE:", "");
                        String mainTitle = newTitle.trim().replace("&#8217;", "'");
                        String link = obj.getString("link");
                        String movieImage = obj.getString("jetpack_featured_media_url");
                        updateloadMoreAfricanList(movieImage,mainTitle,link,newDescription,time,content);
                    }

                    progressBar.setVisibility(View.GONE);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                NetworkResponse response = error.networkResponse;
                if (error instanceof ServerError && response != null) {
                    try {
                        String res = new String(response.data,
                                HttpHeaderParser.parseCharset(response.headers, "utf-8"));
                        // Now you can use any deserializer to make sense of data
                        System.out.print("Error Json " + res);
                        JSONObject obj = new JSONObject(res);
                        int status = obj.getJSONObject("data").getInt("status");

                        if (status == 400){
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(getContext(), "Page End", Toast.LENGTH_LONG).show();
                        }
                    } catch (UnsupportedEncodingException e1) {
                        // Couldn't properly decode data to string
                        e1.printStackTrace();
                    } catch (JSONException e2) {
                        // returned data is not JSONObject?
                        e2.printStackTrace();
                    }
                }else {
                    System.out.println("Load More Error" + error);
                    HomeFragment.checkVolleyErrors(getContext(), error);
                    error.printStackTrace();
                }
            }
        }){

        };

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()));
        requestQueue.add(africanRequest);

        africanRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
    }

    private void updateloadMoreAfricanList(String imageUrl, String title, String link,String description, String time,String content){
        MainListModel mainListModel = new MainListModel(imageUrl,title,link,description,time,content);
        mDataSet.add(mainListModel);
    }


}
