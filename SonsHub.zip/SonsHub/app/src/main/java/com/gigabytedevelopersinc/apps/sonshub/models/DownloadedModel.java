package com.gigabytedevelopersinc.apps.sonshub.models;

import android.widget.LinearLayout;

public class DownloadedModel {
    private String title;

    public DownloadedModel(String title){
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
