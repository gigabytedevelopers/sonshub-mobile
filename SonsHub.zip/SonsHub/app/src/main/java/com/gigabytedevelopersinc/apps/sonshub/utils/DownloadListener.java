package com.gigabytedevelopersinc.apps.sonshub.utils;

import android.view.View;

public interface DownloadListener {
    void onAudioOrVideoClick(View view, int position, String title);
}
