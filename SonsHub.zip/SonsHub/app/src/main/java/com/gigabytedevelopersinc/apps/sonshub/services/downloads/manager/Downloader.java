package com.gigabytedevelopersinc.apps.sonshub.services.downloads.manager;

import android.content.Context;
import com.gigabytedevelopersinc.apps.sonshub.App;
import com.gigabytedevelopersinc.apps.sonshub.adapters.DownloadFileAdapter;
import com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2.DefaultFetchNotificationManager;
import com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2.Fetch;
import com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2.FetchConfiguration;
import com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2.Request;
import com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2core.Extras;
import com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2core.Func;
import com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2core.MutableExtras;
import com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2okhttp.OkHttpDownloader;
import com.gigabytedevelopersinc.apps.sonshub.services.notification.SonsHubDownloadNotificationManager;
import com.gigabytedevelopersinc.apps.sonshub.utils.misc.Data;
import com.google.firebase.database.annotations.NotNull;
import timber.log.Timber;

import java.util.ArrayList;
import java.util.List;

/**
 * Project - SonsHub
 * Created with Android Studio
 * Company: Gigabyte Developers
 * User: Emmanuel Nwokoma
 * Title: Founder and CEO
 * Day: Sunday, 10
 * Month: March
 * Year: 2019
 * Date: 10 Mar, 2019
 * Time: 6:09 AM
 * Desc: Downloader
 **/
public class Downloader {
    private static final long UNKNOWN_REMAINING_TIME = -1;
    private static final long UNKNOWN_DOWNLOADED_BYTES_PER_SECOND = 0;
    private static final int GROUP_ID = "listGroup".hashCode();
    private static final String FETCH_NAMESPACE = "Downloading";

    private Request request;

    public static void enqueueDownload() {
        Context appContext = App.getContext();
        final FetchConfiguration fetchConfiguration = new FetchConfiguration.Builder(appContext)
                .setDownloadConcurrentLimit(4)
                .setHttpDownloader(new OkHttpDownloader(
                        com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2core.Downloader.FileDownloaderType.PARALLEL)
                )
                .setNamespace(FETCH_NAMESPACE)
                .setNotificationManager(new SonsHubDownloadNotificationManager(appContext))
                .build();
        final Fetch fetch = Fetch.Impl.getInstance(fetchConfiguration);
        final List<Request> requests = Data.getFetchRequestWithGroupId(GROUP_ID);
        fetch.enqueue(requests, updatedRequests -> {

        });
    }
}
