package com.gigabytedevelopersinc.apps.sonshub.utils;

import android.view.View;

public interface ClickListener {
    void onItemClick(View view, int position);

}
