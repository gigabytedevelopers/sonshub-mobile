package com.gigabytedevelopersinc.apps.sonshub.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.Html;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;
import android.view.*;
import com.android.volley.*;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.GenericTransitionOptions;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.crashlytics.android.Crashlytics;
import com.gigabytedevelopersinc.apps.sonshub.R;
import com.gigabytedevelopersinc.apps.sonshub.activities.MainActivity;
import com.gigabytedevelopersinc.apps.sonshub.adapters.MainListAdapter;
import com.gigabytedevelopersinc.apps.sonshub.adapters.MovieAdapter;
import com.gigabytedevelopersinc.apps.sonshub.adapters.MusicAdapter;
import com.gigabytedevelopersinc.apps.sonshub.adapters.NewsAdapter;
import com.gigabytedevelopersinc.apps.sonshub.fragments.music.MusicFragment;
import com.gigabytedevelopersinc.apps.sonshub.fragments.videos.MoviesFragment;
import com.gigabytedevelopersinc.apps.sonshub.models.MainListModel;
import com.gigabytedevelopersinc.apps.sonshub.models.MovieModel;
import com.gigabytedevelopersinc.apps.sonshub.models.MusicModel;
import com.gigabytedevelopersinc.apps.sonshub.models.NewsModel;
import com.gigabytedevelopersinc.apps.sonshub.services.downloads.manager.Downloader;
import com.gigabytedevelopersinc.apps.sonshub.utils.ClickListener;
import com.gigabytedevelopersinc.apps.sonshub.utils.TinyDb;
import com.gigabytedevelopersinc.apps.sonshub.utils.misc.Data;
import com.glide.slider.library.Animations.DescriptionAnimation;
import com.glide.slider.library.SliderLayout;
import com.glide.slider.library.SliderTypes.BaseSliderView;
import com.glide.slider.library.SliderTypes.DefaultSliderView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.Gson;
import jp.co.recruit_lifestyle.android.widget.WaveSwipeRefreshLayout;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import saschpe.android.customtabs.CustomTabsHelper;
import saschpe.android.customtabs.WebViewFallback;
import timber.log.Timber;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.gigabytedevelopersinc.apps.sonshub.activities.MainActivity.*;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {
    private RelativeLayout movieView,musicView, gistView;
    private RecyclerView moviesRecyclerView, musicRecyclerView, gistRecyclerView, searchRecyclerView;
    private List<MovieModel> movieList;
    private List<MusicModel> musicList, featuredList;
    private List<NewsModel> gistList;
    private NewsAdapter newsAdapter;
    private MovieAdapter adapter;
    private MusicAdapter musicAdapter;
    private String MOVIE_HOME_URL="https://sonshub.com/wp-json/wp/v2/posts?categories=586&per_page=10";
    private String MUSIC_HOME_URL ="https://sonshub.com/wp-json/wp/v2/posts?categories=2&per_page=10";
    private String ARTICLE_HOME_URL ="https://sonshub.com/wp-json/wp/v2/posts?per_page=10";
    private String FEATURED_AREA_URL = "https://sonshub.com/wp-json/wp/v2/posts?categories=19824&per_page=10";
    private SliderLayout mDemoSlider;
    private ProgressBar moviesProgress, musicProgress,gistProgress,searchProgress;
    private TinyDb tinyDb;
    private SearchView searchView;
    private RelativeLayout searchLayout;
    private List<MainListModel> searchList;
    private MainListAdapter searchAdapter;
    private NestedScrollView scrollView;
    private WaveSwipeRefreshLayout mWaveSwipeRefreshLayout;
    private Pattern pattern;
    private Matcher matcher;
    int currentWindow;
    long playBackPosition;
    MainActivity mainActivity = new MainActivity();
    boolean playWhenReady = false;


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        movieView = view.findViewById(R.id.movies_view);
        musicView = view.findViewById(R.id.music_view);
        gistView = view.findViewById(R.id.gist_view);
        moviesRecyclerView = view.findViewById(R.id.movies_list);
        musicRecyclerView = view.findViewById(R.id.music_list);
        gistRecyclerView = view.findViewById(R.id.gist_list);
        searchRecyclerView = view.findViewById(R.id.search_recyclerview);
        movieList = new ArrayList<>();
        musicList = new ArrayList<>();
        featuredList = new ArrayList<>();
        gistList = new ArrayList<>();
        searchList = new ArrayList<>();
        mDemoSlider = view.findViewById(R.id.slider_layout);
        moviesProgress = view.findViewById(R.id.movies_progress);
        musicProgress = view.findViewById(R.id.music_progress);
        gistProgress = view.findViewById(R.id.gist_progress);
        tinyDb = new TinyDb(getContext());
        tinyDb.putString("whichFrag","Home");
        searchLayout = view.findViewById(R.id.search_layout);
        searchProgress = view.findViewById(R.id.search_progress);
        scrollView = view.findViewById(R.id.nestedScroll);
        ArrayList<String> listUrl = new ArrayList<>();

        mWaveSwipeRefreshLayout = view.findViewById(R.id.main_swipe);
        mWaveSwipeRefreshLayout.setWaveColor(getResources().getColor(R.color.colorPrimary));
        mWaveSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.colorAccent));
        mWaveSwipeRefreshLayout.setOnRefreshListener(new WaveSwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getMoviePicAndTitle();
                getMusicPicAndTitle();
                getGistList();

            }
        });

        adapter = new MovieAdapter(getActivity(), movieList, new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {
            }
        });
        newsAdapter = new NewsAdapter(getContext(), gistList, new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {

            }
        });
        musicAdapter = new MusicAdapter(getContext(), musicList, new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {

            }
        });

        scrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (scrollY > oldScrollY) {
                    MainActivity.streamLayout.setVisibility(View.GONE);

                } else if (scrollY < oldScrollY){
                    MainActivity.streamLayout.setVisibility(View.VISIBLE);
                }

            }
        });

        searchAdapter = new MainListAdapter(getContext(), searchList, new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {

            }
        });

        moviesProgress.setVisibility(View.VISIBLE);
        musicProgress.setVisibility(View.VISIBLE);
        gistProgress.setVisibility(View.VISIBLE);

            getMoviePicAndTitle();
            getMusicPicAndTitle();
            getGistList();
            getFeaturedImages(listUrl);

        musicView.setOnClickListener(view1 ->{
            MusicFragment musicFragment = new MusicFragment();
            FragmentTransaction fragmentTransaction = Objects.requireNonNull(getFragmentManager()).beginTransaction();
            fragmentTransaction.replace(R.id.parent_frame, musicFragment);
            fragmentTransaction.commit();
            fragmentTransaction.addToBackStack(null);
        });

        movieView.setOnClickListener(view1 ->{
            MoviesFragment moviesFragment = new MoviesFragment();
            FragmentTransaction fragmentTransaction = Objects.requireNonNull(getFragmentManager()).beginTransaction();
            fragmentTransaction.replace(R.id.parent_frame, moviesFragment);
            fragmentTransaction.commit();
            fragmentTransaction.addToBackStack(null);
        });

        gistView.setOnClickListener(view1 ->{
            LatestPostFrag gistFragment = new LatestPostFrag();
            FragmentTransaction fragmentTransaction = Objects.requireNonNull(getFragmentManager()).beginTransaction();
            fragmentTransaction.replace(R.id.parent_frame, gistFragment);
            MainActivity.toolbar.setTitle("Latest Posts");
            fragmentTransaction.commit();
            fragmentTransaction.addToBackStack(null);
        });

        return view;

    }

    public static void hideStreamLayout(RecyclerView recyclerView){
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0){
                    //Scrolling Downl

                    MainActivity.streamLayout.setVisibility(View.GONE);
                } else {
                    //Scrolling Up

                    MainActivity.streamLayout.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    public static void checkVolleyErrors(Context context, VolleyError error){
        try {
            if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                if (error.getMessage() == null
                        || error.getMessage().equals("")
                        || error.getCause().getMessage() == null
                        || error.getCause().getMessage().equals("")) {
                    Toast.makeText(context, "Sorry, There was a Timeout Error", Toast.LENGTH_LONG).show();
                } else {
                    Crashlytics.log(0, "IGNORE: ", error.getMessage());
                }
            } else if (error instanceof AuthFailureError) {
                if (error.getMessage() == null
                        || error.getMessage().equals("")
                        || error.getCause().getMessage() == null
                        || error.getCause().getMessage().equals("")) {
                    Toast.makeText(context, "Ooops... An Authentication Error Occurred", Toast.LENGTH_LONG).show();
                } else {
                    Crashlytics.log(0, "IGNORE: ", error.getMessage());
                }
            } else if (error instanceof ServerError || error.getCause() instanceof ServerError) {
                if (error.getMessage() == null
                        || error.getMessage().equals("")
                        || error.getCause().getMessage() == null
                        || error.getCause().getMessage().equals("")) {
                    Toast.makeText(context, "Ooops... A Server Error Occurred", Toast.LENGTH_LONG).show();
                } else {
                    Crashlytics.log(0, "IGNORE: ", error.getMessage());
                }
            } else if (error instanceof NetworkError) {
                if (error.getMessage() == null
                        || error.getMessage().equals("")
                        || error.getCause().getMessage() == null
                        || error.getCause().getMessage().equals("")) {
                    Toast.makeText(context, "Error Connecting to Server. Check your Network", Toast.LENGTH_LONG).show();
                } else {
                    Crashlytics.log(0, "IGNORE: ", error.getMessage());
                }
            } else if (error instanceof ParseError) {
                if (error.getMessage() == null
                        || error.getMessage().equals("")
                        || error.getCause().getMessage() == null
                        || error.getCause().getMessage().equals("")) {
                    Toast.makeText(context, "Ooops... an Unknown Error Occurred", Toast.LENGTH_LONG).show();
                } else {
                    Crashlytics.log(0, "IGNORE: ", error.getMessage());
                    //Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e){
            if (e.getCause() != null && e.getCause() instanceof UnknownHostException) {
                Crashlytics.log(0, "IGNORE: ", error.getMessage());
            }
            e.printStackTrace();
        }


//        if(error instanceof NoConnectionError){
//            ConnectivityManager cm = (ConnectivityManager)context
//                    .getSystemService(Context.CONNECTIVITY_SERVICE);
//            NetworkInfo activeNetwork = null;
//            if (cm != null) {
//                activeNetwork = cm.getActiveNetworkInfo();
//            }
//            if(activeNetwork != null && activeNetwork.isConnectedOrConnecting()){
//                if ((error.getMessage() == null) || error.getMessage().equals("")) {
//                    Toast.makeText(context, "Server is not connected to internet.",
//                            Toast.LENGTH_SHORT).show();
//                } else {
//                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
//                }
//            } else {
//                Toast.makeText(context, "Your device is not connected to internet.",
//                        Toast.LENGTH_SHORT).show();
//            }
//        } else if (error instanceof NetworkError || error.getCause() instanceof ConnectException
//                || (error.getCause().getMessage() != null
//                && error.getCause().getMessage().contains("connection"))){
//            if ((error.getMessage() == null) || error.getMessage().equals("")) {
//                Toast.makeText(context, "Your device is not connected to internet.",
//                        Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        } else if (error.getCause() instanceof MalformedURLException){
//            if ((error.getMessage() == null) || error.getMessage().equals("")) {
//                Toast.makeText(context, "Bad Request.", Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        } else if (error instanceof ParseError || error.getCause() instanceof IllegalStateException
//                || error.getCause() instanceof JSONException
//                || error.getCause() instanceof XmlPullParserException){
//            if ((error.getMessage() == null) || error.getMessage().equals("")) {
//                Toast.makeText(context, "Parse Error (because of invalid json or xml).",
//                        Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        } else if (error.getCause() instanceof OutOfMemoryError){
//            if ((error.getMessage() == null) || error.getMessage().equals("")) {
//                Toast.makeText(context, "Out Of Memory Error.", Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        }else if (error instanceof AuthFailureError){
//            if ((error.getMessage() == null) || error.getMessage().equals("")) {
//                Toast.makeText(context, "server couldn't find the authenticated request.",
//                        Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        } else if (error instanceof ServerError || error.getCause() instanceof ServerError) {
//            if ((error.getMessage() == null) || error.getMessage().equals("")) {
//                Toast.makeText(context, "Server is not responding.", Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        }else if (error instanceof TimeoutError || error.getCause() instanceof SocketTimeoutException
//                || error.getCause() instanceof ConnectTimeoutException
//                || error.getCause() instanceof SocketException
//                || (error.getCause().getMessage() != null
//                && error.getCause().getMessage().contains("Connection timed out"))) {
//            if ((error.getMessage() == null) || error.getMessage().equals("")) {
//                Toast.makeText(context, "Connection timeout error",
//                        Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        } else {
//            if ((error.getMessage() == null) || error.getMessage().equals("")) {
//                Toast.makeText(context, "An unknown error occurred.",
//                        Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        }
    }

    private void getFeaturedImages(List<String> list){
        JsonArrayRequest featuredRequest = new JsonArrayRequest(FEATURED_AREA_URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                System.out.println("Featured Image " + response);
                try {
                    for (int i = 0; i < response.length(); i++){
                        JSONObject obj = response.getJSONObject(i);
                        String featuredTitle = obj.getJSONObject("title").getString("rendered");
                        String newFeaturedTitle = featuredTitle.trim().replace("DOWNLOAD MUSIC:", "");
                        String mainMovieTitle = newFeaturedTitle.trim().replace("&#8217;", "'");
                        String content = obj.getJSONObject("content").getString("rendered");
                        String featuredImage = obj.getString("jetpack_featured_media_url");
                        String link = obj.getString("link");
                        list.add(featuredImage);
                        updateFeaturedList(featuredImage,mainMovieTitle,content,link);

                    }

                    RequestOptions requestOptions = new RequestOptions();

                    for (int j = 0; j < list.size(); j++) {
                        DefaultSliderView sliderView = new DefaultSliderView(getContext());
                        // if you want show image only / without description text use DefaultSliderView instead

                        // initialize SliderLayout
                        sliderView
                                .image(list.get(j))
                                .setRequestOption(requestOptions)
                                .setRequestOption(requestOptions.diskCacheStrategy(DiskCacheStrategy.ALL))
                                .setProgressBarVisible(true)
                                .setOnSliderClickListener(new BaseSliderView.OnSliderClickListener() {
                                    @Override
                                    public void onSliderClick(BaseSliderView baseSliderView) {
                                        tinyDb.putString("clicked", "featuredimages");
                                        tinyDb.putString("featuredimageslist", getDetailsForMusic(featuredList,mDemoSlider.getCurrentPosition()));
                                        MainActivity mainActivity = new MainActivity();
                                        mainActivity.fillBottomSheet(getContext(),pattern,matcher,tinyDb);
                                    }
                                });

                        //add your extra information
                        sliderView.bundle(new Bundle());

                        mDemoSlider.addSlider(sliderView);
                    }

                    // set Slider Transition Animation
                    // mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Default);
                    mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Default);
                    mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
                    mDemoSlider.setCustomAnimation(new DescriptionAnimation());
                    mDemoSlider.setDuration(4000);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                checkVolleyErrors(getContext(), error);
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        requestQueue.add(featuredRequest);
        featuredRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });

    }

    private void getMoviePicAndTitle(){
        JsonArrayRequest movieRequest = new JsonArrayRequest(MOVIE_HOME_URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                movieList.clear();
                moviesProgress.setVisibility(View.GONE);
                System.out.println(response);
                try {
                    for (int i = 0; i < response.length(); i++){
                        JSONObject obj = response.getJSONObject(i);
                        String movieTitle = obj.getJSONObject("title").getString("rendered");
                        String newMovieTitle = movieTitle.trim().replace("DOWNLOAD MOVIE:", "");
                        String mainMovieTitle = newMovieTitle.trim().replace("&#8217;", "'");
                        String content = obj.getJSONObject("content").getString("rendered");
                        String movieImage = obj.getString("jetpack_featured_media_url");
                        String link = obj.getString("link");
                        updateMovieList(movieImage,mainMovieTitle, content,link);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
           public void onErrorResponse(VolleyError error) {
                try {
                    moviesProgress.setVisibility(View.GONE);
                } catch (Exception npe) {
                    npe.printStackTrace();
                }

                System.out.println("Home Movie list caused crash with error " + error);
                checkVolleyErrors(getContext(), error);
           }
        }){
            @Override
            protected Response<JSONArray> parseNetworkResponse(NetworkResponse response) {
                try {
                    Cache.Entry cacheEntry = HttpHeaderParser.parseCacheHeaders(response);
                    if (cacheEntry == null) {
                        cacheEntry = new Cache.Entry();
                    }
                    final long cacheHitButRefreshed = 3 * 60 * 1000; // in 3 minutes cache will be hit, but also refreshed on background
                    final long cacheExpired = 24 * 60 * 60 * 1000; // in 24 hours this cache entry expires completely
                    long now = System.currentTimeMillis();
                    final long softExpire = now + cacheHitButRefreshed;
                    final long ttl = now + cacheExpired;
                    cacheEntry.data = response.data;
                    cacheEntry.softTtl = softExpire;
                    cacheEntry.ttl = ttl;
                    String headerValue;
                    headerValue = response.headers.get("Date");
                    if (headerValue != null) {
                        cacheEntry.serverDate = HttpHeaderParser.parseDateAsEpoch(headerValue);
                    }
                    headerValue = response.headers.get("Last-Modified");
                    if (headerValue != null) {
                        cacheEntry.lastModified = HttpHeaderParser.parseDateAsEpoch(headerValue);
                    }
                    cacheEntry.responseHeaders = response.headers;
                    final String jsonString = new String(response.data,
                            HttpHeaderParser.parseCharset(response.headers));
                    return Response.success(new JSONArray(jsonString), cacheEntry);
                } catch (UnsupportedEncodingException | JSONException e) {
                    return Response.error(new ParseError(e));
                }
            }

            @Override
            protected void deliverResponse(JSONArray response) {
                super.deliverResponse(response);
            }

            @Override
            public void deliverError(VolleyError error) {
                super.deliverError(error);
            }

            @Override
            protected VolleyError parseNetworkError(VolleyError volleyError) {
                return super.parseNetworkError(volleyError);
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        requestQueue.add(movieRequest);
        movieRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
    }

    private void getMusicPicAndTitle(){
        JsonArrayRequest musicRequest = new JsonArrayRequest(MUSIC_HOME_URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                musicList.clear();
                mWaveSwipeRefreshLayout.setRefreshing(false);
                musicProgress.setVisibility(View.GONE);
                System.out.println("Muisc array "+response);
                try {
                    for (int i = 0; i < response.length(); i++){
                        JSONObject obj = response.getJSONObject(i);
                        String musicTitle = obj.getJSONObject("title").getString("rendered");
                        String newMusicTitle = musicTitle.trim().replace("MUSIC:", "");
                        String mainMusicTitle = newMusicTitle.trim().replace("&#8211;", "'");
                        String content = obj.getJSONObject("content").getString("rendered");
                        String link = obj.getString("link");
                        String movieImage = obj.getString("jetpack_featured_media_url");
                        updateMusicList(movieImage,mainMusicTitle.trim().replace("&#8220:",""), content,link);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                try {
                    musicProgress.setVisibility(View.GONE);
                } catch (Exception npe) {
                    npe.printStackTrace();
                }

                System.out.println("Home Music list caused crash with error " + error);
                checkVolleyErrors(getContext(), error);
                error.printStackTrace();
            }
        }){
            @Override
            protected Response<JSONArray> parseNetworkResponse(NetworkResponse response) {
                try {
                    Cache.Entry cacheEntry = HttpHeaderParser.parseCacheHeaders(response);
                    if (cacheEntry == null) {
                        cacheEntry = new Cache.Entry();
                    }
                    final long cacheHitButRefreshed = 3 * 60 * 1000; // in 3 minutes cache will be hit, but also refreshed on background
                    final long cacheExpired = 24 * 60 * 60 * 1000; // in 24 hours this cache entry expires completely
                    long now = System.currentTimeMillis();
                    final long softExpire = now + cacheHitButRefreshed;
                    final long ttl = now + cacheExpired;
                    cacheEntry.data = response.data;
                    cacheEntry.softTtl = softExpire;
                    cacheEntry.ttl = ttl;
                    String headerValue;
                    headerValue = response.headers.get("Date");
                    if (headerValue != null) {
                        cacheEntry.serverDate = HttpHeaderParser.parseDateAsEpoch(headerValue);
                    }
                    headerValue = response.headers.get("Last-Modified");
                    if (headerValue != null) {
                        cacheEntry.lastModified = HttpHeaderParser.parseDateAsEpoch(headerValue);
                    }
                    cacheEntry.responseHeaders = response.headers;
                    final String jsonString = new String(response.data,
                            HttpHeaderParser.parseCharset(response.headers));
                    return Response.success(new JSONArray(jsonString), cacheEntry);
                } catch (UnsupportedEncodingException | JSONException e) {
                    return Response.error(new ParseError(e));
                }
            }

            @Override
            protected void deliverResponse(JSONArray response) {
                super.deliverResponse(response);
            }

            @Override
            public void deliverError(VolleyError error) {
                super.deliverError(error);
            }

            @Override
            protected VolleyError parseNetworkError(VolleyError volleyError) {
                return super.parseNetworkError(volleyError);
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        requestQueue.add(musicRequest);
        musicRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
    }

    private void getGistList(){
        JsonArrayRequest gistRequest = new JsonArrayRequest(ARTICLE_HOME_URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                gistList.clear();
                gistProgress.setVisibility(View.GONE);
                System.out.println("Gist response "+response);
                try {
                    for (int i = 0; i < response.length(); i++){
                        JSONObject obj = response.getJSONObject(i);
                        String gistTitle = obj.getJSONObject("title").getString("rendered");
                        String gistDescription = obj.getJSONObject("excerpt").getString("rendered");
                        String newGistDescription = gistDescription.replace("<p>", "");
                        String newsTime = obj.getString("date");
                        String content = obj.getJSONObject("content").getString("rendered");
                        String newsImage = obj.getString("jetpack_featured_media_url");
                        String link = obj.getString("link");
                        updateGistList(gistTitle,newGistDescription,newsTime,newsImage, content,link);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                try {
                    gistProgress.setVisibility(View.GONE);
                } catch (Exception npe) {
                    npe.printStackTrace();
                }

                System.out.println("Home Gist list caused crash with error " + error);
                checkVolleyErrors(getContext(), error);
                error.printStackTrace();
            }
        }){
            @Override
            protected Response<JSONArray> parseNetworkResponse(NetworkResponse response) {
                try {
                    Cache.Entry cacheEntry = HttpHeaderParser.parseCacheHeaders(response);
                    if (cacheEntry == null) {
                        cacheEntry = new Cache.Entry();
                    }
                    final long cacheHitButRefreshed = 3 * 60 * 1000; // in 3 minutes cache will be hit, but also refreshed on background
                    final long cacheExpired = 24 * 60 * 60 * 1000; // in 24 hours this cache entry expires completely
                    long now = System.currentTimeMillis();
                    final long softExpire = now + cacheHitButRefreshed;
                    final long ttl = now + cacheExpired;
                    cacheEntry.data = response.data;
                    cacheEntry.softTtl = softExpire;
                    cacheEntry.ttl = ttl;
                    String headerValue;
                    headerValue = response.headers.get("Date");
                    if (headerValue != null) {
                        cacheEntry.serverDate = HttpHeaderParser.parseDateAsEpoch(headerValue);
                    }
                    headerValue = response.headers.get("Last-Modified");
                    if (headerValue != null) {
                        cacheEntry.lastModified = HttpHeaderParser.parseDateAsEpoch(headerValue);
                    }
                    cacheEntry.responseHeaders = response.headers;
                    final String jsonString = new String(response.data,
                            HttpHeaderParser.parseCharset(response.headers));
                    return Response.success(new JSONArray(jsonString), cacheEntry);
                } catch (UnsupportedEncodingException | JSONException e) {
                    return Response.error(new ParseError(e));
                }
            }

            @Override
            protected void deliverResponse(JSONArray response) {
                super.deliverResponse(response);
            }

            @Override
            public void deliverError(VolleyError error) {
                super.deliverError(error);
            }

            @Override
            protected VolleyError parseNetworkError(VolleyError volleyError) {
                return super.parseNetworkError(volleyError);
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        requestQueue.add(gistRequest);

        gistRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
    }

    private void updateMovieList(String movieImage, String movieTitle, String content,String link){
        MovieModel movieModel = new MovieModel(movieImage,movieTitle, content,link);
        movieList.add(movieModel);
        adapter.notifyDataSetChanged();

        adapter = new MovieAdapter(getActivity(), movieList, new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                tinyDb.putString("clicked", "movies");
                tinyDb.putString("movieDetailsList", getDetailsForMovies(movieList,position));

                fillBottomSheet(getContext(),pattern,matcher,tinyDb);
            }
        });

        LinearLayoutManager llm = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL,false);
        moviesRecyclerView.setLayoutManager(llm);
        moviesRecyclerView.setAdapter(adapter);
    }

    private void updateMusicList(String musicImage, String musicTitle, String content,String link){
        MusicModel musicModel = new MusicModel(musicImage, musicTitle, content,link);
        musicList.add(musicModel);
        musicAdapter.notifyDataSetChanged();

        musicAdapter = new MusicAdapter(getActivity(), musicList, new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                tinyDb.putString("clicked", "music");
                tinyDb.putString("musicDetailsList", getDetailsForMusic(musicList,position));

                fillBottomSheet(getContext(),pattern,matcher,tinyDb);

            }
        });

        LinearLayoutManager llm = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL,false);
        musicRecyclerView.setLayoutManager(llm);
        musicRecyclerView.setAdapter(musicAdapter);
    }

    private void updateGistList(String newsTitle, String newsDescription, String newsTime, String newsImage, String content,String link){
        NewsModel newsModel = new NewsModel(newsTitle,newsDescription,newsTime,newsImage, content,link);
        gistList.add(newsModel);
        newsAdapter.notifyDataSetChanged();

        newsAdapter = new NewsAdapter(getActivity(), gistList, new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                tinyDb.putString("clicked", "featured");
                tinyDb.putString("featuredDetailsList",getDetailsForGist(gistList, position));

                fillBottomSheet(getContext(),pattern,matcher,tinyDb);
            }
        });

        LinearLayoutManager llm = new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL,false);
        gistRecyclerView.setLayoutManager(llm);
        gistRecyclerView.setAdapter(newsAdapter);
    }

    private void updateFeaturedList(String musicImage, String musicTitle, String content,String link){
        MusicModel musicModel = new MusicModel(musicImage, musicTitle, content,link);
        featuredList.add(musicModel);
    }

    private String getDetailsForMovies(List<MovieModel> movieList, int position){
        List<MovieModel> movieModels = new ArrayList<>();
        movieModels.add(movieList.get(position));

        Gson gson = new Gson();
        return gson.toJson(movieModels);
    }

    private String getDetailsForMusic(List<MusicModel> musicList, int position){
        List<MusicModel> musicModels = new ArrayList<>();
        musicModels.add(musicList.get(position));

        Gson gson = new Gson();
        return gson.toJson(musicModels);
    }

    private String getDetailsForGist(List<NewsModel> newsList, int position){
        List<NewsModel> newsModels = new ArrayList<>();
        newsModels.add(newsList.get(position));

        Gson gson = new Gson();
        return gson.toJson(newsModels);
    }

    @SuppressLint("InflateParams")
    public static void fillBottomSheet(Context context, Pattern pattern, Matcher matcher, TinyDb tinyDb){
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Objects.requireNonNull(context));
        View detailsView = LayoutInflater.from(context).inflate(R.layout.details_bottomsheet, null);
        ImageView imageView = detailsView.findViewById(R.id.songImage);
        ImageView downloadBtn = detailsView.findViewById(R.id.download_button);
        ImageView streamBtn = detailsView.findViewById(R.id.stream_button);
        TextView songTitle = detailsView.findViewById(R.id.song_title);
        TextView songContent = detailsView.findViewById(R.id.content_view);
        Button button = detailsView.findViewById(R.id.web_button);
        LinearLayout backButton = detailsView.findViewById(R.id.back);

        backButton.setOnClickListener(v -> bottomSheetDialog.dismiss());
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(context.getResources().getColor(R.color.colorAccent));          // (no gradient)
        gd.setStroke(2, Color.BLACK);
        gd.setShape(GradientDrawable.OVAL);
        gd.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        gd.setGradientRadius(streamBtn.getWidth()/2);
        gd.setSize(50,50);
        streamBtn.setBackground(gd);
        downloadBtn.setBackground(gd);

        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setContentView(detailsView);
        bottomSheetDialog.show();
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setShowTitle(true);
        CustomTabsIntent customTabsIntent = builder.build();
        builder.setToolbarColor(context.getResources().getColor(R.color.colorPrimary));
        CustomTabsHelper.addKeepAliveExtra(context, customTabsIntent.intent);
        tinyDb = new TinyDb(context);

        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                //.addTestDevice("DED5E5589FE9B73E06F70486636F2945") // Tecno Camon C7
                .build();

        //This switch statement checks tiny db for each item clicked and know which specific genre was clicked to handle logic properly
        //THis switch statement different categories which are movies, music, news, featureimages, featured
        final View.OnClickListener onClickListener = view -> Toast.makeText(context, "No Download Link Available at this time", Toast.LENGTH_SHORT).show();
        switch (tinyDb.getString("clicked")) {
            case "movies":
                streamBtn.setVisibility(View.GONE);
                downloadBtn.setVisibility(View.VISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("movieDetailsList"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");

                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
//                        contentView.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        tinyDb.putString("movie_title", title);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));
                        pattern = Pattern.compile("http.*?mp4");
                        matcher = pattern.matcher(content);
                        final Matcher matcher2= matcher;
                        if (matcher.find()){
                            //put the download link in tinydb for the exoplayer to pick up
                            downloadBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                if (sonshubInterstitialAd.isLoaded()){
                                    sonshubInterstitialAd.show();
                                    sonshubInterstitialAd.setAdListener(new AdListener(){
                                        @Override
                                        public void onAdClosed() {
                                            AdRequest adRequest = new AdRequest.Builder()
                                                    .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                                                    //.addTestDevice("DED5E5589FE9B73E06F70486636F2945") // Tecno Camon C7
                                                    .build();
                                            MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                            downloadFile(matcher2,context);
                                        }
                                    });
                                } else {
                                    downloadFile(matcher2,context);
                                    MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                }
                            });

                        } else {
                            downloadBtn.setOnClickListener(onClickListener);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            //If it was music that was clicked
            case "music":
                downloadBtn.setVisibility(View.VISIBLE);
                streamBtn.setVisibility(View.VISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("musicDetailsList"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");
                        tinyDb.putString("details_image_link", imageUrl);
                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
//                        contentView.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        tinyDb.putString("music_title", title);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));

                        pattern = Pattern.compile("http.*?\\.mp3");
                        matcher = pattern.matcher(content);
                        final Matcher matcher2= matcher;
                        if (matcher.find()){
                            //put the download link in tinydb for the exoplayer to pick up
                            tinyDb.putString("downloadLink", matcher.group(0));

                            downloadBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                if (sonshubInterstitialAd.isLoaded()){
                                    sonshubInterstitialAd.show();
                                    sonshubInterstitialAd.setAdListener(new AdListener(){
                                        @Override
                                        public void onAdClosed() {
                                            AdRequest adRequest = new AdRequest.Builder()
                                                    .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                                                    //.addTestDevice("DED5E5589FE9B73E06F70486636F2945") // Tecno Camon C7
                                                    .build();
                                            sonshubInterstitialAd.loadAd(adRequest);
                                            downloadFile(matcher2,context);
                                        }
                                    });
                                } else {
                                    downloadFile(matcher2,context);
                                    MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                }
                            });

                            streamBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                Toast.makeText(context, "Loading Music...", Toast.LENGTH_SHORT).show();
                                if (player.getPlayWhenReady()){
                                    player.stop();
                                }
                                Glide.with(context)
                                        .load(imageUrl)
                                        .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                        .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                        .into(imageStreamArt);


                                streamTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);

                                if (!isPreparing){
                                    MainActivity.playWhenReady = true;
                                }

                                if (Build.VERSION.SDK_INT >= 26){
                                    mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                                    mAudioAttributes =
                                            new AudioAttributes.Builder()
                                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                                    .build();
                                    mAudioFocusRequest =
                                            new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                                                    .setAudioAttributes(mAudioAttributes)
                                                    .setAcceptsDelayedFocusGain(true)
                                                    .setOnAudioFocusChangeListener(afChangeListener)
                                                    .build();

                                    mPlaybackDelayed = false;
                                    mPlaybackNowAuthorized = false;
                                    focusRequest = mAudioManager.requestAudioFocus(mAudioFocusRequest);

                                    synchronized(mFocusLock){
                                        switch (focusRequest) {
                                            case AudioManager.AUDIOFOCUS_REQUEST_FAILED:
                                                mPlaybackNowAuthorized = false;
                                                break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_GRANTED:
                                                mPlaybackNowAuthorized = true;
                                                initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                        MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));                                                    break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_DELAYED:
                                                mPlaybackDelayed = true;
                                                mPlaybackNowAuthorized = false;

                                        }
                                    }
                                } else {
                                    if (MainActivity.requestAudioFocus()){
                                        MainActivity.initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));
                                    }
                                }

                            });
                        } else {
                            downloadBtn.setOnClickListener(onClickListener);

                            streamBtn.setOnClickListener(onClickListener);
                        }

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case "featured":
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("featuredDetailsList"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");

                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
//                        contentView.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));

                        pattern = Pattern.compile("http.*?\\.mp3");
                        matcher = pattern.matcher(content);
                        final Matcher matcher2= matcher;
                        //If the mp3 file is found meaning it's a featured music
                        if (matcher.find()){
                            //put the download link in tinydb for the exoplayer to pick up
                            tinyDb.putString("downloadLink", matcher.group(0));

                            downloadBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                if (MainActivity.sonshubInterstitialAd.isLoaded()){
                                    MainActivity.sonshubInterstitialAd.show();
                                    MainActivity.sonshubInterstitialAd.setAdListener(new AdListener(){
                                        @Override
                                        public void onAdClosed() {
                                            MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                            downloadFile(matcher2,context);
                                        }
                                    });
                                } else {
                                    downloadFile(matcher2,context);
                                    MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                }
                            });

                            streamBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                Toast.makeText(context, "Loading Music...", Toast.LENGTH_SHORT).show();
                                if (MainActivity.player.getPlayWhenReady()){
                                    MainActivity.player.stop();
                                }
                                Glide.with(context)
                                        .load(imageUrl)
                                        .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                        .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                        .into(imageStreamArt);

                                streamTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);

                                if (!MainActivity.isPreparing){
                                    MainActivity.playWhenReady = true;
                                }

                                if (Build.VERSION.SDK_INT >= 26){
                                    mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                                    mAudioAttributes =
                                            new AudioAttributes.Builder()
                                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                                    .build();
                                    mAudioFocusRequest =
                                            new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                                                    .setAudioAttributes(mAudioAttributes)
                                                    .setAcceptsDelayedFocusGain(true)
                                                    .setOnAudioFocusChangeListener(afChangeListener)
                                                    .build();

                                    mPlaybackDelayed = false;
                                    mPlaybackNowAuthorized = false;
                                    focusRequest = mAudioManager.requestAudioFocus(mAudioFocusRequest);

                                    synchronized(mFocusLock){
                                        switch (focusRequest) {
                                            case AudioManager.AUDIOFOCUS_REQUEST_FAILED:
                                                mPlaybackNowAuthorized = false;
                                                break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_GRANTED:
                                                mPlaybackNowAuthorized = true;
                                                initializePlayer(MainActivity.getInstance(),MainActivity.player,playerView,MainActivity.playWhenReady,
                                                        MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));                                                    break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_DELAYED:
                                                mPlaybackDelayed = true;
                                                mPlaybackNowAuthorized = false;

                                        }
                                    }
                                } else {
                                    if (MainActivity.requestAudioFocus()){
                                        MainActivity.initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));
                                    }
                                }
                            });
                        } else {
                            downloadBtn.setOnClickListener(onClickListener);

                            streamBtn.setOnClickListener(onClickListener);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case "news":
                streamBtn.setVisibility(View.GONE);
                downloadBtn.setVisibility(View.GONE);
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("newsDetailsList"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");

                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        songContent.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case "featuredimages":
                downloadBtn.setVisibility(View.VISIBLE);
                streamBtn.setVisibility(View.VISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(tinyDb.getString("featuredimageslist"));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String imageUrl = obj.getString("imageUrl");
                        String title = obj.getString("title");
                        String content = obj.getString("content");
                        String link = obj.getString("link");
                        tinyDb.putString("details_image_link", imageUrl);
                        Glide.with(context)
                                .load(imageUrl)
                                .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                .into(imageView);
                        String newContentText = content.trim().replace("<img>", "");
//                        contentView.setText(Html.fromHtml(newContentText), TextView.BufferType.SPANNABLE);
                        songTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);
                        tinyDb.putString("music_title", title);
                        button.setOnClickListener(view12 -> CustomTabsHelper.openCustomTab(context, customTabsIntent,
                                Uri.parse(link),
                                new WebViewFallback()));

                        //THis looks for a specific regex pattern (a link ending with mp3)
                        //If it is found then the user can download or stream the music
                        pattern = Pattern.compile("http.*?\\.mp3");
                        matcher = pattern.matcher(content);
                        final Matcher matcher2= matcher;
                        if (matcher.find()){
                            //put the download link in tinydb for the exoplayer to pick up
                            tinyDb.putString("downloadLink", matcher.group(0));

                            downloadBtn.setOnClickListener(view -> {
                                bottomSheetDialog.dismiss();
                                if (MainActivity.sonshubInterstitialAd.isLoaded()){
                                    MainActivity.sonshubInterstitialAd.show();
                                    MainActivity.sonshubInterstitialAd.setAdListener(new AdListener(){
                                        @Override
                                        public void onAdClosed() {
                                            AdRequest adRequest1 = new AdRequest.Builder()
                                                    .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                                                    //.addTestDevice("DED5E5589FE9B73E06F70486636F2945") // Tecno Camon C7
                                                    .build();
                                            MainActivity.sonshubInterstitialAd.loadAd(adRequest1);
                                            downloadFile(matcher2,context);
                                        }
                                    });
                                } else {
                                    downloadFile(matcher2,context);
                                    MainActivity.sonshubInterstitialAd.loadAd(adRequest);
                                }
                            });

                            streamBtn.setOnClickListener(view -> {
                                if (player.getPlayWhenReady()){
                                    player.stop();
                                }
                                Glide.with(context)
                                        .load(imageUrl)
                                        .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                                        .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                                        .into(imageStreamArt);

                                streamTitle.setText(Html.fromHtml(title), TextView.BufferType.SPANNABLE);

                                if (!MainActivity.isPreparing){
                                    MainActivity.playWhenReady = true;
                                }

                                if (Build.VERSION.SDK_INT >= 26){
                                    mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                                    mAudioAttributes =
                                            new AudioAttributes.Builder()
                                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                                    .build();
                                    mAudioFocusRequest =
                                            new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                                                    .setAudioAttributes(mAudioAttributes)
                                                    .setAcceptsDelayedFocusGain(true)
                                                    .setOnAudioFocusChangeListener(afChangeListener)
                                                    .build();

                                    mPlaybackDelayed = false;
                                    mPlaybackNowAuthorized = false;
                                    focusRequest = mAudioManager.requestAudioFocus(mAudioFocusRequest);

                                    synchronized(mFocusLock){
                                        switch (focusRequest) {
                                            case AudioManager.AUDIOFOCUS_REQUEST_FAILED:
                                                mPlaybackNowAuthorized = false;
                                                break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_GRANTED:
                                                mPlaybackNowAuthorized = true;
                                                initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                        MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));                                                    break;
                                            case AudioManager.AUDIOFOCUS_REQUEST_DELAYED:
                                                mPlaybackDelayed = true;
                                                mPlaybackNowAuthorized = false;

                                        }
                                    }
                                } else {
                                    if (MainActivity.requestAudioFocus()){
                                        MainActivity.initializePlayer(MainActivity.getInstance(),player,playerView,MainActivity.playWhenReady,
                                                MainActivity.playBackPosition,MainActivity.currentWindow,matcher2.group(0));
                                    }
                                }
                            });
                        } else {
                            downloadBtn.setOnClickListener(onClickListener);

                            streamBtn.setOnClickListener(onClickListener);
                        }

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    @SuppressLint("InflateParams")
    public static void downloadFile(Matcher matcher,Context context){
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context);
        final View generalNoticeView = LayoutInflater.from(context).inflate(R.layout.general_notice, null);

        Button cancelButton = generalNoticeView.findViewById(R.id.cancelButton);
        Button continueButton = generalNoticeView.findViewById(R.id.continueButton);

        String downloadFileUrl = matcher.group(0);
        Data.sampleUrls = new String[]{downloadFileUrl};
        Timber.d(Arrays.toString(Data.sampleUrls));
        String fileName = downloadFileUrl.substring(downloadFileUrl.lastIndexOf('/') + 1);
        if (need2Download(fileName)){
            Downloader.enqueueDownload();
        } else {
            continueButton.setOnClickListener(v -> {
                File basePathMp3 = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Music");
                File basePathVideo = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Videos");

                File fullPathMp3 = new File(basePathMp3, fileName);
                File fullPathVideo = new File(basePathVideo, fileName);
                if (fileName.toLowerCase().endsWith(".mp3")) {
                    fullPathMp3.delete();
                } else if (fileName.toLowerCase().endsWith(".mp4")) {
                    fullPathVideo.delete();
                } else {
                    Toast.makeText(context, "We encountered an error ;(", Toast.LENGTH_LONG).show();
                }
                Downloader.enqueueDownload();
                bottomSheetDialog.dismiss();
            });
            cancelButton.setOnClickListener(v -> bottomSheetDialog.dismiss());
            bottomSheetDialog.setCancelable(false);
            bottomSheetDialog.setContentView(generalNoticeView);
            bottomSheetDialog.show();
        }

    }

    public static boolean need2Download(String fileName) {
        File basePathMp3 = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Music");
        File basePathVideo = new File(Environment.getExternalStorageDirectory() + "/SonsHub" + "/Videos");

        File fullPathMp3 = new File(basePathMp3, fileName);
        File fullPathVideo = new File(basePathVideo, fileName);

        /*if (fullPathMp3.exists() || fullPathVideo.exists()) {
            return false;
        }*/
        return !fullPathMp3.exists() && !fullPathVideo.exists();
    }

    @Override
    public void onStop() {
        super.onStop();
        // To prevent a memory leak on rotation, make sure to call stopAutoCycle() on the slider before activity or fragment is destroyed
        mDemoSlider.stopAutoCycle();
        super.onStop();
    }

}
