package com.gigabytedevelopersinc.apps.sonshub.fragments.downloads;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.gigabytedevelopersinc.apps.sonshub.utils.DownloadUtils;
import timber.log.Timber;

import com.gigabytedevelopersinc.apps.sonshub.R;
import com.gigabytedevelopersinc.apps.sonshub.adapters.DownloadedAdapter;
import com.gigabytedevelopersinc.apps.sonshub.models.DownloadedModel;
import com.gigabytedevelopersinc.apps.sonshub.ui.ExpandableLayout;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static android.view.Gravity.BOTTOM;

/**
 * Project - SonsHub
 * Created with Android Studio
 * Company: Gigabyte Developers
 * User: Emmanuel Nwokoma
 * Title: Founder and CEO
 * Day: Wednesday, 06
 * Month: March
 * Year: 2019
 * Date: 06 Mar, 2019
 * Time: 11:15 AM
 * Desc: DownloadedFragment
 **/
public class DownloadedFragment extends Fragment {
    private RecyclerView recyclerViewAudio, recyclerViewVideo;
    private DownloadedAdapter adapter;

    public DownloadedFragment() {
        // Required empty public constructor
        super();
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_downloaded, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Setup downloaded Audio RecyclerView and list downloaded Audio files
        recyclerViewAudio = view.findViewById(R.id.recyclerViewDownloadedAudio);
        LinearLayout downloadedAudioLayout = view.findViewById(R.id.downloadedAudioLayout);
        ImageView downloadedAudioToggle = view.findViewById(R.id.audioToggleImg);
        ExpandableLayout downloadedAudioExpandableLayout = view.findViewById(R.id.audioExpandableLayout);
        downloadedAudioToggle.setImageResource(R.drawable.ic_toggle_open);

        // Setup downloaded Video RecyclerView and list downloaded Video files
        recyclerViewVideo = view.findViewById(R.id.recyclerViewDownloadedVideo);
        LinearLayout downloadedVideoLayout = view.findViewById(R.id.downloadedVideoLayout);
        ImageView downloadedVideoToggle = view.findViewById(R.id.videoToggleImg);
        ExpandableLayout downloadedVideoExpandableLayout = view.findViewById(R.id.videoExpandableLayout);
        downloadedVideoToggle.setImageResource(R.drawable.ic_toggle_open);

        downloadedAudioLayout.setOnClickListener(v -> {
            if (downloadedAudioExpandableLayout.isExpanded()) {
                downloadedAudioToggle.setImageResource(R.drawable.ic_toggle_open);
                downloadedAudioExpandableLayout.collapse();
            } else if (downloadedVideoExpandableLayout.isExpanded()) {
                downloadedVideoExpandableLayout.collapse();
            } else {
                downloadedAudioToggle.setImageResource(R.drawable.ic_toggle_close);
                downloadedAudioExpandableLayout.expand();
            }
        });
        downloadedAudioExpandableLayout.setOnExpansionUpdateListener((expansionFraction, state) -> {
            Timber.tag("ExpandableLayout").d("State: %s", state);
        });
        ArrayList<File> totalAudio = getAudioListFiles();
        if (totalAudio != null){
            if (totalAudio.size() > 0){
                setAudioListAdapter(parseAudioToFileName(totalAudio));
            }
        }

        downloadedVideoLayout.setOnClickListener(v -> {
            if (downloadedVideoExpandableLayout.isExpanded()) {
                downloadedVideoToggle.setImageResource(R.drawable.ic_toggle_open);
                downloadedVideoExpandableLayout.collapse();
            } else if (downloadedAudioExpandableLayout.isExpanded()) {
                downloadedAudioExpandableLayout.collapse();
            } else {
                downloadedVideoToggle.setImageResource(R.drawable.ic_toggle_close);
                downloadedVideoExpandableLayout.expand();
            }
        });
        downloadedVideoExpandableLayout.setOnExpansionUpdateListener((expansionFraction, state) -> {
            Timber.tag("ExpandableLayout").d("State: %s", state);
        });
        ArrayList<File> totalVideo = getVideoListFiles();
        if (totalVideo != null){
            if (totalVideo.size() > 0){
                setVideoListAdapter(parseVideoToFileName(totalVideo));
            }
        }
    }

    // For Downloaded Audio Files
    private ArrayList<DownloadedModel> parseAudioToFileName(ArrayList<File> audioFiles) {
        ArrayList<DownloadedModel> fileNames = new ArrayList<>();
        for (File f : audioFiles) {
            String[] name = f.getAbsolutePath().split("/");
            if (name[(name.length - 1)].endsWith(".mp3"))
                fileNames.add(new DownloadedModel(name[(name.length - 1)]));
        }
        return fileNames;
    }
    private void setAudioListAdapter(List<DownloadedModel> data){
        adapter = new DownloadedAdapter(getActivity(), data, (view, position, title) -> {
            File fileFolder = Environment.getExternalStorageDirectory();
            File audioUrl = new File(
                    fileFolder.getPath() + "/SonsHub/Music/" + title
            );
            Uri uri1 = Uri.fromFile(audioUrl);
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri1, DownloadUtils.getMimeType(Objects.requireNonNull(getContext()), uri1));
                intent.setClassName(
                        "com.gigabytedevelopersinc.apps.sonshub",
                        "com.gigabytedevelopersinc.apps.sonshub.players.music.ui.activities.MusicMainActivity"
                );
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(getContext(), "Sorry, our Music Player cannot open this file",
                        Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.fromFile(audioUrl),"audio/mp3");
                startActivity(Intent.createChooser(intent, "Play this song with"));
                e.printStackTrace();
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerViewAudio.setLayoutManager(linearLayoutManager);
        recyclerViewAudio.setAdapter(adapter);
    }
    private ArrayList<File> getAudioListFiles() {
        File file = new File(
                Environment.getExternalStorageDirectory() + "/SonsHub/Music"
        );
        ArrayList<File> fileArrayList = new ArrayList<>();

        File[] listOfFiles = file.listFiles();
        if (file.exists()) {
            for (File f : listOfFiles) {
                if (f.getAbsolutePath().endsWith(".mp3"))
                    fileArrayList.add(f);
            }
        } else {
            file.mkdir();
        }
        return fileArrayList;

    }

    // For Downloaded Video Files
    private ArrayList<DownloadedModel> parseVideoToFileName(ArrayList<File> videoFiles) {
        ArrayList<DownloadedModel> fileNames = new ArrayList<>();
        for (File f : videoFiles) {
            String[] name = f.getAbsolutePath().split("/");
            if (name[(name.length - 1)].endsWith(".mp4"))
                fileNames.add(new DownloadedModel(name[(name.length - 1)]));
        }
        return fileNames;
    }
    private void setVideoListAdapter(List<DownloadedModel> data){
        adapter = new DownloadedAdapter(getActivity(), data, (view, position, title) -> {
            try {
                File fileFolder = Environment.getExternalStorageDirectory();
                File videoUrl = new File(
                        fileFolder.getPath() + "/SonsHub/Videos/" + title
                );
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.fromFile(videoUrl),"video/mp4");
                startActivity(Intent.createChooser(intent, "Play this Video with"));
            } catch (Exception e) {
                Toast.makeText(getContext(), "No Application can open this file",
                        Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerViewVideo.setLayoutManager(linearLayoutManager);
        recyclerViewVideo.setAdapter(adapter);
    }
    private ArrayList<File> getVideoListFiles() {
        File file = new File(
                Environment.getExternalStorageDirectory() + "/SonsHub/Videos"
        );
        ArrayList<File> fileArrayList = new ArrayList<>();

        File[] listOfFiles = file.listFiles();
        if (file.exists()) {
            for (File f : listOfFiles) {
                if (f.getAbsolutePath().endsWith(".mp4"))
                    fileArrayList.add(f);
            }
        } else {
            file.mkdir();
        }
        return fileArrayList;
    }
}