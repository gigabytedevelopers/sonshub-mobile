package com.gigabytedevelopersinc.apps.sonshub.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.GenericTransitionOptions;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.gigabytedevelopersinc.apps.sonshub.R;
import com.gigabytedevelopersinc.apps.sonshub.models.MainListModel;
import com.gigabytedevelopersinc.apps.sonshub.utils.ClickListener;
import com.gigabytedevelopersinc.apps.sonshub.utils.OnBottomReachedListener;
import com.google.android.gms.ads.NativeExpressAdView;

import java.util.ArrayList;
import java.util.List;

public class AdmobRecyclerViewAdapter extends RecyclerView.Adapter {

    // Defining variables for view types
    private static final int DATA_VIEW_TYPE = 0;
    private static final int NATIVE_EXPRESS_AD_VIEW_TYPE = 1;
    OnBottomReachedListener onBottomReachedListener;

    private Context mContext;
    private List<Object> mDataset = new ArrayList<>();
    private ClickListener listener;

    // Variable for number of data items between ads
    private int spaceBetweenAds;

    // View Holder for data item
    public class DataViewHolder extends RecyclerView.ViewHolder {

        private ImageView image, menuIcon;
        private TextView title, description, time;

        DataViewHolder(View view) {
            super(view);
            image = view.findViewById(R.id.music_image);
            title = view.findViewById(R.id.music_title);
            description = view.findViewById(R.id.music_title_description);
            time = view.findViewById(R.id.music_post_time);
        }
    }

    // View Holder for Admob Native Express Ad Unit
    public class NativeExpressAdViewHolder extends RecyclerView.ViewHolder {
        NativeExpressAdViewHolder(View view) {
            super(view);
        }
    }

    // Constructor for Adapter
    public AdmobRecyclerViewAdapter(Context context, List<Object> dataset, int spaceBetweenAds, ClickListener listener) {
        this.mContext = context;
        this.spaceBetweenAds = spaceBetweenAds;
        this.mDataset.addAll(dataset);
        this.listener = listener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        // Switch Case for creating ViewHolder based on viewType
        switch (viewType) {
            case DATA_VIEW_TYPE:
                DataViewHolder dataViewHolder;
                View dataLayoutView = LayoutInflater.from(viewGroup.getContext()).inflate(
                        R.layout.music_list_item, viewGroup, false);
                dataViewHolder = new DataViewHolder(dataLayoutView);
                dataLayoutView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        listener.onItemClick(dataLayoutView,dataViewHolder.getAdapterPosition());
                    }
                });
                return dataViewHolder;
            case NATIVE_EXPRESS_AD_VIEW_TYPE:
                // fall through
            default:
                View nativeExpressLayoutView = LayoutInflater.from(
                        viewGroup.getContext()).inflate(R.layout.native_ad_cardview,
                        viewGroup, false);
                return new NativeExpressAdViewHolder(nativeExpressLayoutView);
        }

    }

    public void setOnBottomReachedListener(OnBottomReachedListener onBottomReachedListener){

        this.onBottomReachedListener = onBottomReachedListener;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int lastPosition = -1;
        Animation animation = AnimationUtils.loadAnimation(mContext,
                (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);


        holder.itemView.startAnimation(animation);
        lastPosition = position;
        if (position == mDataset.size() - 1){
            onBottomReachedListener.onBottomReached(position);
        }

        int viewType = getItemViewType(position);

        // Binding data based on View Type
        switch (viewType) {
            case DATA_VIEW_TYPE:
                DataViewHolder dataViewHolder = (DataViewHolder) holder;
                MainListModel stateBriefData = (MainListModel) mDataset.get(position);

                dataViewHolder.title.setText(stateBriefData.getTitle());
                dataViewHolder.description.setText(stateBriefData.getDescription());
                dataViewHolder.time.setText(stateBriefData.getTime());

                Glide.with(mContext)
                        .load(stateBriefData.getImageUrl())
                        .transition(GenericTransitionOptions.with(android.R.anim.fade_in))
                        .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
                        .into(dataViewHolder.image);

                break;
            case NATIVE_EXPRESS_AD_VIEW_TYPE:
                // fall through
            default:
                try {
                    NativeExpressAdViewHolder nativeExpressHolder = (NativeExpressAdViewHolder) holder;
                    NativeExpressAdView adView = (NativeExpressAdView) mDataset.get(position);
                    ViewGroup adCardView = (ViewGroup) nativeExpressHolder.itemView;

                    if (adCardView.getChildCount() > 0) {
                        adCardView.removeAllViews();
                    }
                    if (adView.getParent() != null) {
                        ((ViewGroup) adView.getParent()).removeView(adView);
                    }
                    adCardView.addView(adView);
                } catch (Exception e){
                    System.out.println("Not an adview");
                    e.printStackTrace();
                }

        }
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    @Override
    public int getItemViewType(int position) {
        // Logic for returning view type based on spaceBetweenAds variable
        // Here if remainder after dividing the position with (spaceBetweenAds + 1) comes equal to spaceBetweenAds,
        // then return NATIVE_EXPRESS_AD_VIEW_TYPE otherwise DATA_VIEW_TYPE
        // By the logic defined below, an ad unit will be showed after every spaceBetweenAds numbers of data items
        return (position % (spaceBetweenAds + 1) == spaceBetweenAds) ? NATIVE_EXPRESS_AD_VIEW_TYPE: DATA_VIEW_TYPE;
    }

}