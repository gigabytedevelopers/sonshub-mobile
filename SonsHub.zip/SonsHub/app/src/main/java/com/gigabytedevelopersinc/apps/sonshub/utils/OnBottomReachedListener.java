package com.gigabytedevelopersinc.apps.sonshub.utils;

public interface OnBottomReachedListener {
    void onBottomReached(int position);
}
