package com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2core

data class FileSliceInfo(val slicingCount: Int, val bytesPerFileSlice: Long)