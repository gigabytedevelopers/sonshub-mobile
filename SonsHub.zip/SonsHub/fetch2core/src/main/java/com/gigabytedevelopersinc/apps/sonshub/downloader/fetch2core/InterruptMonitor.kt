package com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2core

interface InterruptMonitor {
    val isInterrupted: Boolean
}