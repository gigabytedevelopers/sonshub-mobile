package com.gigabytedevelopersinc.apps.sonshub.downloader.fetch2.exception

open class FetchException constructor(message: String) : RuntimeException(message)